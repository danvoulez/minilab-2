# Contributing

## Doctrine First

Before implementing behavior, identify the governing RFC layer and invariant.

- Do not collapse law, proof, labour, economics, jurisdiction, and actuation into one crate.
- Do not bypass transcript and proof visibility with hidden state.
- Do not convert model output into final authority.

## Development Workflow

```bash
just fmt
just check
just lint
just test
```

## Standards

- Rust edition: `2024`
- Minimum supported Rust version: `1.85`
- Pinned development and CI toolchain: `1.94.0`
- `unsafe`: discouraged (`warn`)
- Clippy warnings are CI-failing (`-D warnings`)
- APIs should be strongly typed (newtypes where identity matters)

## Pull Request Expectations

- Explain which constitutional layer changed and why.
- Add or update tests for invariants touched.
- Update docs when public contracts or dependency direction change.
