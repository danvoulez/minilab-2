# Epistemic Runtime

## Purpose

This note records the first executable epistemic layer added on top of the constitutional stack.

It is not a new constitutional office. It is a cross-cutting implementation slice spanning:

- `proof-runtime` as proof-bearing closure process.
- `epistemic-storage` as typed record of cells, ghosts, and resolution.
- `manager-plane` as institutional consequence of epistemic state.
- `horizon-real` as the explicit boundary where grounding can stop being a metaphor.

The doctrinal background sits primarily across RFC-0002, RFC-0003, RFC-0005, and Paper 10.

## What Was Implemented

### 1. Canonical epistemic objects in `epistemic-storage`

Added a minimal stable form for:

- `CanonicalCell`
- `GhostRecord`
- `CellKind`
- `CellStatus`
- `JustificationRef`
- `DoubtPolicy`
- `ClosureClass`
- `EpistemicGraph`

The current `CanonicalCell` shape is intentionally minimal:

- `id`
- `kind`
- `content`
- `status`
- `depends_on`
- `confirmed_by`
- `if_doubt`
- `created_at`
- `meta`

This is not yet the full final-form nine-field doctrine. It is the minimum executable form that already has structural room for provenance, absence, closure, and suspension.

`GhostRecord` is now a first-class object rather than a flag. It carries:

- `reason`
- `criticality`
- `opened_from`
- `required_for`
- `status`
- `resolution_ref`

The graph can now explicitly resolve a ghost through `resolve_ghost(...)`.

The storage layer now also has a first durable persistence slice:

- `PersistedGraphSnapshot`
- `PersistedCaseState`
- `PersistedReceipt`
- `EpistemicStateStore`
- `SqliteEpistemicStore`

This is intentionally thin. It does not yet try to become a grand storage platform. It gives the runtime enough durable substrate to save graph state, case state, and replayable receipts across restart.

### 2. Pure epistemic checks in `proof-runtime`

Added three pure functions:

- `compute_grounding_ratio(...)`
- `detect_spawn_omission(...)`
- `closure_guard(...)`

This gives the runtime a minimal geometry of legitimacy:

- external anchors contribute grounding at the base.
- internal derivation decays with depth.
- independent support paths accumulate up to a ceiling.
- closed internal loops without contact to anchor collapse to zero.

The omission detector currently catches:

- unsupported premises with neither anchor nor ghost.
- strong causal jumps without an intermediate evidentiary bridge.
- unresolved material contradiction without resolution or ghost.

The closure guard now distinguishes:

- `Commit`
- `Ghost`
- `Reject`

### 3. Transcripted epistemic receipts in `proof-runtime`

The runtime now emits typed epistemic receipts rather than hiding closure judgment inside local logic:

- `EpistemicClosureEvaluated`
- `GhostResolved`
- `EpistemicClosureTransition`

This means grounding and closure legitimacy now appear in the transcript as replayable artifacts.

The runtime also materializes a `Resolution` cell when a ghost is resolved. That cell is linked back into the graph through `confirmed_by`, so the system does not merely mark a ghost as closed; it creates a new justificatory object.

The proof runtime now also has a first persistence-and-replay surface:

- `ReplaySeed`
- `ReplayAuditBundle`
- `ReplayEquivalenceReport`
- `persist_replay_seed(...)`
- `load_replay_seed(...)`
- `persist_proof_pack_receipts(...)`
- `load_replay_audit_bundle(...)`
- `compare_replay_equivalence(...)`

These helpers let the runtime save enough epistemic state to restart, reload, and compare governed outcomes without inventing a separate replay subsystem.

### 4. Witness and anchor driven ghost resolution

Ghosts can now be resolved through:

- the latest witness receipt
- the latest external anchor receipt

This is the first working bridge between doubt and reality-bearing evidence.

It is still a thin bridge, but it is executable and transcript-visible.

### 5. Institutional behavior in `manager-plane`

The manager now treats epistemic state as governance-relevant rather than advisory.

Implemented behavior:

- doubt with `SpawnGhost` policy creates a `GhostRecord`.
- `EpistemicClosureEvaluated` does not advance the case.
- `EpistemicClosureTransition { to: Commit }` is required for pointer advance.
- `EpistemicClosureTransition { to: Ghost }` blocks as `GhostPending`.
- `EpistemicClosureTransition { to: Reject }` blocks as `EpistemicReject`.
- `GhostResolved` triggers `ReevaluateEpistemicClosure`.
- persisted manager case state can now carry the next institutional consequence across restart.
- rehydrated manager state can now resume a pending `AdvancePointer`, `GhostPending`, or `EpistemicReject` state without recomputing it from scratch.

This is important: evidence arrival alone does not produce sovereignty. Only an explicit audited requalification of closure does.

### 6. Proposal adaptation in `manager-plane`

The manager now also has a strict proposal adapter that:

- parses LLM-style JSON into typed cells and graph state
- normalizes unknown or partial fields into explicit defaults with issues recorded
- separates syntactic validity from epistemic adequacy
- synthesizes explicit ghosts for recoverable unsupported claims rather than letting absence remain implicit

This is the first bridge from real proposer output to the epistemic runtime without hand-authored Rust fixtures.

### 7. Runnable containment benchmark path

The workspace now also has a vendor-agnostic proposer seam with:

- `MockProposer` for deterministic CI coverage
- `FileStructuredJsonBackend` for fixture and replay runs
- `CommandStructuredJsonBackend` for live external proposer processes that accept prompt JSON on `stdin` and emit strict proposal JSON on `stdout`
- `OpenAiResponsesBackend` for direct live model calls through the Responses API while preserving strict JSON schema control and raw-response auditability

The `manager-plane` example runner can now:

- load benchmark cases from disk
- execute the selected proposer path
- normalize and score the resulting proposals
- persist a typed benchmark report for later audit

### 8. End-to-end proof in `horizon-real`

The integration test path now proves the sequence:

1. manager delegates
2. runtime evaluates closure
3. manager does not advance on initial non-commit state
4. witness resolves the ghost
5. manager triggers re-evaluation
6. runtime emits `EpistemicClosureTransition { from: Ghost, to: Commit }`
7. manager advances the pointer only after that transition

This is the first system-level proof that the epistemic layer is not merely a crate-local utility.

The integration path now also proves the same chain across restart:

1. runtime emits `GhostResolved`
2. manager produces `ReevaluateEpistemicClosure`
3. runtime seed and manager state are persisted
4. both are rehydrated after restart
5. the restored manager resumes the same re-evaluation
6. runtime emits `EpistemicClosureTransition { from: Ghost, to: Commit }`
7. manager advances the pointer from the restored state

This is a stronger claim than replay of runtime state alone. It begins to show replayable institutional sovereignty rather than replayable in-memory correctness.

### 9. Stage 1 scenarios institutionalized in Rust

The original four epistemic scenarios now exist as Rust-native runtime fixtures:

- `complete`
- `honest_doubt`
- `hallucination`
- `paranoia`

They are no longer only conceptual examples or external prototype fixtures.

They now serve as:

- live runtime classification checks
- replay-equivalence regression checks
- a compact executable memory of the project’s early epistemic claims

## Why This Matters

This slice establishes five important claims in executable form.

### 1. Absence now has form

The system no longer has to choose between silent omission and false completion.

Missing support can be represented explicitly as a `GhostRecord`.

### 2. Doubt is now a process obligation

`if_doubt` is no longer rhetorical. It now changes runtime and manager behavior.

The system is beginning to preserve the capacity for suspension instead of treating uncertainty as a formatting problem.

### 3. Closure is now governed, not implied

A coherent internal derivation is no longer enough.

Closure must survive:

- grounding checks
- omission checks
- transcript visibility
- constitutional verdict

### 4. Resolution does not equal closure

The arrival of evidence is not identical to lawful advance.

The system now distinguishes:

- resolution of a gap
- re-evaluation of closure
- institutional permission to advance

That distinction is one of the central ideas of the project.

### 5. Grounding now has a runtime boundary

Because the current slice resolves ghosts from witness or external anchor flows and sits adjacent to `horizon-real`, grounding is beginning to exist as runtime boundary rather than philosophical metaphor.

It is still early, but the architecture now has a place where contact with the world can enter as typed justification.

### 6. Restart now preserves institutional consequence

The persistence slice no longer preserves only:

- graph state
- ghost state
- receipt history

It now also preserves:

- pending pointer advance
- `GhostPending` institutional block
- `EpistemicReject` institutional block
- the resume path from ghost resolution to lawful pointer advance
- the resume path from ghost resolution to lawful institutional reject

That is a real doctrinal move for the project: restart is beginning to preserve sovereignty, not only serialized memory.

## Current Guarantees

The current tests prove at least the following:

- hallucinated closure without required ghost is rejected.
- honest gap with explicit ghost yields `Ghost`, not false `Commit`.
- runtime emits closure receipts into the transcript.
- ghost resolution can be driven by witness or external anchor.
- ghost resolution is followed by explicit re-evaluation rather than silent advancement.
- manager does not advance on evaluation alone.
- manager does not advance on `GhostResolved` alone and instead triggers re-evaluation.
- manager advances only on explicit transition to `Commit`.
- manager restart preserves pending `AdvancePointer`, `GhostPending`, and `EpistemicReject` consequences.
- manager and runtime together preserve the `GhostResolved -> ReevaluateEpistemicClosure -> AdvancePointer` chain across restart.
- manager and runtime together preserve the `GhostResolved -> ReevaluateEpistemicClosure -> EpistemicReject` chain across restart.
- manager can adapt LLM-style structured output into `EpistemicGraph` while preserving adequacy issues and recoverable absence.
- transcript event order remains causal and append-only in the end-to-end path.
- graph, case state, and receipt log can survive store reopen through the local SQLite persistence slice.
- replay seed loading preserves session, graph, and pointer-facing case state.
- replay equivalence already holds for a lawful `Ghost -> Commit` path.
- replay equivalence already holds for an adversarial `Reject` path.
- the four Stage 1 scenarios preserve their epistemic class in native Rust tests and survive persistence/replay round-trips without semantic drift.

## Deliberately Not Yet Implemented

The current layer is intentionally minimal.

Still deferred:

- full final-form epistemic cell schema.
- distributed or production-grade persistence beyond the current local SQLite slice.
- richer ghost taxonomy and policy packs.
- richer persisted resume flows across manager/runtime boundaries.
- direct production adapters from `horizon-real` sensors and witnesses into `confirmed_by`.
- additional live model adapters beyond the current OpenAI Responses path.
- richer operator surfaces beyond the current benchmark runner example.

## Immediate Next Steps

The next implementation passes should be:

1. extend replay equivalence to broader multi-step and manager-linked resume flows.
2. connect `horizon-real` witness and anchor adapters directly to closure requalification.
3. expand receipts so resolution lineage and pointer eligibility are easier to audit across longer chains.
4. document the current persistence tranche as an interim `Cycle 3` governed result, then decide whether the next cut is freeze-ready or needs one more replay lane.

## Summary

The workspace now contains a minimal but real epistemic runtime.

It can represent absence, preserve doubt, resolve gaps through evidence, re-qualify closure, persist core epistemic state across restart, and compare replayed outcomes against live governed behavior.

That is already more than a validation library.

It is the beginning of closure-carrying governance.
