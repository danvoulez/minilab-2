# Type Hardening

## Purpose

This note records the short type-hardening pass completed for TASKLIST 0.

The goal is not to eliminate every raw `String` in one sweep.

The goal is to harden identities that already carry clear legitimacy or routing burden, while preserving the current constitutional layering of the workspace.

## Completed In This Pass

### `proof-runtime`

Added explicit newtypes for core transcript and proof identity:

- `CaseId`
- `ContractHash`

These now flow through:

- `Session`
- `SessionView`
- `StepEvent`
- `ProofPack`

Why this matters:

- case identity is no longer an ambient string at the runtime boundary
- contract identity is no longer a loose string at the proof-bearing boundary

### `manager-plane`

Hardened manager-facing routing and advancement identity with:

- `CaseId` from `proof-runtime`
- `WorkerId`
- `PointerAlias`
- `AtomCid` for delegated task identity
- `GhostId` for ghost spawn output

Why this matters:

- delegated work now carries an atom identity type rather than a raw string
- pointer advancement now distinguishes the head alias from arbitrary text
- ghost identifiers no longer lose their type at the manager boundary

### Integration coverage

The hardening pass was carried through:

- manager unit tests
- proof runtime unit tests
- jurisdiction tests that consume `ProofPack`
- `horizon-real` end-to-end tests

## Existing Strong Types Already Present

The workspace already had meaningful newtypes in several places, including:

- `AtomCid`
- `CellId`
- `GhostId`
- `ReceiptCid`
- `CaseCid`
- `ProofPackCid`
- `RecommendationCid`
- `SignerId`
- `AuthorityCid`
- `Signature`

This pass extends that direction rather than starting it from zero.

## Deferred Candidates

The following remain acceptable candidates for later hardening:

- manager witness identifiers
- justification artifact identifiers in jurisdiction
- manager-facing reason and queue codes
- additional pointer and receipt identity types where they become protocol-bearing rather than merely descriptive

These remain deferred because the current pass focused on identities that already sit directly on runtime, transcript, or institutional routing boundaries.

## Rule For Future Hardening

Prefer a stronger type when all three are true:

1. the value carries legitimacy, authority, or replay significance
2. the value crosses crate or protocol boundaries
3. mixing it with ordinary text would plausibly hide a defect

Do not add newtypes merely for ornament.

In this workspace, types should make important invalid states harder to express, not make the code ceremonially heavier.
