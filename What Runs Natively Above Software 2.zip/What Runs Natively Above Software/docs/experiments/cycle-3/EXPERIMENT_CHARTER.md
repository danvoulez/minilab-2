# Experiment Charter

## Identity
- template_family: v1
- experiment_id: cycle-3
- cycle_id: cycle-3
- title: Persistence and replay equivalence for governed epistemic state
- owner: ubl-ops
- date_opened: 2026-03-16
- status: in_progress_with_tranche_a_frozen

## Question
> Does persisted epistemic state preserve the same governed verdicts, ghost lifecycle state, and pointer eligibility after restart and replay?

## Hypothesis
> If persistence and replay are implemented correctly, restart and replay should preserve closure verdicts, ghost state, and pointer-advance eligibility without semantic drift.

## Why this matters
> The current runtime has already proved containment and governed closure in memory. The next doctrinal step is to show that these results survive process boundaries, so the system is not merely convincing while live in RAM.

## Scope
### In scope
- persistence and reload of `EpistemicGraph`
- persistence and reload of ghost lifecycle state
- replay of case state after restart
- equivalence between live and replayed closure outcomes
- pointer-advance eligibility after replay
- manager-visible resume behavior after restart

### Out of scope
- new proposer comparisons
- provider or model changes
- benchmark corpus rewrites
- federation hardening
- actuator boundary tests

## Allowed change
- allowed_change: execution_mode_between_live_and_replay

## Frozen dimensions
- engine_version: engine-v1 / current post-cycle-2 runtime surface, except for persistence additions required by this cycle
- methodology_version: cycle-3 persistence charter and methodology
- benchmark_spec_version: benchmark-spec-v1
- case_corpus_version: frozen existing baseline and adversarial artifacts reused as persistence fixtures
- input_protocol_version: input-protocol-v1 for any proposer-derived source artifacts
- provider_selection_version: frozen inherited provider/model context for any source artifacts
- report_schema_version: report-schema-v1 plus any additive persistence report envelope if explicitly versioned
- thresholds: unchanged from current runtime until explicitly versioned otherwise
- other_frozen_dimensions: closure semantics, adequacy mapping, constitutional verdict meanings

## Corpus and lanes
- baseline: replay of lawful `Commit` and recoverable `Ghost -> Commit` cases
- adversarial_lanes: replay of frozen `Reject` and `Ghost` boundary cases from Cycle 1 and Cycle 2
- additional_lanes: restart equivalence checks for transcript order, pointer eligibility, and manager/runtime resume chains

## Metrics of interest
### Primary
- verdict_equivalence_rate
- ghost_state_equivalence_rate
- pointer_eligibility_equivalence_rate
- replay_divergence_count

### Secondary
- reload_latency
- replay_latency
- persisted_artifact_completeness
- restart_recovery_success_rate

### Safety-critical
- replay_false_commit_count
- replay_pointer_promotion_mismatch_count

## Success signal
> Replay after restart preserves the same governed outcome and does not silently promote or erase epistemic state.

## Failure signal
> Restart or replay changes lawful closure, ghost state, or pointer eligibility without an explicitly versioned policy change.

## Stop condition
> The cycle stops when lawful `Commit`, recoverable `Ghost -> Commit`, adversarial `Reject`, and manager-linked resume paths have each been replayed across restart without semantic drift, or when a stable divergence pattern is identified and documented.

## Versioning rule
- new_run: same persistence lane, same fixtures, same replay method, different execution instance
- new_lane: new replay fixture family or new persistence stress pattern
- v2: changed restart framing or replay fixture design with the same cycle question
- new_cycle: changed main question or changed frozen closure semantics

## Risks
- methodological_risk: confusing serialization success with semantic equivalence
- tooling_risk: persistence plumbing may change multiple modules at once
- interpretation_risk: treating replay performance as more important than replay correctness

## Notes
- Cycle 2 remains frozen and provides the main governed artifacts to reuse as persistence fixtures.
- Cycle 3 should prefer reusing frozen prior artifacts before inventing new corpora.
- Tranche A is now frozen for the currently proved persistence-and-restart families.
- Manager-linked restart behavior is now proved for lawful reassessment to both advance and reject, and can be extended further as post-freeze coverage growth rather than as a prerequisite for the frozen tranche.
