# Decision Note

## Identity
- template_family: v1
- cycle_id: cycle-3
- note_type: decision
- author: ubl-ops
- date: 2026-03-16
- status: partial_freeze

## Decision
> Freeze `Cycle 3` tranche A now. Keep the overall cycle open for broader coverage and any later extension work.

## Why this decision was taken

The current tranche has already established three important facts:

1. the epistemic runtime now has a real local persistent store
2. replay equivalence is already proved for a lawful `Ghost -> Commit` path
3. replay equivalence is already proved for an adversarial `Reject` path
4. manager-linked restart now preserves pending institutional consequence across reload
5. manager/runtime restart now preserves both lawful advance and lawful block after resumed reassessment

In addition, the four Stage 1 scenarios are now institutionalized as native Rust fixtures and replay-regression cases.

That is enough to freeze a coherent tranche.
It is not yet enough to claim that the whole `Cycle 3` question is closed.

## What is accepted now

The following are now accepted as valid frozen `Cycle 3` tranche A results:

- SQLite-backed persistence for graph, case state, and receipts
- replay seed loading and audit-bundle loading
- replay-equivalence reporting
- grounding visibility surviving persisted receipt replay
- manager resume behavior preserving pending `AdvancePointer`, `GhostPending`, and `EpistemicReject`
- manager/runtime restart equivalence for `GhostResolved -> ReevaluateEpistemicClosure -> AdvancePointer`
- manager/runtime restart equivalence for `GhostResolved -> ReevaluateEpistemicClosure -> EpistemicReject`
- Stage 1 scenario institutionalization in Rust

## Tranche A freeze statement

The following claim is now considered frozen:

> Persistence, restart, and rehydration preserve governed epistemic meaning for the principal operational families already tested: lawful advance, lawful block, and adversarial reject.

In practical terms, tranche A establishes that the workspace now preserves:

- epistemic state
- manager institutional state
- lawful `Ghost -> Commit` resumption
- lawful `Ghost -> Reject` resumption
- pending advance and pending block consequence across restart

## What is not yet accepted as complete

The following are still required before a full cycle freeze is justified:

- broader replay coverage across more than the current initial proof paths
- stronger linkage between persisted state and manager-facing resume flows beyond the currently proved restart chains
- final governed comparison and freeze language for the cycle package

## Operational consequence

Continue `TASKLIST-3.md`.

The next useful implementation directions now count as extension work, not prerequisites for the tranche that was just frozen:

1. broaden replay-equivalence coverage
2. strengthen pointer/head resume behavior where needed, especially for additional blocked and rejected restart families
3. then reassess freeze readiness

## Methodological note

This is an intentional partial freeze.

The goal is to preserve rigor:

- acknowledge the tranche that landed
- avoid overclaiming full-cycle closure
- keep the cycle’s memory honest while momentum remains high
