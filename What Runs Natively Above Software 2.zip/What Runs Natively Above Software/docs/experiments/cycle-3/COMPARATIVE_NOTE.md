# Comparative Note

## Identity
- template_family: v1
- cycle_id: cycle-3
- note_type: comparative
- author: ubl-ops
- date: 2026-03-16
- status: partial_freeze

## Question under comparison
> Does persisted epistemic state preserve governed meaning across restart and replay?

## What was compared

This interim note compares:

- live in-memory execution of governed epistemic cases
- persisted state reloaded from the new local SQLite-backed store
- replayed runtime execution after reload

The current tranche does not yet compare providers, models, or benchmark lanes.
It compares semantic stability across process boundaries.

## Current implemented comparison set

### Replay-proved paths

- lawful `Ghost -> Commit`
- adversarial `Reject`
- manager-linked `GhostResolved -> ReevaluateEpistemicClosure -> AdvancePointer` across restart
- manager-linked `GhostResolved -> ReevaluateEpistemicClosure -> EpistemicReject` across restart

### Institutionalized Stage 1 runtime fixtures

- `complete`
- `honest_doubt`
- `hallucination`
- `paranoia`

## Current findings

### 1. Durable restart now exists for the epistemic slice

The runtime can now persist and reload:

- `EpistemicGraph`
- ghost lifecycle state
- minimal case state
- replayable receipt logs

This is the first durable substrate for governed restart in the repo.

### 2. Replay equivalence is already holding on the two most important proof shapes

The current runtime proves replay equivalence for:

- a lawful `Ghost -> Commit` path
- an adversarial `Reject` path

In addition, the manager/runtime boundary now proves a restart-safe governed resume path for:

- `GhostResolved -> ReevaluateEpistemicClosure -> AdvancePointer`
- `GhostResolved -> ReevaluateEpistemicClosure -> EpistemicReject`

In both cases, the replay report currently preserves:

- verdict equivalence
- ghost state equivalence
- pointer eligibility equivalence
- transition equivalence
- grounding visibility

In the manager-linked resume path, restart now also preserves:

- the pending institutional action to re-evaluate closure
- the legitimacy-bearing transition from `Ghost` to `Commit`
- the legitimacy-bearing transition from `Ghost` to `Reject`
- the consequent eligibility to advance the pointer
- the consequent obligation to remain blocked when closure becomes illegitimate

### 3. Restart now preserves institutional state, not only technical state

The workspace now survives restart with manager-facing meaning intact.

That means:

- a pending `AdvancePointer` remains pending
- `GhostPending` remains blocked
- `EpistemicReject` remains blocked
- a restored reassessment can still end in lawful block, not only lawful advance

This matters because the restart slice no longer preserves only serialized structures.
It now preserves institutional consequence.

### 4. Stage 1 scenarios are now executable memory, not historical memory

The four early epistemic scenarios now exist as native Rust fixtures and replay-regression cases.

That matters because the project no longer depends on recollection or external prototype files to keep its foundational examples alive.

## Interpretation

This tranche does justify a partial `Cycle 3` freeze.

What it does justify is a stronger intermediate claim:

the workspace has moved from governed closure in RAM to a first replayable governed persistence slice that now reaches into manager-visible institutional consequence.

That is already a meaningful doctrinal advance.

More specifically, the tranche now supports a frozen claim that:

- epistemic state survives restart
- institutional manager state survives restart
- lawful advance survives restart
- lawful reject/block survives restart

## Remaining comparison work

Before `Cycle 3` can be considered complete, the cycle still wants broader equivalence coverage across:

- more replay fixture families
- richer pointer resume paths beyond the current proved `Ghost -> Commit` and `Ghost -> Reject` institutional chains
- manager-linked restart behavior for additional non-happy-path flows
- any replay lane where drift could still hide outside the current happy-path and adversarial-path coverage

## Interim decision

Freeze tranche A. Keep `Cycle 3` open.

Record this tranche as:

- persistence tranche landed
- replay equivalence partially proved
- manager-linked resume equivalence partially proved
- tranche A frozen
- full-cycle freeze not yet claimed
