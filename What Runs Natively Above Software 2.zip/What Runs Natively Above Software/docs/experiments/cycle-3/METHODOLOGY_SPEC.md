# Methodology Spec

## Identity
- template_family: v1
- methodology_id: cycle-3-persistence-equivalence-v1
- related_experiment_id: cycle-3
- author: ubl-ops
- date: 2026-03-16
- status: in_progress

## Objective
> Test whether persisted and replayed epistemic state preserves governed meaning across restart.

## Experimental design
- design_type: replay equivalence
- unit_of_analysis: persisted case state and replayed outcome
- comparison_axis: live_execution versus restart_replay_execution

## Inputs
### Case corpus
- corpus_id: frozen prior-cycle governed artifacts reused as replay fixtures
- source: `benchmarks/reports/` and replayable runtime state once persistence lands
- lane(s): lawful commit, recoverable ghost resolution, adversarial reject
- expected_verdict_classes: `CommitReady`, `RequiresEpistemicResolution`, `Rejected`

### Input protocol
- protocol_id: persistence-replay-protocol-v1
- format: persisted graph, ghost lifecycle, and transcript-adjacent state
- constraints: replay must not rewrite closure semantics
- normalization_rules: compare live and replayed outcomes using the same adequacy and closure logic

## System configuration
### Engine
- engine_version: engine-v1 with persistence additions introduced by this cycle
- relevant_modules: `epistemic-storage`, `proof-runtime`, `manager-plane`
- thresholds_policies: unchanged closure thresholds and verdict semantics

### Provider and model
- provider: inherited from frozen source artifacts when relevant
- model: inherited from frozen source artifacts when relevant
- snapshot: inherited from frozen source artifacts when relevant
- reasoning_effort: not the comparison axis in this cycle
- other_parameters: no new proposer behavior required for the core persistence proof

### Adapter
- adapter_version: adapter-v1 unless explicitly versioned otherwise
- structured_output_requirement: unchanged for reused source artifacts
- parse_rules: unchanged
- adequacy_rules: unchanged

## Run procedure
1. Select frozen governed fixtures from prior cycles.
2. Execute or reconstruct the live reference outcome.
3. Persist the epistemic and case state.
4. Restart, reload, and replay.
5. Compare verdicts, ghost state, pointer eligibility, and transcript ordering.

## Metrics
### Primary
- verdict_equivalence_rate
- ghost_state_equivalence_rate
- pointer_eligibility_equivalence_rate
- replay_divergence_count

### Secondary
- reload_latency
- replay_latency
- persisted_artifact_completeness
- restart_recovery_success_rate

## Reporting
- report_schema_version: report-schema-v1 unless an additive replay schema is introduced
- output_paths: `benchmarks/reports/cycle-3-*/`
- raw_output_retained: yes where source artifacts exist
- research_package_format: RO-Crate
- provenance_style: PROV-aligned partial fields
- software_metadata: CodeMeta

## Interpretation rules
### Examples
- If replay preserves verdicts, ghost states, and pointer eligibility, interpret as successful semantic persistence.
- If replay preserves bytes but changes governed outcomes, interpret as persistence failure, not success.
- If replay introduces false commit or pointer promotion mismatch, do not claim restart safety.

## Limitations
- This cycle depends on persistence implementation landing during the cycle.
- Early runs may use a small number of replay fixtures before broader coverage.
