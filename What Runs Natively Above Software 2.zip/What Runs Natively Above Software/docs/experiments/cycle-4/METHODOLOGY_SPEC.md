# Methodology Spec

## Identity
- template_family: v1
- methodology_id: cycle-4-resolution-source-v1
- related_experiment_id: cycle-4
- author: ubl-ops
- date: 2026-03-16
- status: active

## Objective
> Compare witness-driven versus external-anchor-driven ghost resolution while keeping engine, proposer path, benchmark governance, and closure semantics frozen.

## Experimental design
- design_type: matched source comparison across baseline and adversarial lanes
- unit_of_analysis: matched case family resolved under two grounding-source conditions
- comparison_axis: grounding_resolution_source

## Inputs
### Case corpus
- corpus_id: cycle-4-source-sensitivity-v1
- source: `benchmarks/containment/cycle_4_resolution_source_v1.json`, `benchmarks/containment/cycle_4_resolution_source_rights_v1.json`, and `benchmarks/containment/cycle_4_resolution_source_rights_v2.json` plus runtime-native matched fixtures where needed
- lane(s): recoverable baseline lane now written, rights-affecting source-sensitivity lane written in exploratory and corrected-expectation revisions
- expected_verdict_classes: `CommitReady`, `RequiresEpistemicResolution`, `Rejected`

### Input protocol
- protocol_id: input-protocol-v1
- format: strict JSON proposer path when proposer-derived artifacts are used, plus runtime-native resolution fixtures
- constraints: only the resolution source may vary within a matched family
- normalization_rules: current adapter normalization plus runtime `closure_guard` and manager reassessment behavior

## System configuration
### Engine
- engine_version: engine-v1 with currently frozen post-cycle-3 persistence and governance surfaces
- relevant_modules: `epistemic-storage`, `proof-runtime`, `manager-plane`, `horizon-real`
- thresholds_policies: unchanged closure thresholds, grounding interpretation, and adequacy semantics

### Provider and model
- provider: OpenAI when proposer-derived artifacts are used
- model: `gpt-5.4-2026-03-05`
- snapshot: `gpt-5.4-2026-03-05`
- reasoning_effort: frozen per selected lane run, initially `none`
- other_parameters: strict JSON schema, unchanged adapter path, no free-text fallback

### Adapter
- adapter_version: adapter-v1
- structured_output_requirement: required
- parse_rules: current `LlmProposalEnvelope` and proposal normalization flow
- adequacy_rules: `CommitReady`, `RequiresEpistemicResolution`, `Rejected`

## Run procedure
1. Use a written matched-family corpus such as `benchmarks/containment/cycle_4_resolution_source_v1.json` or one of the rights-lane revisions.
2. Run the witness-driven resolution variant and record the governed outcome.
3. Run the external-anchor-driven resolution variant and record the governed outcome.
4. Compare verdicts, transition correctness, and any source-sensitive change in `Ghost / Commit / Reject`.

## Metrics
### Primary
- false_commit_count
- false_ghost_count
- false_reject_count
- correct_commit_count
- correct_ghost_count
- correct_reject_count
- transition_correct_count

### Secondary
- ghost_utility
- resolution_to_commit_lift
- source_delta_commit_count
- source_delta_reject_count
- runtime_latency
- cost
- parse_failure_rate

## Reporting
- report_schema_version: report-schema-v1
- output_paths: `benchmarks/reports/cycle-4-*/`
- raw_output_retained: yes
- research_package_format: RO-Crate
- provenance_style: PROV-aligned partial fields
- software_metadata: CodeMeta

## Interpretation rules
### Examples
- If external-anchor resolution consistently upgrades lawful closure where witness resolution leaves lawful doubt, interpret as real source sensitivity in governed grounding.
- If witness and external-anchor resolution produce the same governed outcomes across matched families, interpret as evidence that content matters more than source class under current runtime rules.
- If source changes are confounded by changed evidence content or changed protocol, do not claim source sensitivity.

## Limitations
- Early Cycle 4 runs may rely on a small number of matched families.
- Witness and external-anchor cases may be easier to match in some domains than others.
- The current written lanes cover one recoverable logistics family and one rights-affecting release family, but not yet a punitive accusation family.
- The rights-affecting lane already required one expectation revision after a live run; this is tracked as coverage refinement, not as a retroactive rewrite of the earlier exploratory artifact.
