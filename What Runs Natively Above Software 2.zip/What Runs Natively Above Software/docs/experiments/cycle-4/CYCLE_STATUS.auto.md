# Cycle Status

## Identity
- cycle_id: cycle-4
- title: Resolution source sensitivity
- charter_status: in_progress
- methodology_status: active
- comparative_status: missing
- decision_status: missing
- verify_status: not_run

## Question
> Does the source of grounding resolution materially change governed closure behavior when all other dimensions are frozen?

## Current governed posture
> What was decided?

## Auto checks
- pre_cycle_checklist: ready
- canonical_completeness: PASS
- verification_trace: not_run

## Core docs
- [EXPERIMENT_CHARTER.md](./EXPERIMENT_CHARTER.md)
- [METHODOLOGY_SPEC.md](./METHODOLOGY_SPEC.md)
- [COMPARATIVE_NOTE.md](./COMPARATIVE_NOTE.md)
- [DECISION_NOTE.md](./DECISION_NOTE.md)
