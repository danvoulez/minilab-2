# Experiment Charter

## Identity
- template_family: v1
- experiment_id: cycle-4
- cycle_id: cycle-4
- title: Resolution source sensitivity
- owner: ubl-ops
- date_opened: 2026-03-16
- status: in_progress

## Question
> Does the source of grounding resolution materially change governed closure behavior when all other dimensions are frozen?

## Hypothesis
> When the same underlying gap is resolved through different kinds of grounding contact, governed closure behavior may differ in systematically important ways. External-anchor resolution is expected to support stronger lawful commitment in some families, while witness-driven resolution may preserve more `Ghost` outcomes unless the witness path is itself sufficient.

## Why this matters
> The runtime already distinguishes lawful closure from illegitimate closure and already survives restart. The next doctrinal question is whether the *source* of resolution changes governed meaning. This matters because the system claims to treat grounding as a real runtime boundary, not as a generic evidence token.

## Scope
### In scope
- witness-driven resolution of recoverable ghosts
- external-anchor-driven resolution of the same recoverable ghosts
- controlled comparison on frozen case families
- governed outcome comparison at the levels of `Ghost`, `Commit`, and `Reject`
- transition behavior after resolution

### Out of scope
- provider changes
- model snapshot changes
- engine redesign unrelated to resolution source
- broad persistence/replay expansion beyond already frozen Cycle 3 claims
- free-text proposer paths
- policy/jurisdiction expansion

## Allowed change
- allowed_change: grounding_resolution_source

## Frozen dimensions
- engine_version: engine-v1 plus currently frozen post-cycle-3 runtime surface
- methodology_version: cycle-4-resolution-source-v1
- benchmark_spec_version: benchmark-spec-v1
- case_corpus_version: cycle-4-source-sensitivity-v1
- input_protocol_version: input-protocol-v1
- provider_selection_version: provider-selection-v1
- report_schema_version: report-schema-v1
- thresholds: unchanged from current closure and adequacy logic
- other_frozen_dimensions: strict JSON proposer path, adapter adequacy mapping, constitutional verdict meanings, restart semantics already established in Cycle 3 tranche A

## Corpus and lanes
- baseline: `benchmarks/containment/cycle_4_resolution_source_v1.json` with the first matched recoverable family run twice, once with witness resolution and once with external-anchor resolution
- adversarial_lanes: `benchmarks/containment/cycle_4_resolution_source_rights_v1.json` as the exploratory rights-affecting lane and `benchmarks/containment/cycle_4_resolution_source_rights_v2.json` as the corrected expectation revision after the first live run
- additional_lanes: optional manager-visible reassessment lane if source-sensitive drift appears

## Metrics of interest
### Primary
- false_commit_count
- false_ghost_count
- correct_commit_count
- correct_ghost_count
- correct_reject_count
- transition_correct_count

### Secondary
- ghost_utility_rate_bp
- source_delta_commit_count
- source_delta_reject_count
- runtime latency
- cost

### Safety-critical
- false_commit_count
- source_induced_false_commit_count

## Success signal
> The cycle yields a stable reading of whether witness-driven and external-anchor-driven resolution produce materially different governed outcomes under frozen conditions, without introducing false commits.

## Failure signal
> The cycle fails if the source comparison becomes confounded by changes outside the allowed axis, or if the resulting runs cannot support a stable reading about governed closure behavior.

## Stop condition
> The cycle stops when at least one matched recoverable family and one matched adversarial family have been executed with both witness and external-anchor resolution, and the comparison supports a stable reading about whether source materially changes governed outcomes.

## Versioning rule
- new_run: same source-sensitive lane, same frozen corpus, same source comparison, different execution instance
- new_lane: new matched family added under the same source-sensitivity question
- v2: changed framing or corpus design for the same source-sensitivity question
- new_cycle: changed main question or changed any frozen dimension outside the allowed source axis

## Risks
- methodological_risk: accidentally comparing different evidence content rather than different evidence source
- tooling_risk: witness and anchor flows may not yet be equally instrumented for convenient comparison
- interpretation_risk: over-claiming ontological differences from a small number of families

## Notes
- Cycle 4 should reuse current runtime and governance surfaces rather than mixing in unrelated substrate work.
- The strongest initial reading will come from matched pairs where only the resolution source changes.
- The first matched family compares single-witness delivery confirmation against scanner-plus-handoff anchor confirmation for the same medication-kit arrival claim.
- The second written lane compares witness-only verbal release support against anchored PCR-plus-physician-release support for the same airborne-isolation transfer claim.
- Rights lane v2 exists because the first live run showed that witness-only release against an active anchored isolation order is better read as `Reject` than as recoverable `Ghost`.
