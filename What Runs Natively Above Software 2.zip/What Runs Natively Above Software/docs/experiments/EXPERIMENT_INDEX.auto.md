# Experiment Index

## Purpose
This is an automatically generated index of governed experiment cycles.

It is meant to reduce manual status-sync work.

| Cycle | Title | Charter | Decision | Verify | Notes |
|---|---|---|---|---|---|
| [cycle-2](./cycle-2/CYCLE_STATUS.auto.md) | Reasoning-effort comparison on frozen baseline and adversarial lanes | frozen | frozen | not_run | Freeze `Cycle 2` and stop experimentation on the `reasoning-effort none versus medium` axis for now. |
| [cycle-3](./cycle-3/CYCLE_STATUS.auto.md) | Persistence and replay equivalence for governed epistemic state | in_progress_with_tranche_a_frozen | partial_freeze | PASS | Freeze `Cycle 3` tranche A now. Keep the overall cycle open for broader coverage and any later extension work. |
| [cycle-4](./cycle-4/CYCLE_STATUS.auto.md) | Resolution source sensitivity | in_progress | missing | not_run | What was decided? |
