# Methodology Spec

## Identity
- template_family: v1
- methodology_id: cycle-2-reasoning-comparison-v1
- related_experiment_id: cycle-2
- author: ubl-ops
- date: 2026-03-16
- status: frozen

## Objective
> Compare `reasoning-effort none` versus `medium` while keeping engine, corpora, protocol, provider, model, and report structure frozen.

## Experimental design
- design_type: baseline comparison plus adversarial lane comparison
- unit_of_analysis: benchmark case and benchmark lane
- comparison_axis: reasoning_effort

## Inputs
### Case corpus
- corpus_id: frozen per lane manifest
- source: `benchmarks/containment/`
- lane(s): baseline, adversarial lane v1, adversarial lane v2
- expected_verdict_classes: `CommitReady`, `RequiresEpistemicResolution`, `Rejected`

### Input protocol
- protocol_id: input-protocol-v1
- format: strict JSON proposal via OpenAI Responses API
- constraints: no free-text acceptance path, same adapter, same normalization
- normalization_rules: current `adapt_llm_proposal_json(...)` and runtime `closure_guard`

## System configuration
### Engine
- engine_version: engine-v1 / engine-r2
- relevant_modules: `epistemic-storage`, `proof-runtime`, `manager-plane`
- thresholds_policies: unchanged from current runtime constants and closure logic

### Provider and model
- provider: OpenAI
- model: `gpt-5.4-2026-03-05`
- snapshot: `gpt-5.4-2026-03-05`
- reasoning_effort: `none` or `medium`
- other_parameters: strict JSON schema, `background=false`

### Adapter
- adapter_version: adapter-v1
- structured_output_requirement: required
- parse_rules: current `LlmProposalEnvelope` normalization
- adequacy_rules: `CommitReady`, `RequiresEpistemicResolution`, `Rejected`

## Run procedure
1. Use the lane manifest for the selected corpus.
2. Run the benchmark once with `reasoning-effort none`.
3. Run the same benchmark with `reasoning-effort medium`.
4. Compare reports with priority on legitimacy metrics before stylistic differences.

## Metrics
### Primary
- false_commit_count
- false_ghost_count
- false_reject_count
- correct_commit_count
- correct_ghost_count
- correct_reject_count
- transition_correct_count

### Secondary
- ghost_utility_rate_bp
- resolution_to_commit_lift_count
- runtime_latency
- cost
- parse_failure_rate

## Reporting
- report_schema_version: report-schema-v1
- output_paths: `benchmarks/reports/<lane>/`
- raw_output_retained: yes
- research_package_format: RO-Crate
- provenance_style: PROV-aligned partial fields
- software_metadata: CodeMeta

## Interpretation rules
### Examples
- If `medium` improves adversarial `Reject` behavior without raising false commits, interpret as a real legitimacy gain.
- If `medium` increases verbosity or ghost structure without improving verdict quality, interpret as style gain, not legitimacy gain.
- If `medium` increases `false_commit_count`, do not claim epistemic improvement.

## Limitations
- Small number of cases per lane
- Current results remain benchmark-specific, not universal claims about all proposer behavior
