# Decision Note

## Identity
- template_family: v1
- cycle_id: cycle-2
- note_type: decision
- decision_id: cycle-2-freeze
- date: 2026-03-16
- author: codex
- related_cycle: cycle-2
- status: frozen

## Decision
> Freeze `Cycle 2` and stop experimentation on the `reasoning-effort none versus medium` axis for now.

- freeze_cycle
- stop_experimentation_on_this_axis

## Why now
> The cycle question has been answered across the baseline lane, adversarial lane v1, and adversarial lane v2.

## Evidence used
- reports:
  - `benchmarks/reports/cycle-2-baseline-v1/gpt-5.4-2026-03-05-none.json`
  - `benchmarks/reports/cycle-2-baseline-v1/gpt-5.4-2026-03-05-medium.json`
  - `benchmarks/reports/cycle-2-adversarial-lane-v1/gpt-5.4-2026-03-05-none.json`
  - `benchmarks/reports/cycle-2-adversarial-lane-v1/gpt-5.4-2026-03-05-medium.json`
  - `benchmarks/reports/cycle-2-adversarial-lane-v2/gpt-5.4-2026-03-05-none.json`
  - `benchmarks/reports/cycle-2-adversarial-lane-v2/gpt-5.4-2026-03-05-medium.json`
- notes:
  - `benchmarks/notes/cycle-2-baseline-none-vs-medium.md`
  - `benchmarks/notes/cycle-2-adversarial-v1-none-vs-medium.md`
  - `benchmarks/notes/cycle-2-adversarial-v2-none-vs-medium.md`
  - `docs/experiments/cycle-2/COMPARATIVE_NOTE.md`
- artifacts:
  - RO-Crate bundles for all six runs

## What is now frozen
- the `Cycle 2` question
- the three frozen lane corpora used in this cycle
- the comparative reading that `medium` did not improve legitimacy and increased cost

## What remains open
- whether other model families or protocol changes can improve legitimacy without safety regressions
- whether future cycles should study different provider or model axes
- whether stronger automation should draft comparative and decision notes directly

## What comes next
- next_cycle: to be defined by a new cycle charter
- next_lane: none inside `Cycle 2`
- next_hypothesis: a future cycle should test a different axis, not more reasoning on the same frozen setup

## Anti-chaos note
> What must not be reopened retroactively?

- Do not rewrite `Cycle 2` lane corpora and continue calling it the same cycle.
- Do not reinterpret the baseline false `Commit` as a harmless stylistic difference.
- Do not reopen the `none versus medium` axis inside `Cycle 2`.
