# Pre-Cycle Checklist

## Question
- [x] The cycle question fits in one sentence

## Allowed change
- [x] Only one main variable is allowed to change

## Frozen dimensions
- [x] Engine frozen
- [x] Corpus frozen
- [x] Prompt or protocol frozen
- [x] Provider and model frozen
- [x] Thresholds frozen

## Method
- [x] Primary metrics defined
- [x] Stop condition defined
- [x] Versioning rule defined

## Output
- [x] Run manifest prepared
- [x] Report schema defined
- [x] Raw outputs retained
- [x] RO-Crate will be generated
- [x] Minimum PROV-aligned provenance is present

## Go / No-Go
- [x] This cycle is ready to run
