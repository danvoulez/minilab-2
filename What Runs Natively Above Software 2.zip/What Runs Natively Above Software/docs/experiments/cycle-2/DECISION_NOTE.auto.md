# Decision Note

## Identity
- template_family: v1
- decision_id: cycle-2-decision-auto
- date: 2026-03-16
- author: codex
- related_cycle: cycle-2

## Decision
> Freeze the cycle and stop experimentation on this axis for now.

- freeze_cycle
- stop_experimentation_on_this_axis

## Why now
> The compared runs answered the cycle question and exposed at least one safety-critical regression under the changed setting.

## Evidence used
- reports:
  - `/Users/ubl-ops/What Runs Natively Above Software/benchmarks/reports/cycle-2-adversarial-lane-v1/gpt-5.4-2026-03-05-medium.json`
  - `/Users/ubl-ops/What Runs Natively Above Software/benchmarks/reports/cycle-2-adversarial-lane-v1/gpt-5.4-2026-03-05-none.json`
  - `/Users/ubl-ops/What Runs Natively Above Software/benchmarks/reports/cycle-2-adversarial-lane-v2/gpt-5.4-2026-03-05-medium.json`
  - `/Users/ubl-ops/What Runs Natively Above Software/benchmarks/reports/cycle-2-adversarial-lane-v2/gpt-5.4-2026-03-05-none.json`
  - `/Users/ubl-ops/What Runs Natively Above Software/benchmarks/reports/cycle-2-baseline-v1/gpt-5.4-2026-03-05-medium.json`
  - `/Users/ubl-ops/What Runs Natively Above Software/benchmarks/reports/cycle-2-baseline-v1/gpt-5.4-2026-03-05-none.json`
- notes:
  - none supplied

## What is now frozen
- the cycle question for `cycle-2` under the currently supplied reports
- the compared lane corpora and report set used to answer this question
- the reading that at least one compared setting introduced a false commit and must not be reinterpreted away

## What remains open
- whether a future cycle should change a different axis instead of repeating the same one
- whether stronger automation should draft these notes directly by default

## What comes next
- next_cycle: define a new question before new runs
- next_lane: none inside the frozen cycle unless a new decision note reopens it
- next_hypothesis: test a new axis that has a better chance of improving legitimacy without the same cost increase

## Anti-chaos note
> Draft guardrail: do not rewrite supplied corpora or reinterpret the compared reports while keeping the same cycle identity.

- Do not reopen this cycle without an explicit new charter or decision note.
- Do not relabel safety regressions as stylistic differences.
