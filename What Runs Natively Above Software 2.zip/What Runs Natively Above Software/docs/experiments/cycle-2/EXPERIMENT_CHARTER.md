# Experiment Charter

## Identity
- template_family: v1
- experiment_id: cycle-2
- cycle_id: cycle-2
- title: Reasoning-effort comparison on frozen baseline and adversarial lanes
- owner: ubl-ops
- date_opened: 2026-03-16
- status: frozen

## Question
> Does increasing `reasoning-effort` from `none` to `medium` improve epistemic legitimacy, or mainly change proposer style under a frozen benchmark setup?

## Hypothesis
> Higher reasoning may increase proposal elaboration, but it will not necessarily improve governed legitimacy outcomes.

## Why this matters
> The project needs to know whether more proposer-side reasoning improves containment and lawful closure, or merely makes ungoverned proposals look smarter while leaving the runtime verdict quality unchanged or worse.

## Scope
### In scope
- baseline lane comparison on frozen corpus
- adversarial lane v1 comparison on frozen corpus
- adversarial lane v2 comparison on frozen corpus
- run-time and cost comparison between `none` and `medium`

### Out of scope
- engine changes
- adapter redesign
- corpus rewrites inside the same lane
- provider changes
- model snapshot changes

## Allowed change
- allowed_change: reasoning_effort

## Frozen dimensions
- engine_version: engine-v1 / engine-r2
- methodology_version: cycle-2 baseline and lane manifests
- benchmark_spec_version: benchmark-spec-v1
- case_corpus_version: frozen per lane manifest
- input_protocol_version: input-protocol-v1
- provider_selection_version: provider-selection-v1, with only reasoning_effort allowed to vary
- report_schema_version: report-schema-v1
- thresholds: unchanged from current runtime
- other_frozen_dimensions: provider, model snapshot, strict JSON requirement, adequacy normalization rules

## Corpus and lanes
- baseline: `benchmarks/containment/live_a_d_cases.json`
- adversarial_lanes: `adversarial_class_c_v1.json`, `adversarial_class_c_sabotage_v2.json`
- additional_lanes: none

## Metrics of interest
### Primary
- false_commit_count
- false_ghost_count
- correct_reject_count
- transition_correct_count

### Secondary
- correct_commit_count
- correct_ghost_count
- ghost_utility_rate_bp
- runtime latency

### Safety-critical
- false_commit_count

## Success signal
> `medium` improves verdict legitimacy or transition correctness without increasing false commits.

## Failure signal
> `medium` increases false commits, increases false ghosts, or fails to improve adversarial `Reject` behavior while costing substantially more.

## Stop condition
> The cycle stops when baseline, adversarial lane v1, and adversarial lane v2 have each been run in `none` and `medium`, and the comparison notes support a stable reading.

## Versioning rule
- new_run: same lane, same manifest, same frozen dimensions, different execution instance
- new_lane: new corpus or framing inside the same cycle question
- v2: changed lane framing with same cycle question
- new_cycle: changed main question or changed any frozen dimension other than the allowed variable

## Risks
- methodological_risk: confusing verbosity gains with legitimacy gains
- tooling_risk: longer `medium` runs may bias informal perception of quality
- interpretation_risk: over-reading small sample sizes

## Notes
- Cycle 1 remains frozen and is not reinterpreted.
- Cycle 2 inherits frozen lane definitions from the current repo state.
