# Cycle 4 Candidates

## Purpose
This note proposes small, clear next-cycle questions.

The goal is to preserve the discipline that now exists:

- one main question per cycle
- frozen dimensions before measurement
- no mixing of infrastructure changes with question changes

## Candidate A
### Title
Manager-visible replay coverage for full Stage 1 families

### Main question
> Does manager-visible institutional meaning remain stable across restart for the full Stage 1 scenario battery, not only for the currently proved central families?

### Why this might be worth a cycle
This is the strongest case for staying near `Cycle 3` while still asking a genuinely new question.
It turns Stage 1 from replay-regression in the runtime into manager-facing governed replay memory.

### Good if we want
- more confidence in the same doctrinal axis
- broader coverage without changing substrate
- a clean bridge between foundational examples and institutional restart behavior

## Candidate B
### Title
Resolution source sensitivity

### Main question
> Does the source of grounding resolution materially change governed closure behavior when all other dimensions are frozen?

### Comparison axis
- witness-driven resolution
- external-anchor-driven resolution

### Why this might be worth a cycle
This would move the work from persistence into epistemic boundary behavior.
It asks whether different kinds of contact with reality affect `Ghost / Commit / Reject` outcomes in systematically important ways.

### Good if we want
- a new question without changing provider/model benchmark setup
- more contact with the theory of grounding
- a cycle that is adjacent to `horizon-real`

## Candidate C
### Title
Institutional drift under resumed branching

### Main question
> When a case restarts from a branch-heavy or multiply blocked state, does the manager preserve the same lawful next action, or does resumed orchestration introduce institutional drift?

### Why this might be worth a cycle
This keeps the persistence theme but asks a meaningfully harder orchestration question than tranche A.
It would test whether restart stability holds beyond the principal linear families.

### Good if we want
- a harder manager-plane question
- stronger institutional replay guarantees
- a more orchestration-heavy cycle without changing the larger benchmark stack

## Current recommendation
If we open a new cycle now, the strongest starting candidate is:

1. Candidate B if we want a genuinely new epistemic question
2. Candidate A if we want one more foundational confidence-building cycle close to `Cycle 3`
3. Candidate C if we want the hardest manager-plane extension next
