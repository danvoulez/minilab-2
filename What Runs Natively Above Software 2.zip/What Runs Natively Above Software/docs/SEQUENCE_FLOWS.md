# Sequence Flows

## Purpose

These flows summarize the canonical process paths without requiring a full read of the RFC corpus.

They are operational summaries, not replacements for the constitutional documents.

## 1. Proposal To Epistemic Evaluation

1. a case enters through `ManagerInput::Event`
2. the manager delegates or schedules the next admissible work
3. the runtime evaluates a proposal or epistemic closure path
4. the runtime emits `EpistemicClosureEvaluated`
5. the manager does not advance on evaluation alone

Result:

- `Commit` is not inferred from evaluation visibility alone

## 2. Honest Gap To Ghost

1. a conclusion is evaluated with partial support
2. the runtime returns a non-commit epistemic result
3. if doubt policy requires preservation, a ghost is present or spawned
4. the manager blocks advancement

Result:

- the system preserves recoverable absence rather than pretending completion

## 3. Ghost To Witness Or Anchor To Re-evaluation To Commit

1. a ghost remains open in the closure lineage
2. witness or external anchor support arrives
3. the runtime resolves the ghost and emits `GhostResolved`
4. the manager emits `ReevaluateEpistemicClosure`
5. the runtime executes `ReassessClosure`
6. the runtime emits `EpistemicClosureTransition`
7. the manager advances the pointer only if the transition goes to `Commit`

Result:

- resolution and closure remain distinct

## 4. Evaluation Without Commit

1. the runtime emits `EpistemicClosureEvaluated`
2. the manager records the receipt
3. the manager remains idle or blocked depending on the verdict
4. no pointer advance occurs

Result:

- evaluation is visible, but not final

## 5. Transition To Commit

1. the runtime emits `EpistemicClosureTransition`
2. the manager checks `to_verdict`
3. if `to_verdict == Commit`, the manager emits `AdvancePointer`

Result:

- institutional motion depends on explicit requalification of closure

## 6. Federated Fork Preservation

Canonical target flow for later hardening:

1. an incompatible head is received
2. the system preserves the fork as explicit object
3. anti-rewind checks prevent silent overwrite
4. policy, proof, and witness govern later acceptance or refusal

Result:

- disagreement becomes explicit state, not hidden overwrite

## 7. Jurisdiction-Bearing Finality

1. a consequence-bearing case approaches final action
2. jurisdiction checks evaluate signer authority and consequence class
3. missing accountable authority blocks lawful finality
4. `horizon-real` refuses irreversible actuation without lawful closure

Result:

- no silent move from advisory computation to real-world consequence

## Summary Rule

Across all flows, the workspace enforces the same pattern:

- runtime executes
- contract governs
- manager coordinates
- transcript records
- jurisdiction authorizes
- horizon-real refuses irreversible consequence without lawful closure
