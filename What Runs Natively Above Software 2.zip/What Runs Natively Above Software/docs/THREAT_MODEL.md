# Threat Model

## Purpose

This document states what the workspace is defending against at the operational level.

The threats here include both hostile attacks and structural failure modes.

In this architecture, a bug that silently promotes advisory output into consequence can be as important as an external attacker.

## Protected Assets

The workspace primarily protects:

- lawful pointer advancement
- transcript integrity
- proof pack integrity
- signer and authority legitimacy
- explicit witness and anchor paths
- consequence-bearing finality
- preservation of doubt, dissent, and suspension

## Architectural Assumptions

The threat model assumes:

- offices remain constitutionally separated
- lower-law crates do not depend upward
- runtime progress remains transcript-visible
- final consequence requires explicit lawful closure

If those assumptions are broken, many protections weaken at once.

## Threat Classes

### 1. Silent pointer overwrite

Threat:

- a new head replaces an incompatible old head without explicit fork handling

Impact:

- history is rewritten without visible conflict

Mitigation direction:

- explicit fork objects
- anti-rewind checks
- acceptance separated from reception

### 2. Replay or rewind

Threat:

- stale proof or old head is presented as current authority

Impact:

- invalid state advance appears legitimate

Mitigation direction:

- append-only transcript events
- anti-rewind policy in federation
- explicit pointer height and prior head linkage

### 3. Well-formed but invalid proof pack

Threat:

- a structurally valid proof artifact lacks lawful support or complete transcript basis

Impact:

- formal appearance outruns actual legitimacy

Mitigation direction:

- verification against transcript and contract
- no acceptance by shape alone

### 4. Forged signer or authority

Threat:

- actor presents signature, role, or authority beyond lawful scope

Impact:

- consequence-bearing action occurs without accountable legitimacy

Mitigation direction:

- typed authority validation
- scope checks
- explicit signer and consequence linkage

### 5. UI acknowledgement masquerading as signature

Threat:

- superficial user interaction is treated as accountable human finality

Impact:

- irreversible action is taken without real jurisdiction-bearing authorization

Mitigation direction:

- explicit signer authority objects
- justification requirements
- no silent substitution of interface events for accountable signoff

### 6. Advisory output promoted to final action

Threat:

- model or worker output is treated as final authority without lawful closure

Impact:

- computation becomes consequence without governance

Mitigation direction:

- manager does not treat chat or proposer output as protocol authority
- runtime and manager require explicit transition before pointer advance
- jurisdiction and horizon-real remain downstream boundaries

### 7. Suppression of doubt or dissent

Threat:

- unresolved absence is hidden instead of recorded
- escalation or suspension paths are bypassed

Impact:

- false closure appears as orderly system behavior

Mitigation direction:

- ghost as first-class object
- explicit `if_doubt` handling
- closure transition separated from evidence arrival

### 8. Dependency inversion across offices

Threat:

- higher-consequence logic leaks downward into lower-law layers

Impact:

- foundational law becomes contaminated by policy or convenience

Mitigation direction:

- one-way crate dependency graph
- architecture review against constitutional office separation

### 9. Ghost laundering

Threat:

- a ghost is used as decorative notation while the process still advances as though the gap were resolved

Impact:

- structured absence exists on paper but not in governance

Mitigation direction:

- open critical ghosts block `Commit`
- `GhostResolved` does not itself advance the case
- re-evaluation remains mandatory

## Residual Risks In v0

The following risks remain material in the current version:

- epistemic graph state is still carried in-process rather than durably persisted
- witness and external anchor adapters are still thin
- cryptographic and transport hardening are not production-grade yet
- worker backends remain mock or thin execution slices

These are accepted v0 limitations, not hidden assumptions.

## Review Rule

Any change that weakens:

- transcript visibility,
- lawful transition boundaries,
- signer accountability,
- or explicit preservation of unresolved doubt

should be treated as a security-relevant architectural regression.
