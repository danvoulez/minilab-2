# Roadmap

## Purpose

This roadmap turns the current constitutional and epistemic status of the workspace into an execution order.

It does not change constitutional office separation.

It orders the next implementation passes so that:

- the epistemic loop becomes operational end to end,
- real proposer behavior is tested before large infrastructure expansion,
- persistence lands before federation and hardware hardening become too wide,
- and consequence-bearing boundary tests remain tied to lawful closure.

## Current Position

The workspace already has:

- the 10-crate constitutional stack,
- replay-first proof execution,
- typed governance and jurisdiction boundaries,
- and a minimal epistemic runtime that can represent absence, preserve doubt, resolve gaps, re-evaluate closure, and advance pointers only after explicit transition to `Commit`.

The next cycle is about public proof, persistence, and boundary hardening.

## Execution Order

### 1. Containment benchmark for unanchored inference

Artifact:

- benchmark harness using the protocol in `docs/BENCHMARK_PROTOCOL.md`
- baseline proposer outputs and guarded outputs
- command-backed and OpenAI Responses-backed strict-JSON proposer paths, plus persisted benchmark reports

Success criteria:

- false closure attempts are contained as `Ghost` or `Reject`
- missing support is named explicitly
- lawful `Commit` remains reachable after witness or anchor resolution

Why now:

- the proposal adapter base already exists
- the workspace now has a vendor-agnostic proposer seam and a runnable benchmark driver
- this is now the first public proof that the runtime governs model behavior rather than curated examples

### 2. Persistent atom and epistemic state

Artifact:

- persistent `AtomSpace`
- persistent `EpistemicGraph`
- durable ghost lifecycle

Success criteria:

- restart and replay preserve the same case state and closure result
- proof artifacts survive outside process memory

Why now:

- the doctrine requires immutable graphs and replayable state advances
- RAM-only epistemic state is still transitional

### 3. Direct witness and anchor adapters

Artifact:

- adapters from runtime witness flows and external anchors into persisted epistemic state
- direct feed into closure requalification

Success criteria:

- a witness or external anchor can resolve a ghost without test-only orchestration glue

Why now:

- this makes grounding a concrete runtime boundary rather than a thin fixture path

### 4. Sorrow test with dummy actuator

Artifact:

- local actuation boundary for consequence-bearing commands
- hard refusal without lawful closure and valid accountable signer authority

Success criteria:

- epistemically strong but jurisdictionally invalid commands never cross the boundary

Why now:

- the architecture becomes most legible where proof meets irreversible consequence

### 5. Federation hardening

Artifact:

- persisted fork artifacts
- clearer fork visibility and acceptance flow
- stronger anti-rewind and quorum witness handling

Success criteria:

- incompatible heads never overwrite silently
- fork resolution remains explicit, policy-bearing, and proof-bearing

Why now:

- federation remains important, but it should follow the first public epistemic proof

### 6. Real worker backend

Artifact:

- concrete bounded worker execution backend
- deterministic yield and resume under transcript control

Success criteria:

- workers remain subordinate to contract and transcript while running under a real backend

Why later:

- this is a second-wave hardening step, not the first public proof of epistemic control

## Supporting Documents

- `docs/EPISTEMIC_RUNTIME.md`
- `docs/BENCHMARK_PROTOCOL.md`
- `docs/ANATOMY_OF_A_GHOST.md`
- `docs/SEQUENCE_FLOWS.md`
- `docs/THREAT_MODEL.md`

## Exit Condition For This Cycle

This roadmap phase is successful when the workspace can demonstrate:

- a real proposer producing incomplete closure attempts,
- epistemic containment without silent promotion to authority,
- lawful requalification after witness or anchor arrival,
- durable replay of that process after restart,
- and consequence-bearing boundary refusal without accountable lawful closure.
