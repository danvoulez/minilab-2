# Implementation Status (Auto)

## Purpose
This file is generated from current workspace state.

It exists to reduce manual status-sync work.

Use [IMPLEMENTATION_STATUS.md](./IMPLEMENTATION_STATUS.md) for the strategic, human-written narrative.

## Workspace ledger
- governed_cycles_detected: 3
- frozen_cycles_detected: 1
- cycles_with_frozen_tranche_detected: 2
- cycles_with_pass_verify_trace: 1

## Automation surfaces detected
- new_cycle_scaffold: present
- refresh_cycle_governance: present
- verify_cycle_progress: present
- sync_experiment_docs: present

## Generated governed docs
- [docs/experiments/EXPERIMENT_INDEX.auto.md](./experiments/EXPERIMENT_INDEX.auto.md)
- [docs/experiments/cycle-2/CYCLE_STATUS.auto.md](./experiments/cycle-2/CYCLE_STATUS.auto.md)
- [docs/experiments/cycle-3/CYCLE_STATUS.auto.md](./experiments/cycle-3/CYCLE_STATUS.auto.md)
- [docs/experiments/cycle-4/CYCLE_STATUS.auto.md](./experiments/cycle-4/CYCLE_STATUS.auto.md)

## Cycle ledger
| Cycle | Charter | Decision | Verify | Auto status |
|---|---|---|---|---|
| [cycle-2](./experiments/cycle-2/CYCLE_STATUS.auto.md) | frozen | frozen | not_run | present |
| [cycle-3](./experiments/cycle-3/CYCLE_STATUS.auto.md) | in_progress_with_tranche_a_frozen | partial_freeze | PASS | present |
| [cycle-4](./experiments/cycle-4/CYCLE_STATUS.auto.md) | in_progress | missing | not_run | present |
