# ADR-0001: Boundary Law

## Decision

Use one first-class crate per constitutional layer from RFC-0001 through Paper 10.

## Rationale

The doctrine requires separation of offices. Crate boundaries are the first executable form of that law.

## Consequences

- Clear ownership of invariants.
- No generic `core/utils/platform` aggregation crate.
- Cross-layer calls must follow declared dependency direction.
