# ADR-0002: Dependency Direction

## Decision

Lower-law layers do not depend on higher-consequence layers.

## Rationale

Authority inversion would let consequence-bearing concerns influence foundational law and proof semantics.

## Consequences

- `constitution-gate` and `epistemic-storage` remain dependency roots.
- `horizon-real` depends on `jurisdiction` and `worker-abi`, never inverse.
- CI and review enforce acyclic crate graph.
