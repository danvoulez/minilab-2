# ADR-0003: Proof-First Execution

## Decision

Runtime progress is represented as typed steps that emit transcript events and proof artifacts.

## Rationale

The RFC corpus defines decision as process, not one-shot inference.

## Consequences

- Contracts produce `StepDecision` values.
- Runtime emits append-only events and terminal `ProofPack`.
- Economic and jurisdiction layers bind to transcript artifacts, not opaque output.
