# Implementation Status

This file is the strategic, human-written status note.

For the generated operational ledger, see [IMPLEMENTATION_STATUS.auto.md](/Users/ubl-ops/What%20Runs%20Natively%20Above%20Software/docs/IMPLEMENTATION_STATUS.auto.md).

## Implemented in v0

- Workspace with 10 constitutional crates.
- RFC-aligned public interfaces and core type systems.
- Thin executable slices:
  - Gate verdict flow and no-guess enforcement.
  - Proof runtime loop and proof pack emission.
  - In-memory atom CAS, heat transitions, pointer registry.
  - Minimal epistemic runtime with canonical cells, ghost records, grounding ratio, spawn omission detection, closure guard, and transcripted closure transitions.
  - Manager-side proposal adapter that parses and normalizes LLM-style JSON into `EpistemicGraph`, separates parse success from epistemic adequacy, and synthesizes explicit ghosts for recoverable unsupported claims.
  - Initial benchmark harness covering protocol classes A-D and reporting basic containment metrics over structured proposer output.
  - Vendor-agnostic proposer interface with mock, file-backed, command-backed, and OpenAI Responses-backed strict-JSON paths, plus a runnable containment benchmark driver that persists typed reports.
  - Automatic benchmark cycle/version tracking with per-dimension fingerprints, persisted revision registry, ISO 8601 timestamps, and PROV-style run metadata.
  - Research-artifact export as a minimal RO-Crate bundle for each benchmark run.
  - Draft automation for governance docs via a CLI example that generates `Comparative Note` and `Decision Note` markdown from versioned benchmark reports.
  - Validation automation for governed experiment docs via a CLI example that generates `Pre-Cycle Checklist` and `Canonical Completeness Check` markdown from charter, methodology, and manifest inputs.
  - Single-command governance refresh via `scripts/refresh_cycle_governance.sh`, which orchestrates the current cycle ritual without requiring the user to remember the CLI sequence.
  - Single-command cycle scaffolding via `scripts/new_cycle_scaffold.sh`, which opens a governed cycle package and valid manifest without manual folder choreography.
  - Single-command cycle verification via `scripts/verify_cycle_progress.sh`, which refreshes the governed package, runs evidence commands, and leaves a `VERIFY_STATUS.auto.md` trace.
  - Single-command experiment status sync via `scripts/sync_experiment_docs.sh`, which refreshes auto-generated cycle status snapshots and the workspace experiment index.
  - First live containment benchmark frozen as `Cycle 1` baseline with the canonical OpenAI-backed proposer lane on `gpt-5.4-2026-03-05`.
  - Frozen adversarial `Class C` lanes showing the transition from partial `Reject` emergence in lane `v1` to controlled `3/3 Reject` behavior in sabotage-focused lane `v2`.
  - `Cycle 2` frozen with governed charter, methodology, comparative note, decision note, and automated draft/validation companions.
  - `Cycle 3` opened as a governed persistence-and-replay equivalence cycle with charter, methodology, manifest, and automatic preflight/completeness validation, and now has tranche A partially frozen.
  - `Cycle 3` now also has a first durable persistence slice: SQLite-backed graph / case-state / receipt persistence, replay seed loading, replay audit bundle loading, and equivalence reports over governed runtime outcomes.
  - `Cycle 3` replay equivalence is already proved for a lawful `Ghost -> Commit` path and an adversarial `Reject` path.
  - `Cycle 3` now also proves manager-linked restart behavior: pending `AdvancePointer`, `GhostPending`, and `EpistemicReject` survive reload, and the chains `GhostResolved -> ReevaluateEpistemicClosure -> AdvancePointer` and `GhostResolved -> ReevaluateEpistemicClosure -> EpistemicReject` both survive restart end-to-end.
  - The four Stage 1 scenarios (`complete`, `honest_doubt`, `hallucination`, `paranoia`) are now institutionalized as Rust-native runtime fixtures and replay-regression cases.
  - Short type-hardening pass for case, contract, ghost, task, worker, and pointer-facing identities on the most sensitive runtime and manager boundaries.
  - Federation pointer acceptance with anti-rewind/fork visibility.
  - Worker yield/resume with explicit gas consumption.
  - Economic envelope hash chain and gas conservation checks.
  - Jurisdiction thresholding, authority validation, and finality controls.
- Physical interlock refusing irreversible command without lawful closure.
- End-to-end epistemic flow proving that pointer advance occurs only after explicit transition to `Commit`.
- Repository hygiene cleanup (macOS/export artifacts removed, archival RFC packaging consolidated).

See `docs/EPISTEMIC_RUNTIME.md` for the cross-crate epistemic slice and its current guarantees.
Operational planning and supporting specifications now live in:

- `docs/ROADMAP.md`
- `docs/BENCHMARK_PROTOCOL.md`
- `docs/ANATOMY_OF_A_GHOST.md`
- `docs/SEQUENCE_FLOWS.md`
- `docs/THREAT_MODEL.md`
- `docs/TYPE_HARDENING.md`
- `docs/EXPERIMENT_CYCLES.md`
- `docs/EXPERIMENTAL_GOVERNANCE_TRANSITION.md`
- `docs/IMPLEMENTATION_STATUS.auto.md`
- `docs/experiments/TEMPLATE_FAMILY_v1/`
- `docs/experiments/EXPERIMENT_INDEX.auto.md`
- `docs/experiments/cycle-2/`
- `docs/experiments/cycle-3/`

Benchmark run analyses now also live in:

- `benchmarks/notes/cycle-1-adversarial-v1-v2.md`
- `benchmarks/notes/cycle-2-design.md`
- `benchmarks/notes/cycle-2-baseline-none-vs-medium.md`
- `benchmarks/notes/cycle-2-adversarial-v1-none-vs-medium.md`
- `benchmarks/notes/cycle-2-adversarial-v2-none-vs-medium.md`

## Intentionally Deferred

- Full persistent storage and replication transport implementations.
- Distributed or replicated persistence beyond the new local SQLite slice.
- Signature cryptography and key management beyond typed contracts.
- Hardware-specific sandbox runtimes (WASM/WGPU executors).
- Domain policy packs and production observability pipelines.
- Robotics/device-control subsystems beyond boundary interlock contracts.

## Quality Gate Notes

- Clippy is enforced as `-D warnings`.
- `clippy::pedantic` was removed from workspace defaults in this pass to reduce noise and keep the quality gate focused on doctrinal correctness and concrete correctness defects.

## Next Steps

- Execute [`TASKLIST-3.md`](/Users/ubl-ops/What%20Runs%20Natively%20Above%20Software/TASKLIST-3.md) as the implementation tranche for the governed `Cycle 3` persistence-and-replay question.
- Extend replay equivalence from the current tranche A proof set to broader multi-fixture and non-happy-path flows.
- Record any additional `Cycle 3` persistence tranche gains in governed comparative and decision docs.
- Bind witness and external-anchor adapters more directly to closure requalification.
- Consider whether the next persistence cut should include richer pointer-head resume flows across `manager-plane`.
- Replace mock transports/interlocks with production adapters.
- Add formal model checking for selected invariants.
- Expand federated conflict resolution and quorum witness policies.
