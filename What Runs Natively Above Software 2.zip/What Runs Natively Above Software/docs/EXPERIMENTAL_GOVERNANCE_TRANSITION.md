# Experimental Governance Transition

## Purpose

This note records the transition from pre-governance experimental practice to the formal `Template Family v1` regime.

The goal is not to restart the project.
The goal is to preserve valid work, name the methodological gap honestly, and continue under stronger governance.

## What remains valid

The following remain valid and are not discarded:

- runtime architecture
- benchmark harness
- frozen benchmark artifacts
- Cycle 1 baseline and adversarial lane results
- Cycle 2 results already produced before this note
- empirical learnings already extracted from those runs

## What was missing

What was missing was not value.
What was missing was formal ex ante experimental governance through a stable template family and a canonical completeness check.

## Transition decision

From this point forward, new experimental cycles and lane extensions should use `Template Family v1`.

This means:

- stable experiment documents live under `docs/experiments/`
- run identity remains automated through manifests, fingerprints, reports, and RO-Crate packaging
- experimental documents are checked for canonical completeness
- past work is treated as pre-governance or transition-era evidence, not as invalid work

## Regime split

### Pre-governance / transition-era evidence

These artifacts remain usable evidence, but were produced before the template family was formally installed:

- Cycle 1 baseline
- Cycle 1 adversarial lane v1
- Cycle 1 adversarial lane v2
- early Cycle 2 comparisons produced before this transition note

### Governed line

The governed line begins here, with:

- `Template Family v1`
- explicit cycle charter and methodology documents
- canonical completeness checks
- continued automated manifests, reports, version registry, and RO-Crate output

## Policy

We do not restart everything from zero.

We preserve prior evidence, contextualize it honestly, and re-run only what is worth re-running under the stronger regime.

## Rule of interpretation

Past artifacts may still support technical and methodological claims when their context is made explicit.

What changes now is not the truth of the artifacts but the governance regime under which future artifacts are produced.
