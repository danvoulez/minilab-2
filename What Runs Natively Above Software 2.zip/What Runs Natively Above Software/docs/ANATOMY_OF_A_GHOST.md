# Anatomy Of A Ghost

## Purpose

`GhostRecord` is now a first-class operational object in the epistemic runtime.

This note defines what a ghost is, when it should appear, how it behaves, and how it affects closure and governance.

## Definition

A ghost is a typed record of structured absence that materially affects lawful closure.

It is not:

- a null marker,
- a cosmetic warning,
- a logging convenience,
- or a synonym for failure.

It exists so the system can preserve missing support without either hiding the gap or falsely converting the gap into presence.

## Current Runtime Form

The current `GhostRecord` carries:

- `id`
- `reason`
- `criticality`
- `opened_from`
- `required_for`
- `status`
- `resolution_ref`

This is the minimum stable operational form.

## Spawn Conditions

A ghost should be spawned when lawful closure cannot proceed without explicitly preserving a missing condition.

Current runtime-adjacent triggers include:

### 1. Insufficiency

Support is partial but not collapsed.

Example:

- a conclusion depends on an inference that still requires witness or external anchor support

### 2. Omission that should remain recoverable

There is a missing link that the process can still resolve through witness, anchor, or later evidence.

### 3. Active doubt policy

`if_doubt == SpawnGhost` turns unresolved doubt into a process obligation rather than silent continuation.

## Non-Spawn Cases

A ghost should not be used to hide states that should be rejected directly.

Examples:

- grounding collapses with no meaningful recovery path
- contradiction is severe and not recoverable under current policy
- the process attempts closure with no admissible support path and no preserved suspension

In such cases, `Reject` remains the correct outcome.

## Ghost Categories

The current implementation does not yet encode a full taxonomy, but the operational distinction should be:

### Omission ghost

A needed premise, bridge, or anchor is absent.

### Contradiction ghost

Material contradiction exists and must be resolved before lawful closure.

### Insufficiency ghost

Support exists but remains below the threshold or quality needed for closure.

## Criticality

The current runtime supports:

- `Low`
- `Medium`
- `High`

Operational meaning:

- `High` ghosts can block `Commit` when they remain open in the relevant lineage.
- lower criticalities can later support more nuanced policy, but are not yet richly differentiated in v0.

## Lifecycle

### Open

The missing condition is active and still affects closure.

### Resolved

A valid `resolution_ref` has been attached and the ghost no longer counts as open.

### Waived

Reserved for policy-bearing cases where the system explicitly permits non-resolution under declared law.

This state exists in the type surface but is not yet a major operational path.

## Resolution

A ghost is resolved when the runtime can attach a valid `resolution_ref`.

Current supported resolution sources:

- latest witness receipt
- latest external anchor receipt

Resolution also materializes a `Resolution` cell, which becomes part of the justificatory graph rather than closing the ghost by hidden mutation alone.

## Resolution Is Not Closure

This is the most important rule.

`GhostResolved` means the gap has received a candidate resolution.

It does not mean the case may advance.

After resolution:

1. the manager triggers re-evaluation
2. the runtime reassesses closure
3. only an explicit `EpistemicClosureTransition` can move the case toward lawful `Commit`

## Effect On Closure

Ghost state currently affects closure in these ways:

- open critical ghosts in the relevant lineage prevent direct `Commit`
- sufficiently grounded but unresolved cases tend toward `Ghost`
- collapse or structural omission can still force `Reject`

## Effect On Manager Behavior

The manager currently treats ghost state as governance-relevant:

- spawn-worthy doubt can create a `GhostRecord`
- open ghost conditions block advancement
- `GhostResolved` triggers `ReevaluateEpistemicClosure`
- pointer advance still waits for explicit transition to `Commit`

## Design Rule

The system must prefer:

- explicit ghost over silent omission
- explicit reject over fraudulent closure
- explicit transition over assumed legitimacy

That is the core function of the ghost object.
