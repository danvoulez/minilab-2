# What Runs Natively Above Software

Canonical Rust workspace for the 10-paper RFC corpus.

This repository encodes constitutional separation between:
- law (`constitution-gate`)
- proof process (`proof-runtime`)
- sovereign atom space (`epistemic-storage`)
- federation (`proof-federation`)
- non-chat governance (`manager-plane`)
- bounded labour (`worker-abi`)
- economic legibility (`economic-fields`)
- jurisdiction and signature (`jurisdiction`)
- office allocation doctrine (`efficiency-allocation`)
- physical boundary and entropy (`horizon-real`)

The repository is intentionally sparse and constitutional: it encodes law, proof, labour, economics, jurisdiction, and contact-with-the-real as separate executable offices.

## Principles

- Proof-bearing process over opaque inference.
- Replayability and transcript visibility over implicit state.
- Typed authority and consequence over silent automation.
- Bounded silicon and explicit yield over arbitrary I/O.

## Quick Start

```bash
just ci
```

or:

```bash
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace
```

## Current Operational Slice

The workspace is not only constitutional scaffolding.

It already contains a minimal operational epistemic path in which:

- closure can be evaluated explicitly,
- structured absence can be preserved as `GhostRecord`,
- witness or external anchor input can resolve epistemic gaps,
- closure must be re-evaluated after resolution,
- and pointer advance occurs only after explicit transition to `Commit`.

See:

- [`docs/EPISTEMIC_RUNTIME.md`](docs/EPISTEMIC_RUNTIME.md)
- [`docs/IMPLEMENTATION_STATUS.md`](docs/IMPLEMENTATION_STATUS.md)
- [`docs/ROADMAP.md`](docs/ROADMAP.md)

## Repository Layout

- `crates/`: constitutional crates (one per major layer).
- `rfcs/`: canonical split of the source doctrine (`0001` through `0010`) plus source monolith.
- `docs/`: architecture decisions, implementation status, and focused implementation notes such as the epistemic runtime slice.

## Toolchain Notes

- Minimum supported Rust version for the workspace API surface: `1.85`
- Pinned development and CI toolchain: `1.94.0`

This split is intentional for now:

- `Cargo.toml` records the minimum supported compiler contract
- `rust-toolchain.toml` pins a stable toolchain for local development and CI reproducibility

## Workspace Isolation

- This repository has its own `.git` root and its own workspace root `Cargo.toml`.
- It does not require or reference parent git or cargo workspaces.
- Builds and tests run from this repository root only.

## Dependency Direction

High-level rule: lower-law layers never depend on higher-consequence layers.

- `constitution-gate` is foundational.
- `proof-runtime` depends on `constitution-gate` + `epistemic-storage`.
- `horizon-real` may depend on `jurisdiction` and `worker-abi`; never the reverse.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the full directed graph.
