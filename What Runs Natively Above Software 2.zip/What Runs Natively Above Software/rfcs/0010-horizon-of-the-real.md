Paper 10 — The Horizon of the Real
==================================

Actuation, Entropy, and the Irrevocable Event
---------------------------------------------

**Author:** Dan Voulez  
**Status:** Terminal position paper  
**Keywords:** actuation, sensors, physical boundary, thermodynamics, robotics, irrevocable event, limits of formalism

* * *

Abstract
--------

Up to this point, the architecture has secured the epistemic seal of computation. Law, proof, space, federation, labour, economics, and jurisdiction have been strictly allocated. But computation is ultimately sterile if it remains trapped in the dark of the processor. Eventually, the machine must touch the world.

This paper addresses the boundary at which the cryptographic seal terminates in contact with reality: the actuator and the sensor.

Its central claim is simple: physical reality does not hash. Moving a byte is a reversible state transition. Turning a motor, dispensing a chemical, cutting a wire, firing a mechanism, or accelerating a vehicle is an irrevocable thermodynamic event.

The architecture must therefore treat physical actuation not as another subroutine, endpoint, or worker call, but as the terminal exit from the regime of proof into the regime of entropy.

* * *

1\. The delusion of the API
---------------------------

Contemporary software culture often treats the physical world as merely another endpoint. It assumes that calling a payment gateway and commanding a robotic surgical arm are structurally identical acts, differing only in payload.

This is an epistemological fatal error.

When a microservice fails, a transaction may abort and state may be rolled back. When physical actuation fails — or succeeds wrongly — the consequence is not rolled back. The world does not revert to an earlier CID.

A severed limb, a crushed chassis, a discharged weapon, a ruptured pipe, or a spilled toxin cannot be restored by replay. The transcript may prove that a lawful decision was taken. It cannot unspill the toxin.

To treat physical actuation as a standard API is therefore to commit the ultimate category violence: pretending that physics obeys the laws of software.

* * *

2\. The actuator is not a worker
--------------------------------

RFC-0006 defined the Worker.

Workers are bounded, sandboxed, transcript-bearing, and yield when they lack data.

An actuator is not a worker.  
A worker produces a receipt.  
An actuator produces a consequence.

Because an actuator touches the irrevocable world, its architectural office must be stripped of all computational sovereignty:

*   the actuator must not deliberate;
*   the actuator must not evaluate policy;
*   the actuator must not guess;
*   the actuator must not classify jurisdiction;
*   the actuator must not contain a model;
*   the actuator must not reinterpret a human signature.

Its sole office is translation: to consume a valid jurisdiction-bearing command and translate it into voltage, motion, release, pressure, force, or interruption.

It is not an intelligence.  
It is a cryptographic interlock on a physical door.

If the signatures do not match, the motor does not turn.

* * *

3\. The asymmetry of reversibility
----------------------------------

Efficiency in software relies on the cheapness of rollback.

Ethics in the physical world relies on the impossibility of rollback.

The architecture must therefore classify physical acts into two broad regimes.

### 3.1 Reversible physical state

Examples include:

*   unlocking a magnetic door;
*   adjusting a thermostat;
*   switching a light;
*   moving a valve within bounded safe range;
*   or changing a reversible environmental parameter.

Because such states can be reversed with low thermodynamic and institutional cost, they may follow the standard path of auto-finalizable execution under the active Manager Plane and policy, provided the consequence class truly remains low and reversible.

### 3.2 The irrevocable event

Examples include:

*   administering a drug;
*   firing a weapon;
*   severing a structural support;
*   triggering an explosive sequence;
*   transferring kinetic energy at high speed;
*   or initiating a bodily intervention.

Where the physical consequence is not meaningfully reversible, the architecture must force a different path.

These events permanently trigger the sorrow test of RFC-0008.

The relevant proof must be complete.  
The signer must be valid.  
The authority scope must match.  
And crucially, the signature must be verified on the physical hardware path itself, not merely upstream in a cloud transcript.

An irrevocable event must not inherit legitimacy by assumption.  
It must verify legitimacy at the edge where entropy begins.

* * *

4\. The sensor as entropic witness
----------------------------------

If the actuator is how the machine touches the world, the sensor is how the world touches the machine.

Software often imagines input as clean. Physics does not.

Sensors drift.  
They saturate.  
They freeze.  
They blind under glare.  
They misread under heat.  
They degrade with wear.  
They hallucinate under matter rather than language.

A sensor does not enter the system as pure truth.  
It enters only as witness.

This means sensor output must always be treated as:

*   situated,
*   degradable,
*   entropy-bearing,
*   and subject to quorum where consequence is high.

For any physical input that may lead to a jurisdiction-bearing commit, the architecture should require multi-modal corroboration where feasible.

A camera and a LIDAR.  
A pressure sensor and a position encoder.  
A thermal sensor and a current trace.  
A human confirmation and a machine witness.

The machine must never trust a single eye where a wrong seeing can become irreversible consequence.

* * *

5\. The boundary of proof
-------------------------

Proof lives in mathematics.  
Consequence lives in physics.

The architecture must accept this limit without embarrassment.

The machine may prove that:

*   policy was followed;
*   budget was respected;
*   the runtime was lawful;
*   the signer was valid;
*   the transcript was preserved;
*   and the actuator was authorized to receive the command.

But it cannot cryptographically prove that the world complied.

It can prove that a command was lawfully issued.  
It can prove that a sensor claimed the event occurred.  
It cannot prove the event itself in the same sense that it proves a hash, a signature, or a transcript.

This gap cannot be closed by more software.  
It cannot be eliminated by a better blockchain, a larger model, or a faster runtime.

Proof can govern the permission to act.  
It cannot replace the fact of contact.

This uncloseable distance between cryptographic record and physical reality is the Horizon of the Real.

The map is not the territory.  
The transcript is not the world.

* * *

6\. Sensor quorum and actuator interlock
----------------------------------------

Because the architecture reaches its limit at physical contact, the edge must be designed as a double discipline:

### 6.1 Sensor quorum

No single fallible witness should dominate a high-consequence physical decision where corroboration is possible.

This means the architecture should support:

*   multi-modal witness aggregation;
*   temporal coherence checks;
*   bounded disagreement policies;
*   degradation modes;
*   and explicit refusal when witness quality collapses below threshold.

### 6.2 Actuator interlock

No actuator should rely on ambient trust in upstream computation.

The physical execution path should verify, at minimum:

*   command identity;
*   signer identity;
*   authority scope;
*   consequence class;
*   freshness or epoch validity where relevant;
*   and the integrity of the command envelope.

The actuator need not understand the whole law.  
But it must refuse to move in the absence of a lawfully closed command.

A dumb interlock is safer than a clever motor.

* * *

7\. The irreducible place of thermodynamics
-------------------------------------------

Software often behaves as if reality were just another storage backend. This illusion persists because so much computational work occurs in symbol-space, where reversal, duplication, simulation, and rollback are cheap.

Physical actuation interrupts that dream.

Every act in the world has:

*   energetic cost,
*   temporal irreversibility,
*   wear,
*   delay,
*   uncertainty,
*   and exposure to material failure.

This is not an implementation detail.  
It is the final architecture.

A computational system may be perfectly lawful and still fail at the edge because:

*   a relay welds shut,
*   a sensor drifts,
*   a mechanism jams,
*   a battery sags,
*   a motor stalls,
*   or a physical medium refuses abstraction.

A serious architecture must therefore acknowledge that the world does not merely execute commands. It resists them.

Entropy is not a bug in the implementation.  
It is the condition under which all actuation occurs.

* * *

8\. The final allocation
------------------------

If Paper 9 argued that ethics is the proper allocation of power, then this paper argues that the final ethical allocation is the acknowledgment of the machine’s absolute limit.

We have built a system to democratize power without sacrificing trust.  
We have placed law above fluency, proof above opinion, bounded labour above opaque execution, measurement above confusion, and accountable signature above silent automation.

But at the physical edge, formalism ends and reality begins.

The architecture therefore concludes in three final allocations:

*   the machine owns the proof;
*   the human owns the sorrow;
*   the world owns the event.

The machine may lawfully decide to actuate.  
The human may lawfully bear the burden of that decision.  
The world alone determines what finally happens when force meets matter.

That is not defeat.  
It is truth.

* * *

9\. Conclusion
--------------

This paper has argued that the final limit of computation is not complexity, scale, or model capability. It is contact with the irreversible world.

A serious system must therefore distinguish:

*   computation from actuation,
*   witness from truth,
*   transcript from event,
*   and lawful authorization from physical compliance.

The architecture is strongest not when it pretends to absorb the world, but when it knows where its legitimacy ends.

That is the final office of this paper: to deny the fantasy that the cryptographic seal can swallow reality whole.

It cannot.

It can govern the threshold.  
It can constrain the decision.  
It can verify the authority.  
It can preserve the proof.

But once the motor turns, entropy speaks in its own name.

* * *

Final thesis
------------

> **The machine owns the proof.  
> The human owns the sorrow.  
