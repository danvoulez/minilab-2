RFC-0005 — Non-Chat Manager Plane
=================================

> **Status:** Normative draft.
> 
> This RFC defines the non-conversational management plane for proof-oriented systems, in which the manager is an event-driven semantic control plane rather than a chatbot disguised as an orchestrator.

Summary
-------

The correct manager does not converse in order to exist. It observes, decides admissible continuation, delegates work, requests evidence, governs budget, and consolidates sufficient proof for state advance.

Chat may survive as a surface for inspection, witness, and exception. It may not occupy the throne of the protocol.

If the manager is born as chat, it is born already compromised: state turns implicit, action drifts into free text, reasoning couples itself to interface, replayability weakens, and supervision becomes chaotic.

0\. Status
----------

Normative draft.

* * *

1\. Thesis
----------

The manager MUST NOT be modeled primarily as a chat interface.

The manager MUST be modeled as a machine of transitions that:

*   observes events and receipts;
*   maintains minimum operational context;
*   decides the next admissible step;
*   delegates work to specialized workers;
*   requests evidence when necessary;
*   escalates exceptions;
*   advances pointers when proof is sufficient.

Chat, when it exists, must be treated as a peripheral interface of:

*   supervision;
*   human witness;
*   inspection;
*   explicit override.

Central formulation:

Management is not conversation.  
Management is coordination under policy, budget, and proof.

* * *

2\. Objective
-------------

Define a manager plane in which:

*   inputs and outputs are typed;
*   the main loop is event-driven;
*   the LLM operates as an interpretive component, not opaque authority;
*   humans participate as governed exception;
*   every relevant transition remains replayable;
*   chat ceases to be the primary source of state and decision.

* * *

3\. Scope
---------

This RFC specifies:

*   the role of the manager;
*   the role of the LLM within the manager;
*   the role of workers;
*   the role of the human;
*   the model of events and commands;
*   the operational loop of the manager;
*   the primary non-chat operational UI;
*   integration with RFC-0001 through RFC-0004.

This RFC does not specify:

*   detailed conversational UX;
*   the specific internal algorithm of the LLM;
*   concrete distributed scheduling;
*   business policy for each domain;
*   final visual layout of the dashboard.

* * *

4\. Invariants
--------------

**I1 — Chat is not the primary plane**

The normal flow of the system may not depend on free-form conversation.

**I2 — Every relevant action is typed**

The manager must not emit critical operational commands in free text as the canonical form.

**I3 — The manager is not the worker**

The manager does not execute detailed work when that work can be delegated.

**I4 — The manager decides continuation**

Its central role is to decide whether the case should:

*   continue;
*   delegate;
*   request evidence;
*   escalate;
*   reject;
*   consolidate.

**I5 — The human is a governed exception**

The human enters as witness, arbiter, or explicit approver, never as invisible patch for structural failure of the system.

**I6 — Every relevant continuation leaves a trail**

Any managerial decision that changes case state must produce a replayable artifact.

* * *

5\. Mental model
----------------

The manager must not be understood as:

*   assistant;
*   chatbot;
*   generic conversational agent.

The manager must be understood as:

*   dispatcher;
*   scheduler;
*   workflow supervisor;
*   interpreter of operational policy;
*   arbiter of budget and evidence;
*   semantic controller of transitions.

* * *

6\. Boundaries of the manager
-----------------------------

The manager must do only these classes of work:

1.  interpret case state;
2.  choose the next admissible step;
3.  select the appropriate worker or expert;
4.  request missing evidence;
5.  control budget and risk;
6.  decide escalation;
7.  consolidate sufficient proof for pointer advance or terminal.

The manager must not:

*   hide critical reasoning in ephemeral context;
*   execute arbitrarily the tasks that belong to workers;
*   converse by default as if conversation were the protocol;
*   promote output to decision without passing through the previous RFCs.

* * *

7\. Manager inputs
------------------

The manager operates on typed events.

```
pub enum ManagerInput {
    Event(EventCid),
    Receipt(ReceiptCid),
    PointerAdvanced(StatePointer),
    BudgetTick(BudgetState),
    Deadline(DeadlineSignal),
    Witness(WitnessReceipt),
    ForkDetected(PointerFork),
    PolicyUpdate(PolicyCid),
}
```

### Semantics

*   `Event`: new operational fact.
*   `Receipt`: result of prior action.
*   `PointerAdvanced`: relevant change of head.
*   `BudgetTick`: budget update.
*   `Deadline`: time pressure.
*   `Witness`: typed external proof.
*   `ForkDetected`: federative conflict.
*   `PolicyUpdate`: change in the applicable law.

Free text must not be the primary input when a typed equivalent exists.

* * *

8\. Manager outputs
-------------------

```
pub enum ManagerOutput {
    Delegate {
        worker_id: String,
        task_cid: String,
    },
    RequestEvidence {
        cid: String,
    },
    LoadExpert {
        expert_id: String,
        input_set_cid: String,
    },
    Escalate {
        queue: String,
        reason_code: u32,
    },
    AskHumanWitness {
        witness_kind: String,
        prompt_cid: String,
    },
    AdvancePointer {
        alias: String,
        head_cid: String,
    },
    Reject {
        reason_code: u32,
    },
    NoOp,
}
```

### Rule

Every materially relevant managerial output must be serializable as atom, receipt, or persistable event.

* * *

9\. Role of the LLM
-------------------

The LLM is not the manager. It is a component of the manager plane.

It may be used to:

*   interpret imperfect context;
*   summarize dispersed state;
*   decompose goals into subtasks;
*   suggest viable strategies;
*   prioritize evidence;
*   recommend workers;
*   explain decisions after the fact.

It may not be treated as final authority over:

*   `commit`;
*   federative acceptance;
*   proof validity;
*   pointer integrity;
*   effective budget;
*   zero-guess domains.

Correct formula:

The LLM proposes continuation.  
The manager governs whether that continuation may lawfully proceed.

* * *

10\. Role of workers
--------------------

Workers are specialized executors.

```
pub trait Worker {
    fn id(&self) -> &str;
    fn capabilities(&self) -> Vec<String>;
    fn execute(&self, task_cid: &str) -> anyhow::Result<ReceiptCid>;
}
```

### Rules

*   a worker must be an executor of delimited task;
*   a worker does not advance global pointer without command or explicit policy;
*   a worker returns typed receipt;
*   a worker may be deterministic, heuristic, or hybrid, provided it enters the active proof regime.

* * *

11\. Role of the human
----------------------

The human is not the main loop.

The human is exception authority and governed witness.

The human may enter as:

*   binary witness;
*   textual or structured witness;
*   approver;
*   fork resolver;
*   authorizer of extra budget;
*   policy supervisor.

Every relevant human intervention must generate witness receipt.

* * *

12\. Chat as peripheral interface
---------------------------------

Chat remains permitted, but with restricted standing.

It may serve for:

*   case inspection;
*   explanation of current state;
*   response to witness requests;
*   explicit override;
*   debugging and postmortem.

It may not be:

*   the normal mechanism of dispatch;
*   a hidden repository of state;
*   the primary protocol between manager and worker;
*   the canonical channel of operational decision.

Chat is exception and observability, not the main bus.

* * *

13\. Operational model of the case
----------------------------------

The manager thinks in cases, not in conversation threads.

```
pub struct ManagedCase {
    pub case_id: String,
    pub state_root: String,
    pub current_head_cid: Option<String>,
    pub active_budget: BudgetState,
    pub pending_events: Vec<String>,
    pub pending_actions: Vec<String>,
    pub blocked_on: Option<BlockReason>,
}

pub enum BlockReason {
    WaitingForWorker,
    WaitingForEvidence,
    WaitingForHumanWitness,
    WaitingForBudget,
    WaitingForPolicy,
    WaitingForForkResolution,
}
```

The primary unit of operation is the case.  
Chat is only one of its possible surfaces.

* * *

14\. Manager event loop
-----------------------

```
pub trait ManagerPlane {
    fn ingest(&mut self, input: ManagerInput) -> anyhow::Result<()>;
    fn evaluate_next(&mut self, case_id: &str) -> anyhow::Result<ManagerOutput>;
}
```

### Normative semantics

Upon receiving new input, the manager must:

1.  append it to the observable state of the case;
2.  update the case status;
3.  verify budget and policy;
4.  decide the next admissible step;
5.  emit typed output or `NoOp`.

Critical reasoning must not remain only in ephemeral memory outside the transcript or the observable state of the case.

* * *

15\. Planning and decomposition
-------------------------------

When there is a broad goal, the manager may decompose it into subtasks.

```
pub struct PlanStep {
    pub step_id: String,
    pub task_cid: String,
    pub intended_worker: Option<String>,
    pub dependency_cids: Vec<String>,
}
```

### Rules

*   the plan must be representable as verifiable artifact;
*   a subtask does not execute without admissible budget and policy;
*   replanning is allowed, but must leave trail;
*   planning does not replace proof; it only organizes its production.

* * *

16\. Worker selection
---------------------

Choosing a worker is a materially relevant managerial decision.

```
pub struct WorkerSelection {
    pub worker_id: String,
    pub reason_cid: String,
    pub confidence_q16: u32,
}
```

### Rules

*   selection must consider capability, cost, risk, and policy;
*   it must not be irretrievably opaque when it changes relevant outcomes;
*   the manager may consult the LLM to suggest a selection;
*   final decision remains subordinate to gate, contract, and proof.

* * *

17\. Budget and managerial attention
------------------------------------

To manage is also to administer attention.

```
pub struct BudgetState {
    pub gas_remaining: u64,
    pub max_parallel_workers: u32,
    pub max_open_cases: u32,
    pub max_human_interrupts: u32,
}
```

### Rules

*   the manager must respect the operational budget of the case;
*   it may not open unlimited delegations;
*   it should prefer the lowest-cost resolution compatible with policy;
*   it may reject or escalate cases that exceed admissible budget.

* * *

18\. Manager receipts
---------------------

Managerial action itself must leave operational proof.

```
pub enum ManagerReceipt {
    Delegated {
        case_id: String,
        worker_id: String,
        task_cid: String,
    },
    EvidenceRequested {
        case_id: String,
        cid: String,
    },
    Escalated {
        case_id: String,
        queue: String,
        reason_code: u32,
    },
    HumanWitnessRequested {
        case_id: String,
        witness_kind: String,
        prompt_cid: String,
    },
    PointerAdvanced {
        case_id: String,
        alias: String,
        head_cid: String,
    },
    ManagerRejected {
        case_id: String,
        reason_code: u32,
    },
}
```

Every managerial action with effect on the case must produce a persistable receipt.

* * *

19\. UI model
-------------

The primary UI of the manager is not a text box.

It should privilege:

*   case queue;
*   timeline of events and receipts;
*   case state;
*   pending items;
*   consumed budget;
*   blocks;
*   active workers;
*   escalations;
*   forks;
*   advanced pointers.

Recommended screen models:

*   case queue;
*   case detail;
*   blocked cases;
*   pending human witnesses;
*   fork resolution board;
*   audit trail / replay inspector.

* * *

20\. Human interaction model
----------------------------

Human interactions must be typed.

Admissible examples:

*   confirm A/B;
*   fill a field;
*   approve or reject;
*   sign an exception;
*   select head in fork;
*   authorize budget increase.

Open conversation so that the system may "discover what to do" must not be the primary path in critical flows.

* * *

21\. Integration with RFC-0001
------------------------------

RFC-0001 continues to define the legitimacy of decision:

*   `Commit`, `Ghost`, `Reject`;
*   `epsilon`;
*   no-guess;
*   forbidden domains;
*   the law of budget.

The manager operates within that Constitution. Never above it.

* * *

22\. Integration with RFC-0002
------------------------------

RFC-0002 continues to define transcript and proof.

Every relevant managerial action must be able to enter the transcript as step, action, receipt, witness, or proof artifact.

* * *

23\. Integration with RFC-0003
------------------------------

RFC-0003 continues to define the ground of atoms.

Tasks, plans, prompts, receipts, outputs, witnesses, and proofs must be treated as content-addressed artifacts whenever they are materially relevant.

* * *

24\. Integration with RFC-0004
------------------------------

RFC-0004 continues to define federation.

Distinct managers may federate:

*   state pointers;
*   proof packs;
*   witness receipts;
*   fork decisions;
*   acceptance receipts.

The manager does not replace federation; it produces the artifacts that federation arbitrates.

* * *

25\. Failure modes
------------------

Conformant implementations must distinguish at least:

*   `worker timeout`;
*   `worker invalid receipt`;
*   `insufficient evidence`;
*   `policy violation`;
*   `out of budget`;
*   `blocked on human witness`;
*   `blocked on fork`;
*   `blocked on storage/materialization`;
*   `manager planning failure`.

These failures may not be summarized as "the model did not know how to answer."

* * *

26\. Semantic security
----------------------

The manager plane must resist these anti-patterns:

*   operational command in loose language without receipt;
*   critical state hidden in chat context;
*   delegation without trail;
*   escalation without typed reason;
*   approval without sufficient evidence;
*   silent merging of cases;
*   unrecorded human override.

* * *

27\. Minimum conformance
------------------------

An implementation is minimally conformant only if it:

*   uses typed events as the primary plane;
*   emits typed outputs;
*   treats chat as peripheral;
*   separates manager from worker;
*   records relevant managerial receipts;
*   operates by case, not by conversation thread;
*   respects budget and policy;
*   integrates with the transcript-and-proof regime of the prior RFCs.

* * *

28\. Suggested crate layout
---------------------------

```
manager_plane/
  src/
    lib.rs
    case.rs
    input.rs
    output.rs
    receipt.rs
    worker.rs
    human.rs
    budget.rs
    planner.rs
    loop.rs
    ui_model.rs
```

`lib.rs`:

```
pub mod budget;
pub mod case;
pub mod human;
pub mod input;
pub mod loop;
pub mod output;
pub mod planner;
pub mod receipt;
pub mod ui_model;
pub mod worker;
```

* * *

29\. Canonical flow
-------------------

### Normal case

1.  an `Event` enters;
2.  the manager evaluates the case;
3.  it emits `Delegate`;
4.  the worker returns `Receipt`;
5.  the manager reevaluates;
6.  it requests evidence or delegates a new step;
7.  when proof is sufficient, it advances pointer or terminates.

### Exceptional case

1.  an ambiguous or insufficient `Receipt` enters;
2.  the manager emits `AskHumanWitness`;
3.  the human responds;
4.  the witness becomes receipt;
5.  the case continues or is rejected.

### Federated case

1.  a remote pointer advances;
2.  `PointerAdvanced` enters;
3.  local policy evaluates the impact;
4.  if there is fork, the case blocks in `WaitingForForkResolution`;
5.  resolution generates new input and the flow proceeds.

* * *

30\. Normative mantra
---------------------

Management is not chat.  
Management is typed continuation.  
Chat is exception.  
Proof is memory.  
Policy is law.

Short form:

*   no chat-first control
*   no silent delegation
*   only events
*   only receipts
*   only governed steps

* * *

31\. Architectural verdict
--------------------------

This RFC closes the correct form of the manager.

From this point onward, `LLM as Manager` ceases to mean the fantasy of a chatbot with tools and comes to mean a semantic control plane, event-driven and governed by policy, budget, and proof. That is the difference between a talking interface and an operational institution that can be entrusted with consequence.

* * *

