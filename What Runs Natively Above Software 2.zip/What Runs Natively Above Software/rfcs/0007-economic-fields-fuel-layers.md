RFC-0007 — Economic Fields & Fuel Layers
========================================

> **Status:** Normative draft.
> 
> Subtitle: Gas as Trajectory.
> 
> This RFC consolidates the minimum economic layer of the kernel without prematurely introducing currency, wallet, or settlement as sovereign primitives.

Summary
-------

The transcript already preserves causality, work, authority, and expenditure. This RFC makes explicit that, once identity, contract, and cost enter the hashed chain, those same facts already constitute a primary economic ledger.

The economy, however, must be born in layers. The kernel measures. Economic readings derive. Control modulates. Currency, if it ever deserves to exist, must come later.

0\. Status
----------

Normative draft.

* * *

1\. Thesis
----------

Gas is not the currency.  
Gas is conserved work.

It is primary operational cost, physical fact of the runtime, and the minimum unit of verifiable economic trajectory.

By adding to the transcript the fields:

*   executor;
*   beneficiary;
*   gas\_cost;
*   contract\_hash;

...the system ceases to have merely an operational log and acquires Layer A of a sovereign economic ledger.

But the kernel must not collapse too early into monetary fantasy.

Credit, debt, reputation, valuation, compensation, and settlement belong to derived readings over verified trajectories of work, not to the core of the runtime.

* * *

2\. Layered model
-----------------

This RFC defines three explicit layers.

### Layer A — Operational Gas Ledger

Append-only, hash-chained, and verifiable.

It records:

*   who executed;
*   for whom it was executed;
*   under which contract;
*   how much gas was debited;
*   which semantic receipt was emitted.

This is the measurement layer: physical and observable facts, without embedded monetary interpretation.

### Layer B — Economic Interpretation

Derived, versionable, and queryable.

It produces:

*   relational balance;
*   open debt;
*   reciprocity;
*   reputation;
*   monetary, energy, or carbon valuation;
*   trust indices.

This is the layer of economic reading, not the layer of primary truth.

### Layer C — Control Pressure

Operational modulation layer.

It produces:

*   throttling;
*   routing;
*   circuit breaker;
*   escalation;
*   budget hardening;
*   modulated autonomy.

It interprets economic symptoms for the government of the system, without confusing control with currency.

* * *

3\. What this RFC actually does
-------------------------------

This RFC does only what is necessary to institute Layer A in the kernel:

1.  make the transcript economically identifiable;
2.  record per-step expenditure with executor and beneficiary;
3.  carry that expenditure inside the proof;
4.  permit later reconciliation and query.

It does not create token, wallet, or payment system.

* * *

4\. Invariants
--------------

**I1 — Gas is append-only**

No step expenditure may be altered retroactively once it enters the transcript.

**I2 — Economic identity is load-bearing**

`executor`, `beneficiary`, `gas_cost`, and `contract_hash` must form part of the canonical hashed shape of the transcript.

**I3 — Summary does not replace truth**

Any economic summary in `ProofPack` is a derived claim. The source of truth is the envelopes in the transcript.

**I4 — No wallet in the kernel**

The kernel stores no balance, account, wallet, transfer, or settlement as internal primitive.

**I5 — Gas conserves work**

For any valid `ProofPack`:

```
SUM(envelope.gas_cost) == initial_budget - budget_remaining
```

**I6 — Missing input downgrades certainty**

Derived layers must degrade precision or confidence when sufficient data are absent, rather than invent certainty.

* * *

5\. New primitive: `ReceiptEnvelope`
------------------------------------

```
pub struct ReceiptEnvelope {
    pub executor: NodeId,
    pub beneficiary: NodeId,
    pub gas_cost: u64,
    pub contract_hash: Hash,
    pub receipt: StepReceipt,
}
```

### Semantics of the fields

*   `executor`: who physically executed the step;
*   `beneficiary`: on whose behalf gas was consumed;
*   `gas_cost`: local cost of that transition;
*   `contract_hash`: normative authority under which the expenditure was permitted;
*   `receipt`: semantic payload of the step.

### Rule

`ReceiptEnvelope::canonical()` is the payload that enters the hash chain.

Economic fields are not analytics metadata.  
They are part of the proof.

* * *

6\. Economic session
--------------------

Every session now also exists as an economic relation:

`executor X` performing work for `beneficiary Y` under `contract Z`.

### Mandatory fields

*   `executor_id`;
*   `beneficiary_id`.

`SessionView` now also exposes:

*   `executor_id`;
*   `beneficiary_id`;
*   `initial_budget`;
*   `total_gas_spent`.

### Purpose

To permit future contracts that consider accumulated cost, economic autonomy, and the relation between executor and beneficiary without corrupting the kernel with premature monetary primitives.

* * *

7\. Economic transcript
-----------------------

```
pub struct TranscriptEntry {
    pub envelope: ReceiptEnvelope,
    pub prev_hash: Option<Hash>,
    pub entry_hash: Hash,
    pub budget_before: u64,
    pub budget_after: u64,
    pub state_root_before: Hash,
    pub state_root_after: Hash,
}
```

`TranscriptEntry` is the economic specialization of the `StepEvent` from RFC-0002.

### Critical rule

The chain is hashed over the envelope, not over the raw receipt.

Thus executor, beneficiary, contract, and cost enter the regime of truth of the transcript.

* * *

8\. Minimum additive API
------------------------

To preserve compatibility, this RFC recommends the following evolution.

### New mandatory method

```
append_envelope(envelope: ReceiptEnvelope)
```

### New preferred method

```
append_receipt_with_gas(receipt: StepReceipt, gas_cost: u64)
```

### Legacy method

```
append_receipt(receipt: StepReceipt)
```

The legacy method may survive as shim, but the official runtime must record cost explicitly.

* * *

9\. Reconciliation invariant
----------------------------

The runtime already debits budget in the loop. It must now guarantee that the `gas_cost` of the envelope is exactly the same cost debited in that transition.

### Verification rule

A conformant verifier must be able to prove:

```
sum(transcript_envelopes.gas_cost) == initial_budget - gas_remaining
```

This is the law of conservation of work in the system.

* * *

10\. Economic `ProofPack`
-------------------------

`ProofPack` must carry two levels.

### A. Source of truth

```
pub transcript_envelopes: Vec<ReceiptEnvelope>
```

### B. Summary claim

```
pub struct EconomicSummary {
    pub executor_id: NodeId,
    pub beneficiary_id: NodeId,
    pub total_gas_spent: u64,
    pub gas_remaining: u64,
    pub step_count: u64,
}
```

### Rule

`EconomicSummary` serves indexing, UI, and fast query. Real reconciliation remains the responsibility of the transcript of envelopes.

* * *

11\. What can be derived without changing the kernel
----------------------------------------------------

From the trajectory of envelopes, one may derive:

### 11.1 Relational balance

How much work one agent received minus how much it executed for others.

### 11.2 Debt

Trajectories in which A spent for B without observable later reciprocity.

### 11.3 Payment

Partial closure of debt by reciprocity of execution.

### 11.4 Reputation

Function over success of verification, failures, bounded divergence, and contractual compliance.

### 11.5 Valuation

Mapping of gas trajectory to readings such as estimated USD, energy, or carbon.

### 11.6 Control pressure

Application of policy over patterns of spend, retries, rejects, witness burden, and executor stress.

None of this requires altering the minimal ontology of the kernel.

* * *

12\. Relation to the layer of proposals
---------------------------------------

This RFC does not transform the runtime into a market of economic proposals.

It prepares the ground for that possibility:

*   the economic transcript supplies the facts;
*   Layers B and C produce snapshots, diffs, and packs;
*   manager and LLM may propose;
*   gate and contract continue deciding.

The economy remains subordinate to the same Constitution of the system.

* * *

13\. What this RFC explicitly does not do
-----------------------------------------

This RFC must not:

*   create token;
*   create wallet;
*   create `transfer op`;
*   create payment primitive;
*   create settlement protocol;
*   create table of balances in the kernel;
*   couple federation to monetary logic;
*   introduce economic consensus.

The transcript is already the primary ledger.  
Everything else is later reading.

* * *

14\. Errors of economic verification
------------------------------------

Recommended minimum vocabulary:

*   `GasReconciliationFailed`;
*   `EnvelopeExecutorMismatch`;
*   `EnvelopeContractMismatch`.

Optional future vocabulary:

*   `BeneficiaryPolicyViolation`;
*   `ValuationPrecisionDowngraded`;
*   `TrajectoryCycleMismatch`.

* * *

15\. Relation to the previous RFCs
----------------------------------

### RFC-0001

It continues to define legitimacy: `commit`, `ghost`, `reject`, contracted error, and the law of budget.

### RFC-0002

It continues to define transcript and proof. The transcript is now also economically identifiable.

### RFC-0003

It continues to define the sovereign space of atoms. Envelopes and summaries are artifacts like any others.

### RFC-0004

It continues to define federation. Economic interpretation of proofs occurs after federative acceptance.

### RFC-0005

It continues to define the non-chat manager. The manager may consume derived economic layers for routing, witness, and escalation.

### RFC-0006

It continues to define worker and sandbox. The cost of worker labor now enters the formal economic chain.

* * *

16\. Canonical queries
----------------------

### Query A — Conservation

```
SUM(gas_cost) == total_spent
```

### Query B — Reciprocal debt

```
sum(gas where executor=A and beneficiary=B)
-
sum(gas where executor=B and beneficiary=A)
```

### Query C — Trust by verification

```
verified_steps(node=X) / total_steps(node=X)
```

### Query D — Pressure by trajectory

```
base_gas * penalty(retries, rejects, latencies, witness_burden)
```

* * *

17\. Guiding sentence
---------------------

Gas is conserved work.  
Value is a query over verified trajectories of that work.

Necessary complement:

The transcript does not need a currency primitive to become economic. It only needs identity, authority, and conserved cost.

* * *

18\. Names of the three layers
------------------------------

Recommended nomenclature:

*   Layer A — Transcript Gas
*   Layer B — Trajectory Economics
*   Layer C — Control Pressure

* * *

19\. Implementation mandate
---------------------------

The kernel implements only:

*   `ReceiptEnvelope`;
*   economic identity of the session;
*   economic hashing of the transcript;
*   `EconomicSummary`;
*   reconciliation vocabulary.

Everything else remains outside the kernel.

* * *

Minimum conformance
-------------------

An implementation is minimally conformant only if it:

*   treats gas as append-only;
*   produces `ReceiptEnvelope` with per-step accounted gas;
*   separates Layer A from any derived reading of value;
*   makes economic reconciliation verifiable;
*   declares budget before execution and never permits silent overrun.

* * *

Suggested crate layout
----------------------

```
economic_fields/
  src/
    lib.rs
    envelope.rs
    session_econ.rs
    transcript_econ.rs
    summary.rs
    reconciliation.rs
```

* * *

Closing
-------

The correct next step is not to invent a currency.

The correct next step is to recognize that work is already being conserved, expenditure is already being debited, and proof is already being chained. What was missing was legibility.

If a currency is ever born, let it be born as a historical reading of verified trajectories of work, not as the premature superstition of the runtime.

* * *

