# RFC Corpus Index

## Source Preservation

- `0000-source-monolith.md`: original single-file corpus.
- `0001`–`0010`: canonical split for executable architecture linkage.
- The monolith is archived only here; repository root intentionally avoids duplicate doctrine files.

## Mapping to Crates

- `0001-constitution.md` -> `constitution-gate`
- `0002-decision-as-proof-process.md` -> `proof-runtime`
- `0003-sovereign-atom-space.md` -> `epistemic-storage`
- `0004-federation-proof-carrying-state.md` -> `proof-federation`
- `0005-non-chat-manager-plane.md` -> `manager-plane`
- `0006-sovereign-worker-abi-sandboxed-execution.md` -> `worker-abi`
- `0007-economic-fields-fuel-layers.md` -> `economic-fields`
- `0008-jurisdiction-duty-sorrow.md` -> `jurisdiction`
- `0009-efficiency-and-power.md` -> `efficiency-allocation`
- `0010-horizon-of-the-real.md` -> `horizon-real`

## Invariants and Tests

- Gate totality and no-guess behavior: `constitution-gate` unit tests.
- Transcript append-only and budget-binding: `proof-runtime` unit tests.
- Atom immutability and heat/page fault semantics: `epistemic-storage` unit tests.
- Anti-rewind and fork visibility: `proof-federation` unit tests.
- Yield/resume and bounded gas: `worker-abi` unit tests.
- Gas conservation and envelope hash chain: `economic-fields` unit tests.
- Signer authority and justification/quorum rules: `jurisdiction` unit tests.
- Actuation interlock + sensor quorum constraints: `horizon-real` unit tests.
- End-to-end typed flow: `horizon-real/tests/end_to_end.rs`.
