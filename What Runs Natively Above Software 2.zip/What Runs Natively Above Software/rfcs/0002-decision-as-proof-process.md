RFC-0002 — Decision as Proof Process
====================================

> **Status:** Normative draft.
> 
> This RFC succeeds earlier formulations of the same system and becomes the canonical reference for proof-oriented decision.

Summary
-------

This RFC declares that the system does not perform an inference and then attempt a justification. It executes an incremental proof process in which each transition consumes explicit budget, produces a verifiable receipt, and changes a state whose history can be reconstructed by third parties.

The final decision is not a magical moment. It is only the terminal of an auditable chain.

0\. Thesis
----------

The runtime is not the authority.  
The transcript is the authority.

The contract is not decorative normative text.  
The contract is the governing program.

An output does not count because it was produced.  
It counts only when it comes accompanied by sufficient, replayable, verifiable proof.

From this follow four fundamental consequences:

*   each case is a clean session;
*   each advance is transactional;
*   each cost is debited explicitly;
*   each terminal is a verdict sustained by transcript.

* * *

1\. Objective
-------------

Define a runtime in which:

*   each case begins without residual memory;
*   each admissible step is explicitly typed;
*   the contract is hashed, versioned, and executable;
*   external witnesses enter only through declared paths;
*   the final proof can be verified without trust in the original executor.

* * *

2\. Main semantic shift
-----------------------

In simpler formulations, the system operated with three direct states: `Commit`, `Ghost`, and `Reject`.

This RFC introduces a more rigorous model:

```
pub enum StepDecision {
    Commit,
    Continue(StepAction),
    Reject(RejectReason),
}
```

The reason is structural:

*   `Commit` remains terminal;
*   `Reject` remains terminal;
*   the intermediate state is not a mood of the system, but the next step of the protocol.

The name `Ghost` remains useful, but it should be reserved for classes of action or witness, not for the central axis of decision.

* * *

3\. Invariants
--------------

**I1 — Clean session**

Each case is born with:

*   `case_id`;
*   hashed contract;
*   initial budget;
*   initial inputs;
*   empty transcript.

No invisible cache across cases may participate in legitimacy.

**I2 — Every progression is transactional**

All evolution of the case occurs by means of a single `StepAction`, with:

*   cost;
*   receipt;
*   new state;
*   new `state_root`.

**I3 — Without transcript, there is no valid decision**

No terminal is legitimate without a verifiable event chain.

**I4 — Without hashed contract, there is no law**

Every session points to an explicitly identified contract.

**I5 — Without state root, history weakens**

Each transition must record the canonical summary of the subsequent state.

**I6 — Budget is binding**

If the next step exceeds the remaining budget, the system may not proceed.

* * *

4\. Boundary of the runtime
---------------------------

The runtime must do only four things:

1.  execute an atomic action;
2.  measure cost;
3.  emit a receipt;
4.  deliver the new state to the contract.

The runtime does not govern policy.  
It is a disciplined executor.

* * *

5\. Boundary of the contract
----------------------------

The contract must do only two things:

1.  validate the transcript and the current state;
2.  decide the next step or the terminal.

In short:

*   the runtime executes;
*   the contract governs.

That separation is the backbone of this RFC.

* * *

6\. Session state
-----------------

```
pub struct Session {
    pub case_id: String,
    pub contract_hash: String,
    pub proof_mode: ProofMode,

    pub initial_budget: u64,
    pub budget_remaining: u64,

    pub state_root: String,
    pub atoms: AtomStoreView,

    pub transcript_head: Option<String>,
    pub event_count: u64,

    pub current_proposal: Option<ProposalRef>,
}
```

### Notes

*   `Session` need not carry the full materialization in memory.
*   `atoms` may be a partial view, provided it is sufficient for the current decision.
*   `state_root` is the canonical summary of the case at that instant.
*   `current_proposal` is a reference to a verifiable artifact, never invisible magical state.

* * *

7\. Action types
----------------

Admissible actions must distinguish computation, materialization, and witness.

```
pub enum StepAction {
    Compute(ComputeAction),
    Materialize(MaterializeAction),
    Witness(WitnessAction),
}
```

### 7.1 `ComputeAction`

Purely computational and replayable action.

```
pub enum ComputeAction {
    Propose {
        proposer_id: String,
        input_set_cid: String,
    },
    RunExpert {
        expert_id: String,
        input_set_cid: String,
    },
    RecomputePath {
        derivation_cid: String,
    },
}
```

### 7.2 `MaterializeAction`

Rehydration, pagination, or explicit loading action.

```
pub enum MaterializeAction {
    RehydrateAtom {
        cid: String,
    },
    RetrieveEvidence {
        query_cid: String,
        top_k: u8,
    },
    LoadModule {
        module_id: String,
    },
}
```

### 7.3 `WitnessAction`

Acquisition of external, human, or environmental fact.

```
pub enum WitnessAction {
    AskUserBit {
        question_id: String,
        left: String,
        right: String,
    },
    AskUserField {
        field_id: String,
    },
    GetTime {
        oracle_id: String,
    },
    FetchExternalAtom {
        locator: String,
        expected_cid: Option<String>,
    },
}
```

Not every step is inference.  
Some steps are witnesses necessary to the legitimacy of the case.

* * *

8\. Cost and budget
-------------------

Every `StepAction` must carry explicit cost.

```
pub struct ActionCost {
    pub gas: u64,
}
```

Cost policy may be declared by the contract or calculated according to a table authorized by it.

```
pub trait Contract {
    fn eval_step(&self, session: &SessionView) -> StepDecision;
    fn cost_of(&self, action: &StepAction, session: &SessionView) -> ActionCost;
    fn determinism_profile(&self) -> DeterminismProfile;
}
```

`gate_run`, defined in RFC-0001, should be read as a concrete constitutional case of this abstract contract.

### Rule

Cost is debited before execution.

If there is insufficient balance, the result is:

*   `Reject(OutOfBudget)`

* * *

9\. Determinism profile
-----------------------

Every session must declare the exact regime under which it may be replayed.

```
pub struct DeterminismProfile {
    pub fixed_point_only: bool,
    pub allow_user_input: bool,
    pub allow_time_oracle: bool,
    pub allow_external_fetch: bool,
    pub wasm_abi_version: u32,
}
```

### Laws

*   no implicit clock;
*   no implicit entropy;
*   no implicit network;
*   every external source enters as `WitnessAction`;
*   every relevant computation must be replayable under the same profile.

What cannot be redone deterministically must appear as recorded witness.

* * *

10\. Chained transcript
-----------------------

The transcript is not a list; it is a hashed chain of state.

```
pub struct StepEvent {
    pub prev_event_cid: Option<String>,
    pub action_cid: String,
    pub receipt_cid: String,

    pub budget_before: u64,
    pub budget_after: u64,

    pub state_root_before: String,
    pub state_root_after: String,
}
```

### Rule

Each event must render the following verifiable:

*   the action requested;
*   the receipt emitted;
*   the budget consumed;
*   the transition of `state_root`.

History thus ceases to be narrative and becomes an evidentiary chain.

* * *

11\. Receipts
-------------

Every executed action generates a typed receipt.

```
pub enum StepReceipt {
    ProposalCreated {
        proposal_cid: String,
        proposer_hash: String,
    },
    ExpertOutput {
        output_set_cid: String,
        expert_hash: String,
    },
    AtomRehydrated {
        atom_cid: String,
        bytes: u64,
    },
    EvidenceRetrieved {
        result_set_cid: String,
    },
    UserBitWitnessed {
        question_id: String,
        answer: bool,
    },
    UserFieldWitnessed {
        field_id: String,
        value_cid: String,
    },
    TimeWitnessed {
        oracle_id: String,
        timestamp_ms: u64,
    },
    ExternalAtomFetched {
        atom_cid: String,
    },
}
```

The receipt is the smallest unit of operational proof.

* * *

12\. Proposal as artifact, not shadow
-------------------------------------

A proposal must exist as a hashable, materialized object.

```
pub struct FrugalProposal {
    pub hypothesis_cid: String,
    pub score_q16: u32,
    pub risk_q16: u32,
    pub required_atoms: Vec<String>,
    pub required_modules: Vec<String>,
    pub producer_hash: String,
}

pub struct ProposalRef {
    pub proposal_cid: String,
}
```

The session stores a reference, not private magic.

* * *

13\. `ProofMode`
----------------

The system must make explicit the portability form of the proof.

```
pub enum ProofMode {
    FullSelfContained,
    AnchoredImmutableRefs,
}
```

### 13.1 `FullSelfContained`

Carries everything necessary for complete offline replay:

*   contract or bytecode;
*   full transcript;
*   witnesses;
*   required atoms;
*   relevant modules.

### 13.2 `AnchoredImmutableRefs`

Carries only what is necessary for audit against external immutable storage:

*   transcript;
*   CIDs and hashes;
*   immutable references;
*   minimum witnesses.

* * *

14\. `ProofPack`
----------------

```
pub struct ProofPack {
    pub case_id: String,
    pub proof_mode: ProofMode,

    pub contract_hash: String,
    pub initial_budget: u64,

    pub transcript_head: Option<String>,
    pub event_count: u64,

    pub final_state_root: String,
    pub final_outcome: FinalOutcome,
}

pub enum FinalOutcome {
    Commit {
        output_cid: String,
    },
    Reject {
        reason: RejectReason,
    },
}
```

### Requirement

A third party must be able to:

*   reconstruct the initial session;
*   traverse the transcript;
*   reexecute the transitions;
*   confirm the final outcome.

* * *

15\. Typed rejection
--------------------

```
pub enum RejectReason {
    OutOfBudget,
    MissingMinimumEvidence,
    UnanchoredEvidence,
    ZeroGuessViolation,
    DeterminismViolation,
    ContractViolation,
    InvalidWitness,
    InvalidTranscript,
    InternalExecutionFailure,
}
```

Rejection must not be free text.  
It must be a machine-legible juridical state.

* * *

16\. Normative loop
-------------------

```
pub fn run(
    mut session: Session,
    contract: &dyn Contract,
    rt: &mut dyn RuntimeOps,
) -> Result<ProofPack, RejectReason> {
    loop {
        let view = SessionView::from(&session);
        match contract.eval_step(&view) {
            StepDecision::Commit => {
                return Ok(build_proof_pack(
                    session,
                    FinalOutcome::Commit {
                        output_cid: resolve_final_output_cid(&view)?,
                    },
                ));
            }
            StepDecision::Reject(reason) => {
                return Ok(build_proof_pack(
                    session,
                    FinalOutcome::Reject { reason },
                ));
            }
            StepDecision::Continue(action) => {
                let cost = contract.cost_of(&action, &view);

                if session.budget_remaining < cost.gas {
                    return Ok(build_proof_pack(
                        session,
                        FinalOutcome::Reject {
                            reason: RejectReason::OutOfBudget,
                        },
                    ));
                }

                let budget_before = session.budget_remaining;
                session.budget_remaining -= cost.gas;

                let state_root_before = session.state_root.clone();
                let receipt = rt.execute(&session, &action)?;
                session = apply_receipt(session, &action, &receipt)?;
                let state_root_after = session.state_root.clone();

                let event = StepEvent {
                    prev_event_cid: session.transcript_head.clone(),
                    action_cid: cid(&action)?,
                    receipt_cid: cid(&receipt)?,
                    budget_before,
                    budget_after: session.budget_remaining,
                    state_root_before,
                    state_root_after,
                };

                let event_cid = cid(&event)?;
                session.transcript_head = Some(event_cid);
                session.event_count += 1;
            }
        }
    }
}
```

The loop does not think.  
The loop preserves the legality of the process.

* * *

17\. `RuntimeOps`
-----------------

The runtime must be deliberately minimal.

```
pub trait RuntimeOps {
    fn execute(&mut self, session: &Session, action: &StepAction) -> anyhow::Result<StepReceipt>;
}
```

Nothing of policy.  
Nothing of silent authority.  
Nothing of "maybe."

* * *

18\. Universal verifier
-----------------------

```
pub trait UniversalVerifier {
    fn verify(&self, pack: &ProofPack) -> anyhow::Result<()>;
}
```

It must:

1.  resolve the contract by `contract_hash`;
2.  reconstruct the initial session;
3.  traverse the transcript in order;
4.  reexecute each transition under the declared profile;
5.  compare budget, state, and receipts;
6.  validate the `final_outcome`.

The verifier trusts only law, transcript, witnesses, and replay.

* * *

19\. Session without residual memory
------------------------------------

The runtime must not depend on:

*   invisible global cache;
*   warm state between cases;
*   embeddings persisted outside proof;
*   experts inherited from the previous session as a foundation of validity.

Physical reuse may exist as optimization, never as epistemic condition.

* * *

20\. Contract as governing program
----------------------------------

### Requirements of the executable contract

*   hashable;
*   versioned;
*   sandboxable;
*   deterministically replayable under `DeterminismProfile`;
*   incapable of implicit I/O;
*   incapable of mutating state outside the session.

### Recommendation

WASM is a natural target, provided the contract remains restricted law, not arbitrary application.

### Decisive formula

Contract is a governing program, not general sovereign software.

* * *

21\. Main risk and containment
------------------------------

The greatest risk of this RFC is degeneration into a generic VM.

The correct containment is threefold:

*   minimal runtime;
*   restricted contract;
*   hashed external modules called explicitly.

The architecture remains radical without dissolving its identity.

* * *

22\. Philosophical consequence
------------------------------

The relevant computation is not merely the forward pass.

The relevant computation is the chain of transitions that constructs a verifiable certificate.

That is the true unit of decision in this system.

* * *

23\. Crate shape
----------------

```
proof_runtime/
  src/
    lib.rs
    session.rs
    contract.rs
    decision.rs
    action.rs
    receipt.rs
    event.rs
    proof.rs
    reject.rs
    verifier.rs
    runtime.rs
    cid.rs
    state_root.rs
    determinism.rs
```

`lib.rs`:

```
pub mod action;
pub mod cid;
pub mod contract;
pub mod decision;
pub mod determinism;
pub mod event;
pub mod proof;
pub mod receipt;
pub mod reject;
pub mod runtime;
pub mod session;
pub mod state_root;
pub mod verifier;
```

* * *

Minimum conformance
-------------------

An implementation is minimally conformant only if:

*   every session produces a `ProofPack` when it terminates;
*   each step generates a verifiable `StepEvent`;
*   `StepDecision` is always `Commit`, `Continue`, or `Reject`;
*   the transcript is append-only and auditable;
*   `WitnessAction` is the only path through which external evidence may enter;
*   the error contract remains binding throughout the entire session.

* * *

Normative mantra
----------------

To decide is to prove.  
To advance is to transact.  
To execute is to emit a receipt.  
Validity is transcript plus contract plus replay.

Short form:

*   no hidden state
*   no silent authority
*   only steps
*   only receipts
*   only proof

* * *

Verdict
-------

This RFC turns the act of deciding into a verifiable historical process.

It reduces the runtime to its proper office, elevates the transcript to the status of authority, and converts the contract into executable law. From this point onward, legitimate decision ceases to be a psychological event of the system and becomes a proved fact.

* * *

