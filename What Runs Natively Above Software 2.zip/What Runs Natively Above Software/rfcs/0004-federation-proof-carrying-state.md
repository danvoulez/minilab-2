RFC-0004 — Federation under Proof-Carrying State
================================================

> **Status:** Normative draft.
> 
> This RFC defines the federative layer of a local-first, zero-trust, proof-oriented system in which shared state is represented by signed pointers over immutable content-addressed graphs.

Summary
-------

The federation defined here does not synchronize mutable memory. It arbitrates signed advances over verifiable proof.

Its purpose is to allow coexistence among local sovereignties without regression to distributed mutable database, silent overwrite, or blind trust in remote infrastructure.

0\. Status
----------

Normative draft.

* * *

1\. Scope
---------

This RFC specifies:

*   identity of nodes and authorities;
*   advancement of `StatePointer`;
*   announcement of advances;
*   local acceptance of remote advances;
*   detection and preservation of fork;
*   resolution by policy;
*   anti-rewind protection;
*   optional quorum;
*   integration with `ProofPack`, `AtomSpace`, and contract.

This RFC does not specify:

*   any particular physical transport;
*   any concrete signature algorithm;
*   peer-to-peer discovery;
*   universal global consensus;
*   domain-specific business policy.

* * *

2\. Normative thesis
--------------------

The federation MUST NOT synchronize mutable state.

It MUST exchange only:

*   CIDs;
*   `ProofPacks`;
*   signed `StatePointers`;
*   announcements;
*   acceptance receipts;
*   conflict artifacts.

Federative consensus, in this context, is not universal truth. It is local, verifiable, policy-dependent agreement about which proof has the right to advance which pointer in which namespace.

* * *

3\. Normative terms
-------------------

*   **Accept**: to recognize an advance locally as valid under local policy.
*   **Announce**: to publish a candidate advance.
*   **Authority**: an entity authorized to advance or witness within a namespace.
*   **Fork**: the existence of two or more incompatible heads for the same alias.
*   **Pointer**: the minimal mutable record that points to an immutable head.
*   **Proof-Carrying State**: state whose advance is legitimate only when accompanied by replayable proof.

* * *

4\. Invariants
--------------

**I1 — Truth remains outside the federation**

No remote node is primary authority over factual truth. Truth continues to reside in atoms, transcript, hashed contract, receipts, and replayable proof.

**I2 — Pointer advance requires proof**

A new `StatePointer` may not be accepted without valid signature, recognized authority, satisfied policy, and verifiable or resolvable proof.

**I3 — Reception does not imply acceptance**

Receiving bytes, CIDs, or announcements is never equivalent to accepting them.

**I4 — Fork is a first-class object**

Competing heads must be preserved as explicit conflict until resolution or formal coexistence.

**I5 — Anti-rewind is mandatory**

Silent regression of sequence or head is forbidden.

**I6 — Policy is local**

Even data from a trusted source remain subject to local acceptance policy.

* * *

5\. Identity and authority
--------------------------

### 5.1 `NodeIdentity`

```
pub struct NodeIdentity {
    pub node_id: String,
    pub public_key: String,
    pub roles: Vec<NodeRole>,
}

pub enum NodeRole {
    EdgeExecutor,
    PointerAuthority,
    WitnessAuthority,
    ContractPublisher,
    Mirror,
}
```

### Rules

*   each `node_id` must map to a single active public key per trust epoch;
*   a node may accumulate roles;
*   role does not imply universal authority.

### 5.2 Authority namespace

Authority is always namespaced.

```
pub struct AuthorityGrant {
    pub authority_id: String,
    pub namespace_prefix: String,
    pub allowed_roles: Vec<NodeRole>,
    pub valid_from_epoch: u64,
    pub valid_until_epoch: Option<u64>,
}
```

An authority valid for `contracts:*` is not automatically valid for `cases:*`.

* * *

6\. `StatePointer`
------------------

```
pub struct StatePointer {
    pub alias: String,
    pub prev_head_cid: Option<String>,
    pub head_cid: String,
    pub sequence_number: u64,
    pub authority_id: String,
    pub authority_signature: String,
}
```

### 6.1 Normative rules

A candidate pointer must satisfy:

1.  `alias` must not be empty;
2.  `head_cid` must be syntactically valid;
3.  `sequence_number > 0`;
4.  valid signature over canonical content;
5.  authority recognized for the namespace;
6.  `prev_head_cid` consistent with local policy or explicitly treated as fork.

### 6.2 Anti-rewind

Given a `last_seen_pointer`, the new pointer must be rejected if:

*   `sequence_number < last_seen.sequence_number`;
*   `sequence_number == last_seen.sequence_number` and `head_cid != last_seen.head_cid`;
*   `prev_head_cid != Some(last_seen.head_cid)` in a namespace that does not admit fork;
*   the signature is invalid;
*   the authority is not authorized.

### Exception

If the policy of the alias admits fork, the candidate may be registered as explicit conflict instead of rejected.

* * *

7\. Pointer classes
-------------------

```
pub enum PointerClass {
    Personal,
    SharedCase,
    ContractHead,
    WitnessLog,
    MirrorIndex,
}

pub struct PointerPolicy {
    pub alias_prefix: String,
    pub class: PointerClass,
    pub accepted_authorities: Vec<String>,
    pub requires_quorum: bool,
    pub quorum_size: u32,
    pub allow_forks: bool,
    pub require_proof_pack: bool,
}
```

### Rules

*   every alias must match exactly one effective policy;
*   in case of multiple matches, the most specific policy prevails;
*   absence of policy implies lack of authorization.

* * *

8\. Announcement protocol
-------------------------

```
pub struct PointerAnnouncement {
    pub pointer: StatePointer,
    pub proof_pack_cid: String,
    pub contract_hash: String,
    pub announcer_node_id: String,
    pub announcement_signature: String,
}
```

### Rules

*   every announcement must be signed by the announcer;
*   it must reference `proof_pack_cid` whenever policy requires proof;
*   it may not carry inline mutable state as primary authority;
*   dependency hints may exist, but they never replace CID-based verification.

* * *

9\. Dependency resolution
-------------------------

```
pub enum DependencyStatus {
    Complete,
    Missing(Vec<String>),
}

pub trait FederationTransport {
    fn announce(&mut self, msg: PointerAnnouncement) -> anyhow::Result<()>;
    fn request_atoms(&mut self, cids: &[String]) -> anyhow::Result<Vec<UniversalAtom>>;
    fn request_proof_pack(&mut self, cid: &str) -> anyhow::Result<ProofPack>;
}
```

### Rules

*   dependencies are always resolved by CID;
*   a node may not accept a head whose necessary proof is not verifiable;
*   announcements may remain `Deferred` while dependencies are missing;
*   transport is a source of candidate bytes, never a source of truth.

* * *

10\. Acceptance
---------------

```
pub enum AcceptanceVerdict {
    Accepted,
    Rejected(AcceptRejectReason),
    ForkDetected,
    Deferred,
}

pub enum AcceptRejectReason {
    MissingDependencies,
    InvalidSignature,
    InvalidProof,
    InvalidContract,
    AuthorityViolation,
    RewindAttempt,
    SequenceGap,
    PolicyViolation,
}
```

### Rule

Every announcement must produce exactly one local verdict. Silence or timeout never equals acceptance.

* * *

11\. `AcceptanceReceipt`
------------------------

```
pub struct AcceptanceReceipt {
    pub pointer_alias: String,
    pub head_cid: String,
    pub verifier_node_id: String,
    pub verdict: AcceptanceVerdict,
    pub reason: Option<AcceptRejectReason>,
    pub verifier_signature: String,
}
```

### Rules

*   every acceptance receipt must be verifiable and signable;
*   `reason` must exist in case of rejection;
*   receipts may federate, but they do not advance a pointer by themselves.

* * *

12\. Pointer validation
-----------------------

```
pub trait PointerValidator {
    fn validate_pointer(
        &self,
        new_pointer: &StatePointer,
        previous: Option<&StatePointer>,
        fed: &FederationView,
    ) -> AcceptanceVerdict;
}
```

### Minimum validator rules

The validator must check:

*   pointer signature;
*   monotonicity of sequence;
*   consistency of `prev_head_cid`;
*   authority for the namespace;
*   existence of applicable policy.

It must not assume for itself complete proof verification, which belongs to the acceptance pipeline.

* * *

13\. Proof verification before acceptance
-----------------------------------------

When policy requires proof, the receiver must:

1.  resolve the `ProofPack`;
2.  resolve the necessary dependencies;
3.  verify the pack with `UniversalVerifier`;
4.  confirm that `contract_hash` is recognized;
5.  confirm that the announced head corresponds to the verified result.

If any step fails, the announcement must be rejected or deferred, never accepted by benevolence.

* * *

14\. `FederationView`
---------------------

```
pub struct FederationView {
    pub recognized_nodes: Vec<NodeIdentity>,
    pub accepted_contract_hashes: Vec<String>,
    pub pointer_policies: Vec<PointerPolicy>,
    pub acceptance_receipts: Vec<AcceptanceReceipt>,
}
```

### Rules

*   `recognized_nodes` must suffice to verify recognized authorities;
*   `accepted_contract_hashes` list only laws accepted locally;
*   `pointer_policies` must resolve aliases deterministically.

* * *

15\. Forks
----------

```
pub struct PointerFork {
    pub alias: String,
    pub base_head_cid: Option<String>,
    pub competing_heads: Vec<String>,
    pub detected_by: String,
}
```

### Rules

*   valid competition among heads must be recorded as `PointerFork` or treated explicitly by policy;
*   silent overwrite is forbidden;
*   all relevant known heads must be preserved in the fork artifact.

* * *

16\. `ResolutionPolicy`
-----------------------

```
pub trait ResolutionPolicy {
    fn resolve(&self, fork: &PointerFork, ctx: &FederationView) -> ResolutionOutcome;
}

pub enum ResolutionOutcome {
    ChooseHead { head_cid: String },
    PreserveFork,
    RequireHumanWitness,
    RequireQuorum,
    RejectAll,
}
```

### Rules

*   resolution must be explicit;
*   choosing a head requires an auditable trail of reasons;
*   `PreserveFork` may be a legitimate final result in multiversioned namespaces;
*   `RequireHumanWitness` and `RequireQuorum` must point to measurable policy.

* * *

17\. Quorum
-----------

```
pub struct QuorumProof {
    pub alias: String,
    pub head_cid: String,
    pub acceptance_receipt_cids: Vec<String>,
}

pub enum PointerStatus {
    LocalOnly,
    Announced,
    FederallyAccepted,
    Rejected,
    Forked,
}
```

### Rules

*   when `requires_quorum = true`, a head may not be marked `FederallyAccepted` without sufficient receipts;
*   `quorum_size` must be greater than zero;
*   quorum receipts must come from distinct, recognized nodes;
*   nodes outside the namespace of trust do not count toward quorum.

* * *

18\. Sequence gaps
------------------

If a node receives a pointer with `sequence_number > last_seen + 1`, it may:

*   reject with `SequenceGap`;
*   defer as `Deferred`;
*   request intermediate pointers.

It may not presume that intermediate history is irrelevant, absent explicit policy to the contrary.

* * *

19\. Federation of contracts
----------------------------

```
pub struct ContractAnnouncement {
    pub contract_hash: String,
    pub contract_cid: String,
    pub publisher_id: String,
    pub publisher_signature: String,
}
```

### Rules

*   an announced contract must come from an authorized publisher;
*   a `ProofPack` under an unrecognized contract may not be accepted;
*   contract update should prefer its own pointer, such as `contracts:<namespace>:head`.

* * *

20\. Federation of witnesses
----------------------------

```
pub struct WitnessReceipt {
    pub witness_kind: String,
    pub payload_cid: String,
    pub witness_authority_id: String,
    pub witness_signature: String,
}
```

### Rules

*   every federated witness must be signed by a recognized authority for that witness type;
*   a witness does not count outside its namespace without explicit policy;
*   witnesses may participate in fork resolution and proof verification.

* * *

21\. Processing pipeline
------------------------

```
pub trait AnnouncementProcessor {
    fn process_announcement(
        &mut self,
        ann: &PointerAnnouncement,
    ) -> anyhow::Result<AcceptanceReceipt>;
}
```

### Normative order

When processing an announcement, the implementation must:

1.  verify the signature of the announcement;
2.  validate the syntax of the pointer;
3.  locate the policy for the alias;
4.  compare against the previously known pointer;
5.  resolve minimum dependencies;
6.  verify the proof, if required;
7.  evaluate conflict or fork;
8.  emit `AcceptanceReceipt`.

No shared pointer may advance without an equivalent trail of acceptance.

* * *

22\. `ForkRegistry`
-------------------

```
pub trait ForkRegistry {
    fn register_fork(&mut self, fork: PointerFork) -> anyhow::Result<()>;
    fn list_forks(&self, alias: &str) -> Vec<PointerFork>;
}
```

A detected fork must be persisted as an auditable object. Later resolution does not erase its historical existence.

* * *

23\. `ResolutionEngine`
-----------------------

```
pub trait ResolutionEngine {
    fn resolve_fork(
        &self,
        fork: &PointerFork,
        fed: &FederationView,
    ) -> anyhow::Result<ResolutionOutcome>;
}
```

### Rules

*   the resolver depends only on policy and verifiable artifacts;
*   it does not choose a head by informal source preference;
*   it must be deterministic for the same set of inputs.

* * *

24\. Local sovereignty
----------------------

The federation must preserve local sovereignty:

*   a locally valid proof is not destroyed by remote rejection;
*   cloud is not implicit authority;
*   a node may maintain `LocalOnly` state;
*   remote acceptance promotes federative status, but does not redefine the intrinsic cryptographic validity of the `ProofPack`.

* * *

25\. Failure modes
------------------

A conformant implementation must distinguish at least:

*   transport failure;
*   signature failure;
*   policy failure;
*   dependency failure;
*   replay or proof failure;
*   rewind attempt;
*   fork detected;
*   unknown contract.

These failures may not collapse into generic error when federative acceptance is affected.

* * *

26\. Security
-------------

### Attacks to resist

*   silent overwrite of head;
*   replay of old pointer;
*   announcement with invalid signature;
*   malicious unrecognized contract;
*   invalid but well-formed `ProofPack`;
*   injection of incorrect dependency;
*   quorum forged by unrecognized nodes.

### Minimum requirement

A conformant implementation must detect and not accept such cases without explicit policy.

* * *

27\. Suggested crate layout
---------------------------

```
proof_federation/
  src/
    lib.rs
    node.rs
    pointer.rs
    announcement.rs
    acceptance.rs
    fork.rs
    policy.rs
    resolution.rs
    transport.rs
    validator.rs
    quorum.rs
```

`lib.rs`:

```
pub mod acceptance;
pub mod announcement;
pub mod fork;
pub mod node;
pub mod pointer;
pub mod policy;
pub mod quorum;
pub mod resolution;
pub mod transport;
pub mod validator;
```

* * *

28\. Canonical flow
-------------------

### Simple accepted advance

1.  Node A generates `ProofPack`.
2.  Node A creates `StatePointer`.
3.  Node A emits `PointerAnnouncement`.
4.  Node B validates signature and policy.
5.  Node B resolves proof and dependencies.
6.  Node B executes `UniversalVerifier`.
7.  Node B accepts locally.
8.  Node B emits `AcceptanceReceipt`.

### Fork case

1.  Node A announces `head_1`.
2.  Node C announces `head_2` for the same alias and base.
3.  Node B detects incompatibility.
4.  Node B registers `PointerFork`.
5.  Node B applies `ResolutionPolicy`.
6.  The result chooses, preserves, requests witness, or requires quorum.

* * *

29\. Minimum conformance
------------------------

An implementation is minimally conformant only if it:

*   validates pointer signature;
*   applies anti-rewind;
*   resolves dependencies by CID;
*   verifies `ProofPack` when required;
*   treats fork as explicit object;
*   emits `AcceptanceReceipt`;
*   separates reception from acceptance.

* * *

30\. Normative mantra
---------------------

State does not merge.  
Heads compete.  
Proof decides.  
Policy accepts.

Hard form:

*   no blind trust
*   no silent overwrite
*   only signed heads
*   only verifiable advances

* * *

31\. Architectural verdict
--------------------------

This RFC closes the political layer of the machine.

RFC-0001 defines who may decide.  
RFC-0002 defines how proof is built.  
RFC-0003 defines where immutable knowledge lives.  
RFC-0004 defines how local sovereigns coexist without surrendering to the myth of shared mutable state.

The sustaining formula is definitive:

Federation is not synchronization of memory.  
Federation is arbitration of signed advances over verifiable proof.

* * *

