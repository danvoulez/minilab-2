RFC-0006 — Sovereign Worker ABI & Sandboxed Execution
=====================================================

> **Status:** Normative draft.
> 
> This RFC defines the execution interface, isolation regime, and determinism contract of the workers delegated by the Manager Plane.

Summary
-------

If the previous RFCs defined law, process, space, and government, this RFC defines the labour of the machine: the workers.

The correct worker is not a sovereign microservice. It is an isolated, contained, verifiable function subordinate to the same regime of proof that governs the rest of the system.

If the system is truly zero-trust, the code that does the heavy work cannot stand outside the Constitution.

0\. Status
----------

Normative draft.

* * *

1\. Normative thesis
--------------------

The worker is not a service with a will of its own.

The worker is an isolated function that maps a graph of input CIDs to an output receipt.

To preserve replay and verifiability, the worker:

*   does not access disk directly;
*   does not access network directly;
*   does not query host clock;
*   does not possess hidden entropy;
*   does not persist residual state across executions.

Everything it knows comes by atoms.  
Everything it produces must be able to become an atom.

If hot data are missing from memory, the worker does not improvise I/O. It yields, returns control, and requests rehydration.

* * *

2\. Invariants
--------------

**I1 — Absolute statelessness**

The same `TaskCid`, executed on the same `WorkerCid`, under the same contract and determinism profile, must produce the same `ReceiptCid`, except for divergences explicitly admitted by `epsilon`.

**I2 — No-syscall rule**

The worker must not perform arbitrary system calls. Its visible universe is the interface provided by the host.

**I3 — Mandatory epistemic yield**

If a required CID is `Absent` or `Cold`, the worker must suspend execution and return the missing CIDs to the host.

**I4 — Physiological separation**

There are two legitimate classes of worker:

1.  `ChipAsCode`: exact, bit-for-bit deterministic.
2.  `SiliconAsCompute`: statistical, hardware-accelerated, yet contained by explicit error bounds.

* * *

3\. Worker as sovereign artifact
--------------------------------

A worker is not a loose binary in the operating system. It must itself be treated as a content-addressed artifact in `AtomSpace`.

```
pub struct WorkerManifest {
    pub name: String,
    pub version: String,
    pub class: WorkerClass,
    pub bytecode_cid: String,
    pub required_capabilities: Vec<Capability>,
    pub determinism_profile: DeterminismProfile,
}

pub enum WorkerClass {
    ChipAsCode,
    SiliconAsCompute {
        epsilon_bounds: f32,
        quantization: QuantizationLevel,
    },
}
```

`epsilon_bounds` must be compatible with `ErrorContract.epsilon` from RFC-0001. In the absence of conflict, the more restrictive value prevails.

* * *

4\. The ABI between host and worker
-----------------------------------

The execution boundary must be linear, small, and rigorous.

```
pub trait WorkerHostEnv {
    fn request_atom(&self, cid: &str) -> Result<&[u8], PageFault>;
    fn consume_gas(&mut self, amount: u64) -> Result<(), OutOfGas>;
}

pub enum WorkerResult {
    Complete(ReceiptCid),
    Yield(Vec<String>),
    Fail(WorkerError),
}

pub trait WorkerAbi {
    fn execute(
        &mut self,
        task_cid: &str,
        env: &mut dyn WorkerHostEnv,
    ) -> WorkerResult;
}
```

`WorkerAbi` is the form of execution inside the sandbox. The `Worker` interface of RFC-0005 is the managerial layer of identity, capability, and dispatch.

* * *

5\. The problem of divergent hardware
-------------------------------------

Statistical execution on GPU, NPU, or heterogeneous accelerators produces small variations. This RFC rejects both the fiction of false exactness and the irresponsibility of permissiveness.

The correct rule is: `SiliconAsCompute` is not validated by bit-for-bit identity, but by proof of bounded divergence.

```
pub struct SiliconReceipt {
    pub task_cid: String,
    pub result_vector: Vec<i32>,
    pub hardware_signature: String,
}

pub fn verify_silicon_execution(
    expected_receipt: &SiliconReceipt,
    recomputed_receipt: &SiliconReceipt,
    epsilon: f32,
) -> bool {
    let distance = calculate_vector_distance(
        &expected_receipt.result_vector,
        &recomputed_receipt.result_vector,
    );

    distance <= epsilon
}
```

Thus the system admits the physiology of silicon without surrendering its constitution.

* * *

6\. Isolating the oracle
------------------------

If the worker possesses neither clock nor network, how does it access time or external data?

It does not.

The manager and the runtime must inject witnesses into `TaskCid` before execution.

```
{
  "t": "atom.task",
  "worker": "cid_worker_pricing_v1",
  "witnesses": [
    { "type": "time", "ms": 1741753200, "oracle_sig": "0x..." },
    { "type": "fetch", "url": "api.price", "response_cid": "cid_..." }
  ]
}
```

The worker operates over a frozen photograph of the observable universe. This guarantees historical reexecution without dependence on a mutable present.

* * *

7\. Task lifecycle
------------------

The correct execution flow is a yield loop, not an uncontrolled escape into I/O.

1.  the manager emits `Delegate`;
2.  the runtime initializes the sandbox and calls `execute(task_cid)`;
3.  the worker discovers a dependency not yet hot;
4.  it calls `request_atom(cid)`;
5.  the host returns `PageFault` if the data are not materialized;
6.  the worker returns `Yield(missing_cids)`;
7.  the runtime rehydrates the required CIDs via `AtomSpace`;
8.  the sandbox is resumed;
9.  the worker completes and returns `Complete(ReceiptCid)`.

### 7.1 Authoring Friction and Machine Assistance

Suspension for lack of data is not error.  
It is operational discipline.

A natural objection is that explicit yields, governed I/O, resumable workers, and typed continuations impose too much authorial friction for ordinary software work.

That objection was stronger in an unaided programming era.

As software construction becomes routinely machine-assisted — including environments where the interface remains conversational — the cost of writing explicit orchestration, resumable execution, and proof-compatible control flow falls significantly. What once looked prohibitively formal becomes increasingly authorable in practice.

This does not eliminate the overhead. It changes its historical weight.

In such an environment, the relevant question is no longer whether governed execution is more demanding than casual scripting. It is whether high-consequence systems can still justify architectures whose convenience depends on hidden state, arbitrary I/O, and illegible continuation.

Under machine-assisted authorship, disciplines that once seemed excessive may become the minimum price of legitimacy.

* * *

8\. Suggested crate layout
--------------------------

```
worker_abi/
  src/
    lib.rs
    manifest.rs
    env.rs
    yield.rs
    sandbox/
      wasm.rs
      wgpu.rs
    bounding.rs
```

* * *

9\. Normative mantra
--------------------

Logic is exact.  
Silicon is bounded.  
Workers cannot speak; they only yield.  
Time is an input, not a state.

Short form:

*   no syscalls
*   no arbitrary I/O
*   pure functions only
*   yield on cold memory

* * *

Minimum conformance
-------------------

An implementation is minimally conformant only if it:

*   executes workers in isolated sandbox;
*   provides explicit gas budget on every invocation;
*   prevents direct access to network, filesystem, and host clock;
*   subjects outputs to gate and proof regime before promotion;
*   declares `epsilon_bounds` for `SiliconAsCompute`;
*   correctly implements the `yield/resume` cycle.

* * *

Failure modes
-------------

The implementation must distinguish at least:

*   invalid, incomplete, or inconsistent input;
*   excess of budget or quota;
*   divergence incompatible with `epsilon`;
*   refusal or contract violation at the host interface;
*   violation of isolation, capability, or operational policy.

None of these failures may result in implicit commit.

* * *

Security
--------

The minimum guarantees are:

*   explicit isolation and absence of implicit access to host resources;
*   all external interaction passes only through interfaces admitted by the host;
*   no internal execution failure emits canonical receipt by itself;
*   outputs are promoted only when compatible with the contract and the declared environment;
*   any violation of isolation or policy is treated as explicit failure.

* * *

Architectural verdict
---------------------

With this RFC, the cryptographic circle closes.

The system need not trust blindly the model, the plugin, the expert, or the accelerator. It needs only the small auditable boundary between host and worker, the proofs emitted, the hashes preserved, and the margins explicitly contracted.

The worker ceases to be opaque process and becomes a sovereign instrument of work under law.

* * *

