RFC-0003 — Sovereign Atom Space
===============================

> **Status:** Normative draft.
> 
> Subtitle: Storage under Epistemic Law.
> 
> In this RFC, imperative terms carry normative force equivalent to MUST / MUST NOT.

Summary
-------

If RFC-0001 defined the legitimacy of decision and RFC-0002 defined the proof process, this RFC defines the ground on which that history can survive without semantic corruption.

Its purpose is to replace the imagination of a mutable database with a regime of knowledge that is content-addressed, immutable by construction, local-first by nature, and federable through the exchange of CIDs.

0\. Central thesis
------------------

In proof-oriented systems, the mutable database is an epistemological anti-pattern.

If a record can undergo `UPDATE`, cryptographic history weakens.  
If history weakens, replay becomes fragile.  
If replay becomes fragile, proof degenerates into narrative.

Therefore this system affirms:

*   local disk is not dead archive; it is thermodynamic cache;
*   truth does not reside in tables; it resides in immutable content-addressed graphs;
*   legitimate mutation is the emission of a new atom followed by pointer advancement;
*   controlled forgetting is not failure, but a mechanism of survival.

* * *

1\. Objective
-------------

Define a storage subsystem in which:

*   CID is the only canonical form of access to knowledge;
*   everything, from the smallest witness to the largest model, obeys the same law of the universal atom;
*   the local device can operate offline without losing auditability;
*   the dependencies of a `ProofPack` can be resolved without trusting the origin of the bytes.

* * *

2\. Constitutional invariants
-----------------------------

**I1 — Without CID, there is no canonical existence**

No subsystem may fetch knowledge by semantic ID as primary authority. Semantic resolutions are auxiliary; truth always enters by CID.

**I2 — Mutation is forbidden inside the atom**

Once materialized in `AtomSpace`, the content of an atom never changes. Every legitimate change is the emission of a new atom.

**I3 — Absence is admissible**

It is constitutional to know the hash of an atom without possessing its payload locally. The system can prove chains even when it still needs to rehydrate dependencies.

**I4 — Eviction is part of physical law**

When limits of RAM, VRAM, or disk are reached, the system must cool less-prioritized knowledge. The machine's thermal survival is not an operational detail; it is part of the architecture.

* * *

3\. Anatomy of the universal atom
---------------------------------

There are no sovereign tables. There is one common format capable of carrying any materially relevant fact, subjecting the giant and the trivial alike to the same gravitational law: the universal atom.

```
pub struct UniversalAtom {
    pub header: AtomHeader,
    pub links: Vec<String>,
    pub payload: Vec<u8>,
}

pub struct AtomHeader {
    pub kind: AtomKind,
    pub size_bytes: u64,
    pub producer_hash: String,
    pub signature: Option<String>,
}

pub enum AtomKind {
    Weights,
    WasmContract,
    PromptText,
    ProofPack,
    StateRoot,
    WitnessData,
}
```

The system does not distinguish the large from the small by juridical nature.  
It distinguishes them only by weight, heat, and function.

* * *

4\. Epistemic thermodynamics
----------------------------

The machine must know not only what exists, but in what degree of presence that knowledge currently stands.

```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EpistemicHeat {
    Absent,
    Cold,
    Warm,
    Hot,
}
```

### Semantics

*   `Absent`: the CID is known, but there are no local bytes.
*   `Cold`: header and links are available, but the payload is outside fast memory.
*   `Warm`: an operational summary is present in useful memory.
*   `Hot`: the full payload is loaded and ready for use.

### Transition rule

The runtime performs no direct I/O. It emits `MaterializeAction::RehydrateAtom`; `AtomSpace` promotes the knowledge to the required thermal level, cooling other atoms if necessary.

* * *

5\. Storage contract
--------------------

```
pub trait AtomSpace {
    fn current_heat(&self, cid: &str) -> EpistemicHeat;
    fn heat_up(&mut self, cid: &str, target: EpistemicHeat) -> Result<(), PageFault>;
    fn cool_down(&mut self, cid: &str) -> Result<(), ()>;
    fn materialize(&mut self, atom: UniversalAtom) -> Result<String, StorageError>;
    fn get_thermal_metrics(&self) -> ThermalMetrics;
}

pub enum PageFault {
    NetworkRequired { cid: String },
    BudgetExhausted { required: u64, available: u64 },
    CorruptedCid { expected: String, actual: String },
}
```

Recommended minimum structure for `ThermalMetrics`:

```
pub struct ThermalMetrics {
    pub hot_bytes: u64,
    pub warm_bytes: u64,
    pub cold_bytes: u64,
    pub absent_count: u64,
    pub total_atoms: u64,
}
```

Storage is not mere persistence.  
It is physical management of presence under epistemic law.

* * *

6\. Epistemic pointers
----------------------

If atoms are immutable, the live state of the system must move by means of minimal, auditable pointers.

```
pub struct StatePointer {
    pub alias: String,
    pub head_cid: String,
    pub sequence_number: u64,
    pub authority_signature: String,
}
```

### Law of pointers

*   the pointer does not contain truth; it contains direction;
*   the pointer does not replace proof; it points to it;
*   destroying the pointer registry does not destroy the universe of the system, provided the `ProofPacks` survive.

For federated context, RFC-0004 extends this structure with `prev_head_cid` and `authority_id`.

* * *

7\. Local-first synchronization
-------------------------------

Correct synchronization between devices is not database reconciliation, but exchange of heads and missing dependencies.

Canonical flow:

1.  the local device emits a `ProofPack` offline;
2.  it advances its local `StatePointer`;
3.  once connectivity returns, it announces only the pointer advance;
4.  the remote peer verifies whether it possesses the announced CID;
5.  if material is missing, it requests only the necessary blocks;
6.  it receives bytes, verifies CIDs, and reexecutes the proof;
7.  it accepts or rejects the advance locally.

There is no merge of truth.  
There is only verifiable replication of graphs.

* * *

8\. Integration with the previous RFCs
--------------------------------------

The complete machine operates as follows:

1.  RFC-0003 resolves the contract and its atoms by pointer and CID;
2.  RFC-0002 starts the clean session;
3.  RFC-0001 governs the decision through the gate and the error contract;
4.  RFC-0003 materializes the necessary data when they are missing;
5.  RFC-0002 emits the final `ProofPack`;
6.  RFC-0003 preserves that `ProofPack` as part of the local sovereign universe.

Storage thus ceases to be passive infrastructure and becomes the physical stage of proof.

* * *

9\. Suggested crate layout
--------------------------

```
epistemic_storage/
  src/
    lib.rs
    atom.rs
    heat.rs
    pager.rs
    cas.rs
    pointers.rs
    network.rs
```

* * *

10\. Normative mantra
---------------------

State is a pointer.  
Knowledge is a graph.  
Disk is a cache.  
Forgetfulness is survival.

* * *

Minimum conformance
-------------------

An implementation is minimally conformant only if it:

*   accesses canonical knowledge by CID;
*   treats atoms as immutable after materialization;
*   permits local absence of payload without destroying chain verifiability;
*   implements explicit thermal transitions for the presence of data;
*   represents state mutation by pointer advancement over immutable graphs.

* * *

Verdict
-------

This RFC gives the system its geography.

With it, state ceases to be mutable anxiety and becomes direction over verifiable history. Disk becomes cache, cache becomes thermodynamics, and memory ceases to be sovereign so that it may serve proof.

* * *

