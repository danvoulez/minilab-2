RFC-0001 — Constitution of the Hybrid
=====================================

> **Status:** Normative draft.
> 
> In this RFC, the terms "must," "must not," "forbidden," and their equivalents carry normative force equivalent to MUST / MUST NOT.

Summary
-------

This RFC institutes the constitutional order of the hybrid system: a regime in which silicon may propose, approximate, and accelerate, but may never rule in place of proof.

Its purpose is simple and severe: to democratize computational power without sacrificing trust, verifiability, replay, or explicit governance.

Preamble
--------

Every technical civilization worthy of the name distinguishes power from legitimacy.

It is built to democratize computational power without sacrificing trust.  
Silicon may be statistical. The world may not be statistical without contract.

Power without law produces blind speed.  
Law without power produces sterility.

The system defined here exists to unite both without confusing them:

*   silicon computes;
*   the gate governs;
*   the transcript preserves;
*   proof legitimizes.

From this Constitution onward, no relevant decision may rest on opaque impulse, implicit guesswork, or silent authority.

* * *

Article I — Law of the Outcome
------------------------------

Every computation submitted to the regime of this system must terminate in exactly one of three canonical states:

*   `OK -> COMMIT`
*   `DOUBT -> GHOST`
*   `NOT -> REJECT`

There is no fourth implicit state.  
There is no "maybe commit."  
There is no "almost OK."

Totality of decision is mandatory.

* * *

Article II — Law of Contracted Error
------------------------------------

Admissible error must be a declared clause, never a tolerated side effect.

Before any execution, the system must make explicit:

*   the error margin `epsilon`;
*   the admissible budget of doubt;
*   the forbidden domains in which `epsilon = 0`;
*   the minimum criteria required for result promotion.

In the absence of contract, conservative mode prevails.

* * *

Article III — Law of No-Guess
-----------------------------

Without sufficient evidence, guessing is forbidden.

When the minimum input of truth is missing:

*   the system must request witness, rehydration, or the missing data;
*   the system may not issue `COMMIT` on the basis of illusory completeness;
*   silence, gaps, or low confidence do not count as authorization.

Recognized ignorance is more legitimate than invented certainty.

* * *

Article IV — Law of Creative Silicon
------------------------------------

Silicon is free to approximate, provided the gate can still prove safety.

It may:

*   interpolate;
*   estimate;
*   sample;
*   compress;
*   use heuristics, models, and shortcuts.

But its product may ascend to the regime of decision only if it:

*   respects the active error contract;
*   declares score, risk, and minimum provenance;
*   passes the gate successfully.

In the present system, statistical creativity is not sovereignty.

* * *

Article V — Law of Proof
------------------------

Every decision must be replayable, auditable, and attributable.

For any promoted output, there must exist:

*   content identity by CID;
*   a derivation capable of reexecuting the path and reproducing the result;
*   a minimum trail of inputs, parameters, contract, and origin.

Without replay, it is only opinion.  
With replay, there is proof.

* * *

Article VI — Law of Allocation
------------------------------

Each task must be sent to the regime in which it is most competent.

*   `Silicon`: throughput, parallelism, and approximation.
*   `Chip-as-Code`: policy, invariants, auditability, and exactness.
*   `Hybrid`: silicon proposes, the gate decides.

The objective is not blind speed.  
The objective is governed efficiency.

* * *

Article VII — Law of Minimum Hardware
-------------------------------------

The minimum acceptable hardware is whatever preserves the Constitution.

If a device does not sustain:

*   minimum replay;
*   content addressing;
*   deterministic execution of the gate;
*   emission of verifiable receipts;

then it may compute, but it may not decide.

* * *

Article VIII — Law of Upgrade Without Betrayal
----------------------------------------------

Upgrades may not dissolve history.

A change is constitutional only if it:

*   changes the kernel or shader identifier whenever semantics change;
*   preserves the verifiability of what has already been emitted;
*   maintains compatibility or declares rupture with explicit clarity.

Every legitimate evolution honors the verifiable past.

* * *

Article IX — Law of Democratic Power
------------------------------------

This architecture shall be judged by the weak before it is celebrated by the strong.

It is considered successful when it:

*   runs with dignity on cheap hardware;
*   remains verifiable outside the datacenter;
*   can federate without losing proof, identity, or local sovereignty.

To scale for the few is luxury.  
To scale for the many is principle.

* * *

Reference Implementation
------------------------

The following sections do not exhaust the Constitution, but they offer one concrete way to implement it.

### 1\. Base types: `Verdict` and error contract

```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Verdict {
    Commit,
    Ghost,
    Reject,
}

#[derive(Debug, Clone)]
pub struct ErrorContract {
    /// allowed epsilon (e.g. 0.05 = 5%)
    pub epsilon: f32,
    /// domains in which epsilon = 0 (guessing forbidden)
    pub zero_guess_domains: Vec<&'static str>,
    /// maximum number of questions (`Ghost`) per decision
    pub max_questions: u8,
}

impl ErrorContract {
    pub fn forbids_guess(&self, domain: &str) -> bool {
        self.zero_guess_domains.iter().any(|d| *d == domain)
    }
}
```

### 2\. Canonical CID: `canonize -> BLAKE3`

```
use anyhow::Result;
use blake3;
use serde::Serialize;

pub fn cid_for_value<T: Serialize>(value: &T) -> Result<String> {
    let canon = logline::json_atomic::canonize(value)?;
    Ok(hex::encode(blake3::hash(&canon).as_bytes()))
}
```

For a complete atom, the CID must be computed with the `cid` field itself removed before hashing.

```
use serde_json::Value;

pub fn cid_for_atom_without_cid(v: &Value) -> Result<String> {
    let mut tmp = v.clone();
    if let Value::Object(ref mut m) = tmp {
        m.remove("cid");
    }
    cid_for_value(&tmp)
}

pub fn attach_cid(mut v: Value) -> Result<Value> {
    let cid = cid_for_atom_without_cid(&v)?;
    if let Value::Object(ref mut m) = v {
        m.insert("cid".into(), Value::String(cid));
    }
    Ok(v)
}
```

### 3\. Silicon proposes: `silicon_propose`

`SiliconProposal` represents admissible statistical computation, never terminal authority.

```
#[derive(Debug, Clone)]
pub struct SiliconProposal {
    /// score in Q16 (0..65535)
    pub score_q16: u32,
    /// estimated risk in Q16 (0..65535)
    pub risk_q16: u32,
    /// kernel/shader hash (provenance)
    pub kernel_hash: String,
}

pub fn silicon_propose(seed: u64, idx: u64) -> SiliconProposal {
    let mut r = rand_chacha::ChaCha20Rng::seed_from_u64(
        seed ^ idx.wrapping_mul(0x9E37),
    );
    let score_q16 = (r.next_u32() % 65_536) as u32;
    let mid = 52_000i64;
    let dist = (score_q16 as i64 - mid).abs().min(65_535) as u32;
    let risk_q16 = dist;

    SiliconProposal {
        score_q16,
        risk_q16,
        kernel_hash: "cpu_v1".into(),
    }
}
```

### 4\. The gate decides: `gate_run`

Here the central principle of this RFC becomes concrete: silicon offers possibility; the gate applies law.

```
pub const OK_MIN_Q16: u32 = 52_000;
pub const DOUBT_BELOW_Q16: u32 = 48_000;

pub const R_MISSING_EVIDENCE: u32 = 0x01;
pub const R_UNANCHORED: u32 = 0x02;
pub const R_POLICY_VIOLATION: u32 = 0x04;
pub const R_SILICON_DOUBT: u32 = 0x08;
pub const R_SILICON_NOT_OK: u32 = 0x10;

#[derive(Debug, Clone)]
pub struct GateInputs<'a> {
    pub domain: &'a str,
    pub has_intent: bool,
    pub has_evidence: bool,
    pub evidence_anchored: bool,
    pub policy_ok: bool,
    pub epoch: u64,
    pub contract: &'a ErrorContract,
}

#[derive(Debug, Clone)]
pub struct GateDecision {
    pub verdict: Verdict,
    pub reason_code: u32,
    pub question: Option<String>,
}

pub fn gate_run(inp: GateInputs, silicon: SiliconProposal) -> GateDecision {
    let mut reason = 0u32;

    if !inp.has_intent || !inp.has_evidence {
        reason |= R_MISSING_EVIDENCE;
        return GateDecision {
            verdict: Verdict::Ghost,
            reason_code: reason,
            question: Some("Which evidence is missing to confirm the case?".into()),
        };
    }

    if !inp.evidence_anchored {
        reason |= R_UNANCHORED;
        return GateDecision {
            verdict: Verdict::Reject,
            reason_code: reason,
            question: None,
        };
    }

    if !inp.policy_ok {
        reason |= R_POLICY_VIOLATION;
        return GateDecision {
            verdict: Verdict::Reject,
            reason_code: reason,
            question: None,
        };
    }

    if inp.contract.forbids_guess(inp.domain) {
        if silicon.score_q16 < OK_MIN_Q16 {
            reason |= R_SILICON_NOT_OK;
            return GateDecision {
                verdict: Verdict::Reject,
                reason_code: reason,
                question: None,
            };
        }

        return GateDecision {
            verdict: Verdict::Commit,
            reason_code: reason,
            question: None,
        };
    }

    if silicon.score_q16 < DOUBT_BELOW_Q16 {
        reason |= R_SILICON_DOUBT;
        return GateDecision {
            verdict: Verdict::Ghost,
            reason_code: reason,
            question: Some("There is material doubt: confirm the correct alternative.".into()),
        };
    }

    if silicon.score_q16 < OK_MIN_Q16 {
        reason |= R_SILICON_NOT_OK;
        return GateDecision {
            verdict: Verdict::Reject,
            reason_code: reason,
            question: None,
        };
    }

    GateDecision {
        verdict: Verdict::Commit,
        reason_code: reason,
        question: None,
    }
}
```

### 5\. Emitting replayable atoms in NDJSON

The example below demonstrates how a constitutional decision can be materialized as facts, sets, and a verifiable derivation.

```
use serde_json::{json, Value};

pub fn gate_run_atoms(seed: u64, idx: u64) -> anyhow::Result<Vec<Value>> {
    let contract = ErrorContract {
        epsilon: 0.05,
        zero_guess_domains: vec!["finance"],
        max_questions: 1,
    };

    let intent_fact = attach_cid(json!({
        "t": "atom.fact",
        "v": 1,
        "payload": {"kind": "intent", "idx": idx}
    }))?;

    let evidence_fact = attach_cid(json!({
        "t": "atom.fact",
        "v": 1,
        "payload": {"kind": "evidence", "idx": idx, "anchored": true}
    }))?;

    let policy_fact = attach_cid(json!({
        "t": "atom.fact",
        "v": 1,
        "payload": {"policy": {"epsilon": 0.05, "max_questions": 1}}
    }))?;

    let epoch_fact = attach_cid(json!({
        "t": "atom.fact",
        "v": 1,
        "payload": {"kind": "epoch", "seed": seed}
    }))?;

    let intent_set = attach_cid(json!({
        "t": "atom.set",
        "v": 1,
        "name": "gate:intent_set",
        "members": [intent_fact["cid"].as_str().unwrap()]
    }))?;

    let evidence_set = attach_cid(json!({
        "t": "atom.set",
        "v": 1,
        "name": "gate:evidence_set",
        "members": [evidence_fact["cid"].as_str().unwrap()]
    }))?;

    let silicon = silicon_propose(seed, idx);
    let silicon_fact = attach_cid(json!({
        "t": "atom.fact",
        "v": 1,
        "payload": {
            "kind": "silicon_output",
            "idx": idx,
            "score_q16": silicon.score_q16,
            "risk_q16": silicon.risk_q16,
            "kernel_hash": silicon.kernel_hash
        }
    }))?;

    let decision = gate_run(
        GateInputs {
            domain: "media",
            has_intent: true,
            has_evidence: true,
            evidence_anchored: true,
            policy_ok: true,
            epoch: seed,
            contract: &contract,
        },
        silicon,
    );

    let (outputs, output_atoms) = match decision.verdict {
        Verdict::Commit => {
            let verified_fact = attach_cid(json!({
                "t": "atom.fact",
                "v": 1,
                "payload": {"kind": "verified", "idx": idx}
            }))?;
            let commit_set = attach_cid(json!({
                "t": "atom.set",
                "v": 1,
                "name": "gate:commit_set",
                "members": [verified_fact["cid"].as_str().unwrap()]
            }))?;
            (
                json!([{"set": commit_set["cid"].as_str().unwrap()}]),
                vec![verified_fact, commit_set],
            )
        }
        Verdict::Ghost => {
            let ghost_fact = attach_cid(json!({
                "t": "atom.fact",
                "v": 1,
                "payload": {"kind": "ghost", "idx": idx, "q": decision.question}
            }))?;
            let ghost_set = attach_cid(json!({
                "t": "atom.set",
                "v": 1,
                "name": "gate:ghost_set",
                "members": [ghost_fact["cid"].as_str().unwrap()]
            }))?;
            (
                json!([{"set": ghost_set["cid"].as_str().unwrap()}]),
                vec![ghost_fact, ghost_set],
            )
        }
        Verdict::Reject => {
            let reject_fact = attach_cid(json!({
                "t": "atom.fact",
                "v": 1,
                "payload": {"kind": "reject", "idx": idx, "reason": decision.reason_code}
            }))?;
            (
                json!([{"fact": reject_fact["cid"].as_str().unwrap()}]),
                vec![reject_fact],
            )
        }
    };

    let deriv = attach_cid(json!({
        "t": "atom.derivation",
        "v": 1,
        "z": "gate:v1",
        "op": "gate_run",
        "inputs": [
            {"set": intent_set["cid"].as_str().unwrap()},
            {"set": evidence_set["cid"].as_str().unwrap()},
            {"fact": policy_fact["cid"].as_str().unwrap()},
            {"fact": epoch_fact["cid"].as_str().unwrap()},
            {"fact": silicon_fact["cid"].as_str().unwrap()}
        ],
        "params": {"seed": seed, "idx": idx, "epsilon": contract.epsilon},
        "outputs": outputs
    }))?;

    let mut atoms = vec![
        intent_fact,
        evidence_fact,
        policy_fact,
        epoch_fact,
        intent_set,
        evidence_set,
        silicon_fact,
    ];
    atoms.extend(output_atoms);
    atoms.push(deriv);
    Ok(atoms)
}
```

### 6\. Verification by replay

The verifier does not interpret hidden intentions. It reexecutes the derivation and compares what history claims with what law produces.

```
use std::collections::HashMap;

pub fn verify_gate_run(
    deriv: &Value,
    by_cid: &HashMap<String, Value>,
) -> anyhow::Result<()> {
    let seed = deriv["params"]["seed"].as_u64().unwrap();
    let idx = deriv["params"]["idx"].as_u64().unwrap();

    let contract = ErrorContract {
        epsilon: 0.05,
        zero_guess_domains: vec![],
        max_questions: 1,
    };

    let silicon = silicon_propose(seed, idx);
    let decision = gate_run(
        GateInputs {
            domain: "media",
            has_intent: true,
            has_evidence: true,
            evidence_anchored: true,
            policy_ok: true,
            epoch: seed,
            contract: &contract,
        },
        silicon,
    );

    let outputs = deriv["outputs"].as_array().unwrap();
    match decision.verdict {
        Verdict::Commit => {
            let out_set = outputs[0]["set"].as_str().unwrap();
            let set = &by_cid[out_set];
            if set["name"] != "gate:commit_set" {
                anyhow::bail!("wrong output set");
            }
        }
        Verdict::Ghost => {
            let out_set = outputs[0]["set"].as_str().unwrap();
            let set = &by_cid[out_set];
            if set["name"] != "gate:ghost_set" {
                anyhow::bail!("wrong output set");
            }
        }
        Verdict::Reject => {
            let out_fact = outputs[0]["fact"].as_str().unwrap();
            let fact = &by_cid[out_fact];
            if fact["payload"]["kind"] != "reject" {
                anyhow::bail!("wrong reject fact");
            }
        }
    }

    Ok(())
}
```

* * *

Note on Scale
-------------

The Constitution does not forbid mass; it forbids irresponsibility.

To scale to hundreds of millions of cases on modest hardware:

*   `silicon_propose` may migrate to `wgpu compute`;
*   the gate may remain light and verifiable on CPU;
*   outputs may be compacted by rollup, sampling, and `batch_hash`;
*   proof continues to govern even as throughput grows.

Legitimate scale is compaction of truth, not suppression of trail.

* * *

Minimum conformance
-------------------

An implementation may claim to honor this Constitution only if, at minimum:

*   every computation ends in `Commit`, `Ghost`, or `Reject`;
*   no result is promoted without an admissible contract, receipt, or proof;
*   ambiguity, timeout, and low confidence are never treated as implicit commit;
*   sovereign state remains local, verifiable, and never replaced by model narrative;
*   CIDs, receipts, and replay remain the foundations of legitimacy.

This RFC establishes, therefore, not only a technique but a regime.  
It marks the point at which performance ceases to be sovereign and enters the service of verifiable truth.

* * *

