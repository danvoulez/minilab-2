RFC-0008 — Jurisdiction from Duty and Sorrow
============================================

**Status:** Normative draft.  
In this RFC, the terms **must**, **must not**, **forbidden**, and their equivalents carry normative force equivalent to **MUST / MUST NOT**.

Summary
-------

If RFC-0001 established law, RFC-0002 established proof, RFC-0003 established epistemic space, RFC-0004 established federation, RFC-0005 established government, RFC-0006 established bounded labour, and RFC-0007 established economic legibility, this RFC establishes the final jurisdiction of consequence.

The human is not placed at the top of the system because the human is more reliable than the model, the worker, the manager, or the machine.

The human is not more reliable.

The human remains the final jurisdiction only where non-transferable consequence still survives computation: legal consequence, civil consequence, regulatory consequence, institutional consequence, bodily consequence, and moral burden that cannot be discharged by the machine.

Where duty cannot be delegated and consequence can still be suffered, final authority must remain.

That is the human place in the architecture.

* * *

0\. Status
----------

Normative draft.

* * *

1\. Normative thesis
--------------------

The final commit of a jurisdiction-bearing case must belong to the party that bears non-transferable consequence.

The system may:

*   establish law by text and contract;
*   execute rule by bounded runtime;
*   produce proposals by silicon;
*   advise by model;
*   coordinate by manager;
*   verify by proof;
*   preserve by receipt and transcript;
*   and expose cost by economic envelope.

But none of those may claim final jurisdiction merely by performing well.

Final jurisdiction belongs where duty is real and consequence is borne.

The human does not rule because the human is infallible.  
The human rules only where the human remains answerable after the machine is done speaking.

* * *

2\. Invariants
--------------

**I1 — Accountability outranks fluency**

No model, worker, manager, or protocol surface may exercise final consequential commitment unless a responsible human authority remains identifiable.

**I2 — Final signature follows consequence**

Where only one party can still be sanctioned, removed, sued, blamed, punished, injured, or otherwise held to answer for the outcome, that party is the rightful locus of final signature.

**I3 — Advice is not jurisdiction**

LLM analysis, expert scoring, bounded silicon execution, managerial recommendation, and policy suggestion may inform final action, but none of them constitutes final authority.

**I4 — Duty is not transferable by convenience**

Operational delegation does not transfer jurisdiction. Convenience, automation, throughput, and scale do not dissolve responsibility.

**I5 — Suffering is part of the jurisdictional test**

The system must distinguish between what can compute, what can advise, and what can still suffer the consequence of a wrong commit. Only the last category may close certain classes of decision.

**I6 — Jurisdiction must remain legible**

A final human act must remain transcript-visible as an attributable act of ratification, authorization, refusal, suspension, or escalation, together with duty class, consequence class, signer identity, and signature.

**I7 — Human jurisdiction remains under law**

The human signer is not above contract, proof, transcript, or policy. Human jurisdiction is constrained jurisdiction.

**I8 — No implicit finality**

Absence of signer, timeout, silence, UI confirmation without accountable signature, or passive exposure to a recommendation must never count as final human commitment.

* * *

3\. The three powers
--------------------

The architecture recognizes three distinct powers, each with a different office.

### 3.1 Text establishes the law

Text and contract define:

*   admissibility;
*   constraints;
*   procedures;
*   thresholds;
*   prohibited moves;
*   burden classes;
*   and the shape of proof.

Text governs because law must not improvise.

### 3.2 Model analyzes and advises

The model:

*   compresses;
*   explores;
*   compares;
*   proposes;
*   prioritizes;
*   and advises.

The model is useful precisely because it is plastic.  
It must not rule for the same reason.

### 3.3 Human signs where consequence remains

The human:

*   ratifies;
*   authorizes;
*   refuses;
*   suspends;
*   escalates;
*   or records structured dissent.

The human does not decide because humans are pure, wise, or trustworthy in themselves.

Humans are not trustworthy in themselves.

The human decides only where the human remains exposed to the world after the computation ends.

* * *

4\. Jurisdictional threshold
----------------------------

Not every commit deserves the same human burden.

This RFC therefore distinguishes between two broad classes of finality.

### 4.1 Fully governable commits

A commit may become final without human signoff only when all of the following are true:

*   proof is complete;
*   law is satisfied;
*   the consequence is low or meaningfully reversible;
*   no named party remains non-transferably answerable beyond the machine boundary;
*   the governing policy explicitly permits automatic promotion;
*   and the action does not affect protected rights, bodily safety, legal standing, or institution-binding obligation.

### 4.2 Jurisdiction-bearing commits

A commit must require explicit human signature when any of the following is true:

*   consequence is high;
*   reversibility is low or absent;
*   protected rights are affected;
*   legal, civil, regulatory, or disciplinary exposure remains;
*   institutional standing or binding obligation is created or altered;
*   bodily integrity, health, or life is implicated;
*   irreversible action is taken;
*   or a named human or institution remains answerable beyond the system boundary.

The system must classify this threshold explicitly.  
It must not pretend that all commits are equal merely because all commits are computable.

* * *

5\. The sorrow test
-------------------

This RFC introduces a practical jurisdictional test:

**Who here can still suffer for this commit?**

This test may also be expressed in operational form as the non-transferable consequence test.

The answer may include:

*   legal exposure;
*   regulatory exposure;
*   civil liability;
*   disciplinary or institutional penalty;
*   reputational destruction;
*   bodily harm;
*   economic ruin;
*   or moral burden that cannot be discharged by the machine.

Where such exposure remains human, final authority must remain human.

This is not sentimentality.  
It is an architectural recognition that consequence has not yet been virtualized.

The system may represent consequence.  
Only the signer may still have to live it.

* * *

6\. Duty, burden, and final signature
-------------------------------------

The final signature is not a decorative approval step.  
It is the visible location where burden becomes attributable.

```
pub struct JurisdictionEnvelope {
    pub case_cid: String,
    pub proofpack_cid: String,
    pub recommendation_cid: String,
    pub signer_id: String,
    pub signer_role: String,
    pub authority_cid: String,
    pub duty_class: DutyClass,
    pub consequence_class: ConsequenceClass,
    pub verdict: HumanVerdict,
    pub justification_cid: Option<String>,
    pub signature: String,
}

pub enum DutyClass {
    RoutineOperational,
    Financial,
    Legal,
    Medical,
    Governance,
    IrreversibleAction,
}

pub enum ConsequenceClass {
    ReversibleLow,
    MaterialHigh,
    RightsAffecting,
    InstitutionBinding,
    BodyOrLifeAffecting,
}

pub enum HumanVerdict {
    Ratify,
    Authorize,
    Refuse,
    Suspend,
    Escalate,
}
```

**Rules**

*   `Refuse`, `Suspend`, and `Escalate` must carry `justification_cid`.
*   `Authorize` must carry `justification_cid`.
*   `Ratify` may omit `justification_cid` only when the governing proof, recommendation, threshold classification, and consequence class already make the act sufficiently legible under policy.
*   Any signature over a jurisdiction-bearing commit must bind signer identity, authority scope, case identity, proof identity, and verdict.

The purpose of this envelope is not to glorify the human.  
It is to make visible where consequence finally lands.

* * *

7\. The human is not trusted
----------------------------

This RFC rejects the romantic fiction that the human is the safe part.

The human is:

*   biased;
*   tired;
*   vain;
*   fearful;
*   corruptible;
*   forgetful;
*   and often wrong.

So is the model, in its own way.

Therefore the architecture does not place the human above law.

It places the human under law, under proof, under receipt, under transcript, and under visible signature.

The human remains the final jurisdiction not because the human is good, but because the human remains punishable, removable, sanctionable, and accountable in a way the model does not.

* * *

8\. Human ratification under proof
----------------------------------

A human signature is valid only when it stands over a legible case.

This means the human authority must receive, at minimum:

*   the governing contract or rule-set;
*   the proof-bearing transcript or proof pack;
*   the recommendation, proposal, or computed basis;
*   the threshold classification that explains why the case is jurisdiction-bearing or auto-finalizable;
*   the relevant grounds for ratification, authorization, refusal, suspension, or escalation;
*   and the consequence class of the action.

The system must not ask the human to sign blind.  
Nor may it allow the human to dissolve proof by whim.

The right human place is neither ornamental approval nor arbitrary override.  
It is constrained jurisdiction under proof.

* * *

9\. Signer authority
--------------------

Not every human may sign every burden.

A jurisdictional signature is valid only when exercised by a recognized signer authority.

```
pub struct SignerAuthority {
    pub signer_id: String,
    pub roles: Vec<String>,
    pub allowed_duty_classes: Vec<DutyClass>,
    pub allowed_consequence_classes: Vec<ConsequenceClass>,
    pub may_ratify: bool,
    pub may_authorize: bool,
    pub may_refuse: bool,
    pub may_suspend: bool,
    pub may_escalate: bool,
    pub valid_from_epoch: u64,
    pub valid_until_epoch: Option<u64>,
}
```

**Rules**

*   the signer must be identifiable;
*   the signer must be valid for the relevant epoch;
*   the signer role must match the active authority grant;
*   the signer may not sign beyond the allowed duty and consequence classes;
*   absence of valid authority must block final signature;
*   the authority artifact must itself be transcript-resolvable and auditable.

Operational delegation does not create signer authority by implication.

* * *

10\. Jurisdiction decision
--------------------------

The system must explicitly determine whether a case may finalize automatically or requires human signoff.

```
pub enum JurisdictionDecision {
    AutoFinalizable,
    RequiresHumanSignature {
        duty_class: DutyClass,
        consequence_class: ConsequenceClass,
        minimum_signer_role: String,
    },
}
```

Recommended supporting structure:

```
pub struct JurisdictionThreshold {
    pub reversibility_low: bool,
    pub rights_affected: bool,
    pub bodily_risk: bool,
    pub legal_exposure: bool,
    pub institutional_binding: bool,
    pub named_accountable_party: bool,
}
```

**Rule**

If any active policy marks the case as jurisdiction-bearing, the commit must not become institutionally final without valid human signature.

A model, manager, or worker recommendation may not silently collapse `RequiresHumanSignature` into `AutoFinalizable`.

* * *

11\. Refusal, suspension, escalation, and dissent
-------------------------------------------------

Human jurisdiction includes the right to refuse.

A responsible signer may:

*   refuse a recommendation;
*   suspend a commit;
*   request further evidence;
*   escalate the case to a higher or different authority;
*   or record structured dissent.

This is not a defect in the system.  
It is part of the constitutional architecture.

A regime that permits only automatic assent has confused execution with authority.

A jurisdictional act that blocks, reopens, redirects, or defers a case must remain legible as an attributable act, not merely visible as an event.

For this reason, refusal, suspension, escalation, and dissent must remain justification-bearing, transcript-visible, and attributable.

```
pub struct StructuredDissent {
    pub case_cid: String,
    pub signer_id: String,
    pub verdict: HumanVerdict,
    pub reason_codes: Vec<String>,
    pub justification_cid: String,
    pub signature: String,
}
```

**Rules**

*   `StructuredDissent` must be preserved in transcript;
*   reason codes may be policy-defined, domain-specific, or institution-specific;
*   free text may supplement but must not replace structured grounds when structured grounds are available;
*   dissent must not be silently discarded after later approval.

* * *

12\. What the signer may not do
-------------------------------

Human jurisdiction is real, but it is not arbitrary sovereignty.

A signer must not:

*   ratify a jurisdiction-bearing commit without minimum proof visibility;
*   sign beyond granted authority scope;
*   silently reclassify a jurisdiction-bearing case as auto-finalizable;
*   suppress dissent, refusal, suspension, or escalation artifacts;
*   impersonate another authority;
*   sign on behalf of an absent signer without explicit delegated legal structure recognized by policy;
*   replace transcript-visible proof with private rationale as sole basis of finality;
*   or convert recommendation into final action without attributable act of signature.

Human authority remains bounded by law, proof, transcript, and grant.

* * *

13\. Ratification and authorization
-----------------------------------

This RFC distinguishes two related but non-identical acts.

### 13.1 Ratification

`Ratify` confirms a commit whose legal, procedural, and operational path is already mature under the active law and proof, but which still requires accountable human closure due to consequence class.

### 13.2 Authorization

`Authorize` permits a commit whose final institutional effect requires an explicit act of empowered human permission, even where the proof and recommendation are sufficient.

**Rule**

The active policy must specify whether a given consequence class requires `Ratify` or `Authorize`.  
No implementation may treat these as equivalent by default.

* * *

14\. Multi-signature and quorum human authority
-----------------------------------------------

Some consequence classes may require more than one signer.

```
pub enum HumanFinalityMode {
    SingleSigner,
    DualControl,
    Quorum { required_signatures: u8 },
}
```

**Rules**

*   `BodyOrLifeAffecting`, `InstitutionBinding`, and selected `Legal` or `Governance` actions may require dual control or quorum under policy;
*   required signers must be distinct recognized authorities;
*   quorum must be explicit and auditable;
*   insufficient signatures must block finality;
*   partial signature must remain visible as incomplete, never final.

The architecture must preserve the possibility that the gravity of consequence exceeds the legitimacy of single-handed closure.

* * *

15\. The cost of finality
-------------------------

The system must not hide the cost of asking a human to sign.

Human finality is expensive:

*   slower;
*   heavier;
*   more institutionally charged;
*   and often more emotionally costly than automated continuation.

That cost is not a defect.

It is the visible price of committing where consequence still exceeds what the machine may rightfully absorb.

In low-consequence domains, this cost should be minimized.  
In high-consequence domains, this cost should be preserved.

* * *

16\. Interactions with earlier RFCs
-----------------------------------

### 16.1 With RFC-0001

RFC-0001 establishes the law of `Commit`, `Ghost`, and `Reject`.  
RFC-0008 determines when a valid commit still requires human ratification or authorization before becoming institutionally final.

### 16.2 With RFC-0002

RFC-0002 produces proof-bearing process.  
RFC-0008 determines who may sign over that proof when consequence cannot be delegated.

### 16.3 With RFC-0005

RFC-0005 gives the Manager Plane authority to govern continuations.  
RFC-0008 limits that authority at the boundary where management ends and accountable signature begins.

### 16.4 With RFC-0006

RFC-0006 contains labour under sandbox and yield.  
RFC-0008 contains finality under burden.

### 16.5 With RFC-0007

RFC-0007 makes work economically legible.  
RFC-0008 makes consequence jurisdictionally legible.

* * *

17\. Suggested crate layout
---------------------------

```
jurisdiction/
  src/
    lib.rs
    envelope.rs       # JurisdictionEnvelope, HumanVerdict
    burden.rs         # DutyClass, ConsequenceClass
    threshold.rs      # JurisdictionDecision, JurisdictionThreshold
    authority.rs      # SignerAuthority
    dissent.rs        # StructuredDissent
    signature.rs      # signer identity and accountable attestation
    quorum.rs         # HumanFinalityMode
```

`lib.rs`:

```
pub mod authority;
pub mod burden;
pub mod dissent;
pub mod envelope;
pub mod quorum;
pub mod signature;
pub mod threshold;
```

* * *

18\. Normative mantra
---------------------

Law governs.  
Models advise.  
Humans sign where consequence remains.

Hard form:

*   text establishes the law;
*   contract and proof constrain the case;
*   the model analyzes and advises;
*   the manager coordinates but does not close jurisdiction-bearing consequence;
*   the human signs where duty cannot be transferred;
*   final authority belongs where consequence can still be suffered.

* * *

Minimum conformance
-------------------

An implementation is minimally conformant only if it:

*   identifies which classes of commit are jurisdiction-bearing;
*   binds final ratification or authorization to a named human authority;
*   records duty class and consequence class for the act;
*   preserves proof, recommendation, authority, and signature together;
*   requires justification for refusal, suspension, escalation, and authorization;
*   allows refusal, suspension, escalation, and dissent as legitimate outcomes;
*   prevents model or manager outputs from silently impersonating final signature;
*   validates signer authority against scope and epoch;
*   and preserves incomplete or failed signoff as non-final.

* * *

Failure modes
-------------

The implementation must distinguish at least:

*   absence of accountable signer for a jurisdiction-bearing commit;
*   invalid or expired signer authority;
*   ratification or authorization without sufficient proof visibility;
*   refusal, suspension, or escalation without justification trail;
*   silent promotion of advisory output into final action;
*   forged, ambiguous, or non-attributable signature;
*   signoff beyond allowed duty or consequence class;
*   quorum required but not satisfied;
*   refusal or escalation path not preserved in the transcript.

None of these may result in implicit finality.

* * *

Security
--------

The minimum guarantees are:

*   final signature remains attributable to a specific human authority;
*   advisory systems cannot impersonate jurisdiction;
*   proof remains visible at the point of ratification or authorization;
*   responsibility is not erased by automation layers;
*   refusal, suspension, escalation, and dissent remain transcript-visible;
*   justification-bearing acts remain attributable where they interrupt or redirect finality;
*   authority scope and validity remain auditable;
*   and no UI surface may convert passive acknowledgement into accountable signature.

* * *

Architectural verdict
---------------------

With this RFC, the system acknowledges what computation cannot abolish.

Text may govern.  
Proof may justify.  
Workers may execute.  
Managers may coordinate.  
Models may advise.

But where duty remains non-transferable and consequence remains sufferable, jurisdiction must still have a human face.

This is not a concession to nostalgia.

It is the final refusal to confuse intelligence with authority, automation with legitimacy, performance with the right to decide, or recommendation with accountable signature.

* * *

