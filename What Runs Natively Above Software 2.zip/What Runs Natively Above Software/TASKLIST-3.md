# TASKLIST 3

## Persistence + Replay + Epistemic Auditability

This tranche belongs to `Cycle 3`.

Its question is already frozen in the governed experiment package:

- [`docs/experiments/cycle-3/EXPERIMENT_CHARTER.md`](/Users/ubl-ops/What%20Runs%20Natively%20Above%20Software/docs/experiments/cycle-3/EXPERIMENT_CHARTER.md)
- [`docs/experiments/cycle-3/METHODOLOGY_SPEC.md`](/Users/ubl-ops/What%20Runs%20Natively%20Above%20Software/docs/experiments/cycle-3/METHODOLOGY_SPEC.md)

The implementation rule for this tasklist is simple:

Persist, rehydrate, replay, and audit without semantic drift.

This is not a generic storage expansion. It is the first persistence tranche that belongs to the same legitimacy circuit:

persisted epistemic state -> restart -> replay -> audited equivalence.

## T3.1 - Introduce the local persistent store

Objective: give the epistemic state durable survival across process boundaries.

Preferred shape:

- a typed persistence interface in `epistemic-storage`
- a first local backend using SQLite
- persistence for:
  - `EpistemicGraph`
  - ghost lifecycle state
  - closure receipts / transitions needed for replay
  - minimal case heads / pointers needed to resume

Expected API surface:

- `save_graph`
- `load_graph`
- `save_case_state`
- `load_case_state`
- `append_receipt`
- `load_receipts`

Done when:

- a case can be saved
- the process can stop
- the state can be loaded again intact

## T3.2 - Persist the full Ghost lifecycle

Objective: make `GhostRecord` a durable object, not only a local step effect.

Persist at minimum:

- `Open`
- `Resolved`
- `Waived`, if present in the current model
- `resolution_ref`
- `opened_from`
- `required_for`
- minimal timestamps or lineage needed for audit

Done when:

- an open ghost remains open after restart
- a resolved ghost remains resolved after restart
- its provenance survives reload in a readable way

## T3.3 - Make grounding auditably visible

Objective: grounding must survive restart and replay as inspectable evidence, not remain an opaque in-memory calculation.

Add grounding metadata to the relevant epistemic receipts, at minimum:

- `EpistemicClosureEvaluated`
- `EpistemicClosureTransition`

Persist that metadata with the replayable state.

Done when:

- after reload, the system can inspect prior grounding values without hidden recomputation
- replay reports can compare closure outcomes together with their grounding evidence

## T3.4 - Implement rehydration and replay equivalence

Objective: prove that persistence preserves meaning, not just bytes.

Required flow:

1. run a live case
2. persist graph, ghost state, and case state
3. restart runtime
4. reload persisted state
5. replay or re-evaluate
6. compare live and replay outcomes

Minimum equivalence report:

- verdict equivalence
- ghost state equivalence
- pointer eligibility equivalence
- closure transition equivalence
- replay divergence count

Done when:

- lawful `Commit` survives replay
- lawful `Ghost -> Commit` survives replay
- adversarial `Reject` survives replay
- any semantic drift fails explicitly

## T3.5 - Institutionalize the Stage 1 fixtures in Rust

Objective: turn the early epistemic scenarios into native regression fixtures for persistence and replay.

Add Rust-native fixtures or builders for:

- `complete`
- `honest_doubt`
- `hallucination`
- `paranoia`

Use them both for:

- live runtime behavior checks
- persistence + replay equivalence checks

Done when:

- the four scenarios run natively in Rust
- they also serve as replay regression tests

## T3.6 - Close the tranche with documentation and methodological memory

Objective: land code and proof together.

Update at minimum:

- `docs/IMPLEMENTATION_STATUS.md`
- `docs/EPISTEMIC_RUNTIME.md`
- `docs/experiments/cycle-3/COMPARATIVE_NOTE.md`
- `docs/experiments/cycle-3/DECISION_NOTE.md`

Use the automated governance tools where helpful, but keep final interpretation honest and human-reviewed.

Done when:

- implementation status reflects the persistence tranche truthfully
- replay equivalence results are recorded in governed cycle docs
- freeze conditions can be evaluated without reconstructing the history manually

## What does not enter this tasklist

Keep these out unless they become structurally necessary for persistence correctness:

- full nine-field cell redesign
- federation hardening
- production networking or replication transport
- real WASM worker backend
- expanded policy packs or jurisdiction redesign
- new proposer/model comparisons
- UI/demo work

The rule is:

Only include work that belongs to the same legitimacy circuit:

persist -> rehydrate -> replay -> audit -> compare

## Recommended commit order

1. `epistemic-storage: add sqlite-backed persistence for graph and ghosts`
2. `proof-runtime: persist grounding and closure receipts`
3. `runtime: add rehydration and replay equivalence flow`
4. `tests: add stage-1 canonical fixtures in rust`
5. `docs: update cycle-3 status and epistemic runtime`

## Exit gate

Do not claim `Cycle 3` closed until all of the following are true:

- persistent state survives process restart
- replay preserves lawful `Commit`
- replay preserves lawful `Ghost -> Commit`
- replay preserves adversarial `Reject`
- no silent pointer promotion mismatch is observed
- grounding evidence remains inspectable after reload
- governed cycle documents record the result explicitly
