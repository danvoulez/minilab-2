# Architecture

## Constitutional Shape

This workspace is not a feature bundle. It is a constitutional stack.

1. `constitution-gate`: law of result, error contract, and no-guess gate.
2. `proof-runtime`: sessioned decision as proof process.
3. `epistemic-storage`: immutable atoms, CAS, heat, pointers.
4. `proof-federation`: proof-carrying pointer advances and fork visibility.
5. `manager-plane`: typed event-driven orchestration, non-chat.
6. `worker-abi`: sandboxed worker execution and yield semantics.
7. `economic-fields`: transcript-linked conserved work.
8. `jurisdiction`: signer authority and consequence-bearing finality.
9. `efficiency-allocation`: doctrine of office allocation and misallocation detection.
10. `horizon-real`: actuation interlocks, sensor quorum, entropy boundary.

These crates are offices, not convenience modules. If a change does not preserve this office separation, it is architecturally incorrect.

## Dependency Graph

- `constitution-gate` -> none
- `epistemic-storage` -> none
- `proof-runtime` -> `constitution-gate`, `epistemic-storage`
- `proof-federation` -> `proof-runtime`, `epistemic-storage`
- `worker-abi` -> `epistemic-storage`
- `manager-plane` -> `proof-runtime`, `proof-federation`, `worker-abi`
- `economic-fields` -> `proof-runtime`
- `jurisdiction` -> `economic-fields`, `proof-runtime`
- `efficiency-allocation` -> none
- `horizon-real` -> `jurisdiction`, `worker-abi`

No reverse authority dependencies are permitted.

Forbidden direction examples:
- `constitution-gate` depending on runtime/manager/jurisdiction crates.
- `worker-abi` depending on manager-plane policy logic.
- `efficiency-allocation` becoming a transitive utility crate.

## Implemented vs Deferred

Implemented in v0:
- Canonical types, traits, and contracts per layer.
- Thin executable slices for gate/runtime/storage/federation/worker/economics/jurisdiction/horizon.
- Boundary and invariant tests.

Deferred by design:
- Production networking and cryptography details in federation.
- Real hardware sandbox backends (WASM/WGPU implementations beyond trait surface).
- Persistent storage engines and distributed transport.
- Institution-specific policy packs and signer infrastructure.
- Monetary/token layers beyond transcript-linked gas accounting.

## Adding New Capability Without Violating Doctrine

1. Locate the correct constitutional layer first.
2. Add typed contract before implementation detail.
3. Preserve replay and transcript visibility.
4. Keep cross-layer dependencies one-way.
5. Add invariant tests in the owning crate.
6. Prefer stronger domain types over raw strings when identity/signature semantics matter.
