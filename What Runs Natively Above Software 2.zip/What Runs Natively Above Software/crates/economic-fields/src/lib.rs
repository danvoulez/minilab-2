//! RFC-0007 economic fields: transcript-linked conserved work, not currency.

use blake3::Hasher;
use proof_runtime::StepReceipt;
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NodeId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Hash(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReceiptEnvelope {
    pub executor: NodeId,
    pub beneficiary: NodeId,
    pub gas_cost: u64,
    pub contract_hash: Hash,
    pub receipt: StepReceipt,
}

impl ReceiptEnvelope {
    #[must_use]
    pub fn canonical_hash(&self) -> Hash {
        let mut hasher = Hasher::new();
        let json = serde_json::to_vec(self).expect("receipt envelope is serializable");
        hasher.update(&json);
        Hash(hex::encode(hasher.finalize().as_bytes()))
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TranscriptEntry {
    pub envelope: ReceiptEnvelope,
    pub prev_hash: Option<Hash>,
    pub entry_hash: Hash,
    pub budget_before: u64,
    pub budget_after: u64,
    pub state_root_before: Hash,
    pub state_root_after: Hash,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EconomicSummary {
    pub executor_id: NodeId,
    pub beneficiary_id: NodeId,
    pub total_gas_spent: u64,
    pub gas_remaining: u64,
    pub step_count: u64,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum EconomicError {
    #[error("budget underrun: gas_cost={gas_cost}, remaining={remaining}")]
    BudgetUnderrun { gas_cost: u64, remaining: u64 },
}

#[doc = "UNSTABLE_V0"]
pub struct EconomicTranscript {
    initial_budget: u64,
    gas_remaining: u64,
    entries: Vec<TranscriptEntry>,
}

impl EconomicTranscript {
    #[must_use]
    pub fn new(initial_budget: u64) -> Self {
        Self {
            initial_budget,
            gas_remaining: initial_budget,
            entries: Vec::new(),
        }
    }

    pub fn append_envelope(
        &mut self,
        envelope: ReceiptEnvelope,
        state_root_before: Hash,
        state_root_after: Hash,
    ) -> Result<(), EconomicError> {
        if envelope.gas_cost > self.gas_remaining {
            return Err(EconomicError::BudgetUnderrun {
                gas_cost: envelope.gas_cost,
                remaining: self.gas_remaining,
            });
        }
        let budget_before = self.gas_remaining;
        self.gas_remaining -= envelope.gas_cost;
        let budget_after = self.gas_remaining;
        let prev_hash = self.entries.last().map(|entry| entry.entry_hash.clone());
        let entry_hash = hash_entry(
            &envelope,
            prev_hash.as_ref(),
            budget_before,
            budget_after,
            &state_root_before,
            &state_root_after,
        );
        self.entries.push(TranscriptEntry {
            envelope,
            prev_hash,
            entry_hash,
            budget_before,
            budget_after,
            state_root_before,
            state_root_after,
        });
        Ok(())
    }

    #[must_use]
    pub fn entries(&self) -> &[TranscriptEntry] {
        &self.entries
    }

    #[must_use]
    pub fn summary(&self) -> Option<EconomicSummary> {
        let first = self.entries.first()?;
        let total_gas_spent: u64 = self
            .entries
            .iter()
            .map(|entry| entry.envelope.gas_cost)
            .sum();
        Some(EconomicSummary {
            executor_id: first.envelope.executor.clone(),
            beneficiary_id: first.envelope.beneficiary.clone(),
            total_gas_spent,
            gas_remaining: self.gas_remaining,
            step_count: u64::try_from(self.entries.len()).expect("entries length fits in u64"),
        })
    }

    #[must_use]
    pub fn verify_conservation(&self) -> bool {
        let total: u64 = self
            .entries
            .iter()
            .map(|entry| entry.envelope.gas_cost)
            .sum();
        total == self.initial_budget.saturating_sub(self.gas_remaining)
    }
}

fn hash_entry(
    envelope: &ReceiptEnvelope,
    prev_hash: Option<&Hash>,
    budget_before: u64,
    budget_after: u64,
    state_root_before: &Hash,
    state_root_after: &Hash,
) -> Hash {
    let payload = serde_json::json!({
        "envelope": envelope,
        "prev_hash": prev_hash,
        "budget_before": budget_before,
        "budget_after": budget_after,
        "state_root_before": state_root_before,
        "state_root_after": state_root_after
    });
    let mut hasher = Hasher::new();
    hasher.update(
        serde_json::to_string(&payload)
            .expect("entry payload is serializable")
            .as_bytes(),
    );
    Hash(hex::encode(hasher.finalize().as_bytes()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn envelope_chain_and_conservation_are_verified() {
        let mut econ = EconomicTranscript::new(20);
        let envelope = ReceiptEnvelope {
            executor: NodeId("node-a".to_owned()),
            beneficiary: NodeId("node-b".to_owned()),
            gas_cost: 7,
            contract_hash: Hash("contract".to_owned()),
            receipt: StepReceipt::Computed {
                receipt_cid: "r-1".to_owned(),
            },
        };
        econ.append_envelope(
            envelope,
            Hash("state-before".to_owned()),
            Hash("state-after".to_owned()),
        )
        .expect("append should succeed");
        assert_eq!(econ.entries().len(), 1);
        assert!(econ.verify_conservation());
        let summary = econ.summary().expect("summary should exist");
        assert_eq!(summary.total_gas_spent, 7);
        assert_eq!(summary.gas_remaining, 13);
    }
}
