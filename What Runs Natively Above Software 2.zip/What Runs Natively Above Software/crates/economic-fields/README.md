# economic-fields

RFC-0007 implementation surface:
- `ReceiptEnvelope` as economic truth unit
- transcript hash chain with gas fields
- conservation and summary checks
