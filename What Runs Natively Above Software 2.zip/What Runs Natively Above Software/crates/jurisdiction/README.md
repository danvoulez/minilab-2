# jurisdiction

RFC-0008 implementation surface:
- jurisdiction thresholding
- signer authority validation
- finality envelope and quorum semantics
