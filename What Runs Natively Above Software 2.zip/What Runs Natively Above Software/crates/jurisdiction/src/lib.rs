//! RFC-0008 jurisdiction layer: attributable human finality under proof.

use economic_fields::Hash;
use proof_runtime::ProofPack;
use serde::{Deserialize, Serialize};
use thiserror::Error;

/// Case identity in the jurisdiction envelope.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CaseCid(pub String);

/// Proof artifact identity bound to the signature act.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProofPackCid(pub String);

/// Recommendation artifact identity shown to the signer.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RecommendationCid(pub String);

/// Signer identity carrying accountable burden.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SignerId(pub String);

/// Signer role value evaluated against granted authority.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RoleName(pub String);

/// Authority artifact identity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuthorityCid(pub String);

/// Signature blob used for accountable attestation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Signature(pub String);

/// Final human closure event over a proof-bearing case.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct JurisdictionEnvelope {
    pub case_cid: CaseCid,
    pub proofpack_cid: ProofPackCid,
    pub recommendation_cid: RecommendationCid,
    pub signer_id: SignerId,
    pub signer_role: RoleName,
    pub authority_cid: AuthorityCid,
    pub duty_class: DutyClass,
    pub consequence_class: ConsequenceClass,
    pub verdict: HumanVerdict,
    pub justification_cid: Option<String>,
    pub signature: Signature,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum DutyClass {
    RoutineOperational,
    Financial,
    Legal,
    Medical,
    Governance,
    IrreversibleAction,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ConsequenceClass {
    ReversibleLow,
    MaterialHigh,
    RightsAffecting,
    InstitutionBinding,
    BodyOrLifeAffecting,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum HumanVerdict {
    Ratify,
    Authorize,
    Refuse,
    Suspend,
    Escalate,
}

/// Granted scope for a signer identity and role set.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SignerAuthority {
    pub signer_id: SignerId,
    pub roles: Vec<RoleName>,
    pub allowed_duty_classes: Vec<DutyClass>,
    pub allowed_consequence_classes: Vec<ConsequenceClass>,
    pub may_ratify: bool,
    pub may_authorize: bool,
    pub may_refuse: bool,
    pub may_suspend: bool,
    pub may_escalate: bool,
    pub valid_from_epoch: u64,
    pub valid_until_epoch: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum JurisdictionDecision {
    AutoFinalizable,
    RequiresHumanSignature {
        duty_class: DutyClass,
        consequence_class: ConsequenceClass,
        minimum_signer_role: RoleName,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct JurisdictionThreshold {
    pub reversibility_low: bool,
    pub rights_affected: bool,
    pub bodily_risk: bool,
    pub legal_exposure: bool,
    pub institutional_binding: bool,
    pub named_accountable_party: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StructuredDissent {
    pub case_cid: CaseCid,
    pub signer_id: SignerId,
    pub verdict: HumanVerdict,
    pub reason_codes: Vec<String>,
    pub justification_cid: String,
    pub signature: Signature,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum HumanFinalityMode {
    SingleSigner,
    DualControl,
    Quorum { required_signatures: u8 },
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum JurisdictionError {
    #[error("missing justification for verdict")]
    MissingJustification,
    #[error("invalid signer authority")]
    InvalidAuthority,
    #[error("signature missing")]
    MissingSignature,
    #[error("proof not visible")]
    ProofNotVisible,
}

#[must_use]
pub fn requires_justification(verdict: &HumanVerdict) -> bool {
    matches!(
        verdict,
        HumanVerdict::Authorize
            | HumanVerdict::Refuse
            | HumanVerdict::Suspend
            | HumanVerdict::Escalate
    )
}

#[must_use]
pub fn decide_jurisdiction(threshold: &JurisdictionThreshold) -> JurisdictionDecision {
    if threshold.reversibility_low
        && !threshold.rights_affected
        && !threshold.bodily_risk
        && !threshold.legal_exposure
        && !threshold.institutional_binding
    {
        JurisdictionDecision::AutoFinalizable
    } else {
        JurisdictionDecision::RequiresHumanSignature {
            duty_class: if threshold.bodily_risk {
                DutyClass::IrreversibleAction
            } else if threshold.legal_exposure {
                DutyClass::Legal
            } else if threshold.institutional_binding {
                DutyClass::Governance
            } else {
                DutyClass::Financial
            },
            consequence_class: if threshold.bodily_risk {
                ConsequenceClass::BodyOrLifeAffecting
            } else if threshold.rights_affected {
                ConsequenceClass::RightsAffecting
            } else if threshold.institutional_binding {
                ConsequenceClass::InstitutionBinding
            } else {
                ConsequenceClass::MaterialHigh
            },
            minimum_signer_role: RoleName("accountable_signer".to_owned()),
        }
    }
}

#[must_use]
pub fn authority_can_sign(
    authority: &SignerAuthority,
    duty: &DutyClass,
    consequence: &ConsequenceClass,
    verdict: &HumanVerdict,
    epoch: u64,
) -> bool {
    let can_verdict = match verdict {
        HumanVerdict::Ratify => authority.may_ratify,
        HumanVerdict::Authorize => authority.may_authorize,
        HumanVerdict::Refuse => authority.may_refuse,
        HumanVerdict::Suspend => authority.may_suspend,
        HumanVerdict::Escalate => authority.may_escalate,
    };
    let valid_epoch = authority.valid_from_epoch <= epoch
        && authority
            .valid_until_epoch
            .is_none_or(|until| epoch <= until);
    can_verdict
        && valid_epoch
        && authority.allowed_duty_classes.contains(duty)
        && authority.allowed_consequence_classes.contains(consequence)
}

pub fn validate_envelope(
    envelope: &JurisdictionEnvelope,
    authority: &SignerAuthority,
    epoch: u64,
    proof_pack: Option<&ProofPack>,
) -> Result<Hash, JurisdictionError> {
    if envelope.signature.0.is_empty() {
        return Err(JurisdictionError::MissingSignature);
    }
    if requires_justification(&envelope.verdict) && envelope.justification_cid.is_none() {
        return Err(JurisdictionError::MissingJustification);
    }
    if !authority_can_sign(
        authority,
        &envelope.duty_class,
        &envelope.consequence_class,
        &envelope.verdict,
        epoch,
    ) {
        return Err(JurisdictionError::InvalidAuthority);
    }
    if proof_pack.is_none() {
        return Err(JurisdictionError::ProofNotVisible);
    }
    let canonical = serde_json::to_string(envelope).expect("jurisdiction envelope is serializable");
    Ok(Hash(canonical))
}

#[must_use]
pub fn quorum_satisfied(mode: &HumanFinalityMode, signatures: usize) -> bool {
    match mode {
        HumanFinalityMode::SingleSigner => signatures >= 1,
        HumanFinalityMode::DualControl => signatures >= 2,
        HumanFinalityMode::Quorum {
            required_signatures,
        } => signatures >= usize::from(*required_signatures),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use proof_runtime::{CaseId, ContractHash, FinalOutcome, ProofMode};

    fn authority() -> SignerAuthority {
        SignerAuthority {
            signer_id: SignerId("alice".to_owned()),
            roles: vec![RoleName("accountable_signer".to_owned())],
            allowed_duty_classes: vec![DutyClass::IrreversibleAction, DutyClass::Governance],
            allowed_consequence_classes: vec![
                ConsequenceClass::BodyOrLifeAffecting,
                ConsequenceClass::InstitutionBinding,
            ],
            may_ratify: true,
            may_authorize: true,
            may_refuse: true,
            may_suspend: true,
            may_escalate: true,
            valid_from_epoch: 0,
            valid_until_epoch: None,
        }
    }

    fn proof_pack() -> ProofPack {
        ProofPack {
            case_id: CaseId::from("c1"),
            contract_hash: ContractHash::from("h"),
            proof_mode: ProofMode::FullSelfContained,
            events: Vec::new(),
            final_outcome: FinalOutcome::Commit,
            constitutional_verdict: constitution_gate::Verdict::Commit,
        }
    }

    #[test]
    fn authority_scope_is_enforced() {
        let ok = authority_can_sign(
            &authority(),
            &DutyClass::IrreversibleAction,
            &ConsequenceClass::BodyOrLifeAffecting,
            &HumanVerdict::Authorize,
            1,
        );
        assert!(ok);
        let not_ok = authority_can_sign(
            &authority(),
            &DutyClass::Financial,
            &ConsequenceClass::MaterialHigh,
            &HumanVerdict::Authorize,
            1,
        );
        assert!(!not_ok);
    }

    #[test]
    fn authorize_requires_justification() {
        let env = JurisdictionEnvelope {
            case_cid: CaseCid("case".to_owned()),
            proofpack_cid: ProofPackCid("proof".to_owned()),
            recommendation_cid: RecommendationCid("rec".to_owned()),
            signer_id: SignerId("alice".to_owned()),
            signer_role: RoleName("accountable_signer".to_owned()),
            authority_cid: AuthorityCid("auth".to_owned()),
            duty_class: DutyClass::IrreversibleAction,
            consequence_class: ConsequenceClass::BodyOrLifeAffecting,
            verdict: HumanVerdict::Authorize,
            justification_cid: None,
            signature: Signature("sig".to_owned()),
        };
        let result = validate_envelope(&env, &authority(), 1, Some(&proof_pack()));
        assert!(matches!(
            result,
            Err(JurisdictionError::MissingJustification)
        ));
    }

    #[test]
    fn proof_visibility_is_required_for_finality() {
        let env = JurisdictionEnvelope {
            case_cid: CaseCid("case".to_owned()),
            proofpack_cid: ProofPackCid("proof".to_owned()),
            recommendation_cid: RecommendationCid("rec".to_owned()),
            signer_id: SignerId("alice".to_owned()),
            signer_role: RoleName("accountable_signer".to_owned()),
            authority_cid: AuthorityCid("auth".to_owned()),
            duty_class: DutyClass::IrreversibleAction,
            consequence_class: ConsequenceClass::BodyOrLifeAffecting,
            verdict: HumanVerdict::Ratify,
            justification_cid: None,
            signature: Signature("sig".to_owned()),
        };
        let result = validate_envelope(&env, &authority(), 1, None);
        assert!(matches!(result, Err(JurisdictionError::ProofNotVisible)));
    }

    #[test]
    fn quorum_rules_block_incomplete_finality() {
        assert!(!quorum_satisfied(&HumanFinalityMode::DualControl, 1));
        assert!(quorum_satisfied(&HumanFinalityMode::DualControl, 2));
    }
}
