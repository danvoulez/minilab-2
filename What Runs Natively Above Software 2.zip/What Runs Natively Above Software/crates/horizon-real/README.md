# horizon-real

Paper 10 implementation surface:
- sensor quorum evaluation
- physical actuation interlock
- irreversible-event gating under jurisdiction
