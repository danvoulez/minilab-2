use constitution_gate::Verdict;
use economic_fields::{EconomicTranscript, Hash, NodeId, ReceiptEnvelope};
use epistemic_storage::{
    CanonicalCell, CellId, CellKind, CellMeta, CellStatus, ClosureClass, DoubtPolicy,
    EpistemicGraph, GhostCriticality, GhostId, GhostRecord, GhostStatus, JustificationRef,
    SqliteEpistemicStore,
};
use horizon_real::{
    ActuationCommand, ActuatorInterlock, ConsequenceRegime, DefaultInterlock, InterlockVerdict,
};
use jurisdiction::{
    AuthorityCid, CaseCid, ConsequenceClass, DutyClass, HumanFinalityMode, HumanVerdict,
    JurisdictionEnvelope, JurisdictionThreshold, ProofPackCid, RecommendationCid, RoleName,
    Signature, SignerAuthority, SignerId, decide_jurisdiction, validate_envelope,
};
use manager_plane::{BasicManager, ManagerInput, ManagerOutput, ManagerPlane};
use proof_runtime::{
    ActionCost, CaseId, ComputeAction, Contract, ContractHash, DeterminismProfile, EpistemicAction,
    FinalOutcome, ProofMode, ProofPack, Runtime, RuntimeError, RuntimeOps, Session, SessionView,
    StepAction, StepDecision, StepReceipt, WitnessAction, load_replay_seed, persist_replay_seed,
};
use std::fs;
use worker_abi::{AtomCid, MockHostEnv, WorkerAbi, WorkerResult, YieldingWorker};

struct OneStepContract;

impl Contract for OneStepContract {
    fn eval_step(&self, session: &SessionView) -> StepDecision {
        if session.event_count == 0 {
            StepDecision::Continue(StepAction::Compute(ComputeAction::Propose {
                proposer_id: "manager.default".to_owned(),
                input_set_cid: "input-set".to_owned(),
            }))
        } else {
            StepDecision::Commit
        }
    }

    fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
        ActionCost { gas: 3 }
    }

    fn determinism_profile(&self) -> DeterminismProfile {
        DeterminismProfile {
            deterministic: true,
            bounded_divergence: false,
        }
    }
}

struct NoopOps;

impl RuntimeOps for NoopOps {
    fn execute_action(
        &mut self,
        _session: &Session,
        _action: &StepAction,
    ) -> Result<(StepReceipt, String), RuntimeError> {
        Ok((
            StepReceipt::Computed {
                receipt_cid: "receipt-step-1".to_owned(),
            },
            "state-after-1".to_owned(),
        ))
    }
}

struct InitialEpistemicContract {
    graph: EpistemicGraph,
    conclusion_id: CellId,
}

impl Contract for InitialEpistemicContract {
    fn eval_step(&self, session: &SessionView) -> StepDecision {
        if session.event_count == 0 {
            StepDecision::Continue(StepAction::Epistemic(EpistemicAction::AssessClosure {
                conclusion_cell_id: self.conclusion_id.clone(),
                graph: self.graph.clone(),
            }))
        } else {
            StepDecision::Commit
        }
    }

    fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
        ActionCost { gas: 1 }
    }

    fn determinism_profile(&self) -> DeterminismProfile {
        DeterminismProfile {
            deterministic: true,
            bounded_divergence: false,
        }
    }
}

struct ResolveEpistemicContract {
    graph: EpistemicGraph,
    ghost_id: GhostId,
    conclusion_id: CellId,
}

impl Contract for ResolveEpistemicContract {
    fn eval_step(&self, session: &SessionView) -> StepDecision {
        match session.event_count {
            0 => StepDecision::Continue(StepAction::Witness(WitnessAction::AskUserField {
                field_id: "bank_statement".to_owned(),
            })),
            1 => StepDecision::Continue(StepAction::Epistemic(
                EpistemicAction::ResolveGhostFromLatestWitness {
                    ghost_id: self.ghost_id.clone(),
                    conclusion_cell_id: self.conclusion_id.clone(),
                    graph: self.graph.clone(),
                },
            )),
            _ => StepDecision::Commit,
        }
    }

    fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
        ActionCost { gas: 1 }
    }

    fn determinism_profile(&self) -> DeterminismProfile {
        DeterminismProfile {
            deterministic: true,
            bounded_divergence: false,
        }
    }
}

struct ActionListContract {
    actions: Vec<StepAction>,
}

impl Contract for ActionListContract {
    fn eval_step(&self, session: &SessionView) -> StepDecision {
        let index = session.event_count as usize;
        if index >= self.actions.len() {
            StepDecision::Commit
        } else {
            StepDecision::Continue(self.actions[index].clone())
        }
    }

    fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
        ActionCost { gas: 1 }
    }

    fn determinism_profile(&self) -> DeterminismProfile {
        DeterminismProfile {
            deterministic: true,
            bounded_divergence: false,
        }
    }
}

struct WitnessOps;

impl RuntimeOps for WitnessOps {
    fn execute_action(
        &mut self,
        _session: &Session,
        action: &StepAction,
    ) -> Result<(StepReceipt, String), RuntimeError> {
        match action {
            StepAction::Witness(WitnessAction::AskUserField { field_id }) => Ok((
                StepReceipt::WitnessProvided {
                    witness_cid: format!("witness:{field_id}:cid"),
                },
                "state-after-witness".to_owned(),
            )),
            _ => Err(RuntimeError::ActionFailed(
                "unexpected action for witness ops".to_owned(),
            )),
        }
    }
}

fn epistemic_session(case_id: &str) -> Session {
    Session {
        case_id: CaseId::from(case_id),
        contract_hash: ContractHash::from("contract-epistemic"),
        proof_mode: ProofMode::FullSelfContained,
        initial_budget: 100,
        budget_remaining: 100,
        state_root: "state-0".to_owned(),
        atoms: epistemic_storage::AtomStoreView {
            present_cids: Vec::new(),
        },
        transcript_head: None,
        event_count: 0,
        current_proposal: None,
        last_witness_cid: None,
        last_external_anchor: None,
    }
}

fn graph_with_honest_gap() -> EpistemicGraph {
    let mut graph = EpistemicGraph::new();
    graph.insert_cell(CanonicalCell {
        id: CellId::from("obs"),
        kind: CellKind::Observation,
        content: "invoice exists".to_owned(),
        status: CellStatus::Ok,
        depends_on: Vec::new(),
        confirmed_by: vec![JustificationRef::Anchor("sensor:invoice".to_owned())],
        if_doubt: DoubtPolicy::AskWitness,
        created_at: 1,
        meta: CellMeta::default(),
    });
    graph.insert_cell(CanonicalCell {
        id: CellId::from("infer"),
        kind: CellKind::Inference,
        content: "payment received".to_owned(),
        status: CellStatus::Doubt,
        depends_on: vec![CellId::from("obs")],
        confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-payment"))],
        if_doubt: DoubtPolicy::SpawnGhost,
        created_at: 2,
        meta: CellMeta {
            provenance: vec!["llm".to_owned()],
            closure_class: ClosureClass::Conditional,
            causal_strength: 85,
            contradiction_with: Vec::new(),
        },
    });
    graph.insert_cell(CanonicalCell {
        id: CellId::from("conclusion"),
        kind: CellKind::Conclusion,
        content: "transaction verified".to_owned(),
        status: CellStatus::Doubt,
        depends_on: vec![CellId::from("infer")],
        confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
        if_doubt: DoubtPolicy::SpawnGhost,
        created_at: 3,
        meta: CellMeta {
            provenance: vec!["manager".to_owned()],
            closure_class: ClosureClass::Final,
            causal_strength: 0,
            contradiction_with: Vec::new(),
        },
    });
    graph.insert_ghost(GhostRecord {
        id: GhostId::from("g-payment"),
        reason: "need bank statement".to_owned(),
        criticality: GhostCriticality::High,
        opened_from: CellId::from("infer"),
        required_for: vec![CellId::from("conclusion")],
        status: GhostStatus::Open,
        resolution_ref: None,
    });
    graph
}

fn graph_with_resolved_gap_but_unresolved_contradiction() -> EpistemicGraph {
    let mut graph = EpistemicGraph::new();
    graph.insert_cell(CanonicalCell {
        id: CellId::from("obs"),
        kind: CellKind::Observation,
        content: "invoice exists".to_owned(),
        status: CellStatus::Ok,
        depends_on: Vec::new(),
        confirmed_by: vec![JustificationRef::Anchor("sensor:invoice".to_owned())],
        if_doubt: DoubtPolicy::AskWitness,
        created_at: 1,
        meta: CellMeta::default(),
    });
    graph.insert_cell(CanonicalCell {
        id: CellId::from("obs-contradiction"),
        kind: CellKind::Observation,
        content: "bank freeze record exists".to_owned(),
        status: CellStatus::Ok,
        depends_on: Vec::new(),
        confirmed_by: vec![JustificationRef::Anchor("witness:freeze_notice".to_owned())],
        if_doubt: DoubtPolicy::AskWitness,
        created_at: 2,
        meta: CellMeta::default(),
    });
    graph.insert_cell(CanonicalCell {
        id: CellId::from("infer"),
        kind: CellKind::Inference,
        content: "payment received".to_owned(),
        status: CellStatus::Doubt,
        depends_on: vec![CellId::from("obs")],
        confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-payment"))],
        if_doubt: DoubtPolicy::SpawnGhost,
        created_at: 3,
        meta: CellMeta {
            provenance: vec!["llm".to_owned()],
            closure_class: ClosureClass::Conditional,
            causal_strength: 85,
            contradiction_with: vec![CellId::from("obs-contradiction")],
        },
    });
    graph.insert_cell(CanonicalCell {
        id: CellId::from("conclusion"),
        kind: CellKind::Conclusion,
        content: "transaction verified".to_owned(),
        status: CellStatus::Doubt,
        depends_on: vec![CellId::from("infer")],
        confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
        if_doubt: DoubtPolicy::SpawnGhost,
        created_at: 4,
        meta: CellMeta {
            provenance: vec!["manager".to_owned()],
            closure_class: ClosureClass::Final,
            causal_strength: 0,
            contradiction_with: Vec::new(),
        },
    });
    graph.insert_ghost(GhostRecord {
        id: GhostId::from("g-payment"),
        reason: "need bank statement".to_owned(),
        criticality: GhostCriticality::High,
        opened_from: CellId::from("infer"),
        required_for: vec![CellId::from("conclusion")],
        status: GhostStatus::Open,
        resolution_ref: None,
    });
    graph
}

fn signer_authority() -> SignerAuthority {
    SignerAuthority {
        signer_id: SignerId("human-1".to_owned()),
        roles: vec![RoleName("accountable_signer".to_owned())],
        allowed_duty_classes: vec![DutyClass::IrreversibleAction],
        allowed_consequence_classes: vec![ConsequenceClass::BodyOrLifeAffecting],
        may_ratify: true,
        may_authorize: true,
        may_refuse: true,
        may_suspend: true,
        may_escalate: true,
        valid_from_epoch: 0,
        valid_until_epoch: None,
    }
}

#[test]
fn end_to_end_typed_flow_from_delegate_to_actuation_gate() {
    let case_id = "case-42";

    let mut manager = BasicManager::new();
    manager
        .ingest(ManagerInput::Event {
            case_id: CaseId::from(case_id),
            event_cid: AtomCid("task-cid-42".to_owned()),
        })
        .expect("manager ingest should succeed");
    let delegate = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should produce delegate");
    let ManagerOutput::Delegate { task_cid, .. } = delegate else {
        panic!("expected delegate output")
    };

    let needed_atom = AtomCid("atom-needed".to_owned());
    let mut worker = YieldingWorker {
        required_cid: needed_atom.clone(),
        gas_cost: 2,
    };
    let mut host = MockHostEnv::with_gas(10);
    let first = worker.execute(&task_cid, &mut host);
    assert!(matches!(first, WorkerResult::Yield(_)));
    host.put_atom(needed_atom, b"available".to_vec());
    let second = worker.execute(&task_cid, &mut host);
    assert!(matches!(second, WorkerResult::Complete(_)));

    let session = Session {
        case_id: CaseId::from(case_id),
        contract_hash: ContractHash::from("contract-h1"),
        proof_mode: ProofMode::FullSelfContained,
        initial_budget: 100,
        budget_remaining: 100,
        state_root: "state-0".to_owned(),
        atoms: epistemic_storage::AtomStoreView {
            present_cids: Vec::new(),
        },
        transcript_head: None,
        event_count: 0,
        current_proposal: None,
        last_witness_cid: None,
        last_external_anchor: None,
    };
    let runtime = Runtime::new(8);
    let mut ops = NoopOps;
    let pack: ProofPack = runtime.run(session, &OneStepContract, &mut ops);
    assert_eq!(pack.final_outcome, FinalOutcome::Commit);
    assert_eq!(pack.constitutional_verdict, Verdict::Commit);

    let mut econ = EconomicTranscript::new(100);
    econ.append_envelope(
        ReceiptEnvelope {
            executor: NodeId("node-executor".to_owned()),
            beneficiary: NodeId("node-beneficiary".to_owned()),
            gas_cost: 3,
            contract_hash: Hash("contract-h1".to_owned()),
            receipt: StepReceipt::Computed {
                receipt_cid: "receipt-step-1".to_owned(),
            },
        },
        Hash("state-0".to_owned()),
        Hash("state-1".to_owned()),
    )
    .expect("economic append should succeed");
    assert!(econ.verify_conservation());

    let threshold = JurisdictionThreshold {
        reversibility_low: false,
        rights_affected: false,
        bodily_risk: true,
        legal_exposure: false,
        institutional_binding: false,
        named_accountable_party: true,
    };
    let decision = decide_jurisdiction(&threshold);
    let jurisdiction = JurisdictionEnvelope {
        case_cid: CaseCid(case_id.to_owned()),
        proofpack_cid: ProofPackCid("proof-cid".to_owned()),
        recommendation_cid: RecommendationCid("rec-cid".to_owned()),
        signer_id: SignerId("human-1".to_owned()),
        signer_role: RoleName("accountable_signer".to_owned()),
        authority_cid: AuthorityCid("auth-cid".to_owned()),
        duty_class: DutyClass::IrreversibleAction,
        consequence_class: ConsequenceClass::BodyOrLifeAffecting,
        verdict: HumanVerdict::Authorize,
        justification_cid: Some("justification-cid".to_owned()),
        signature: Signature("sig-1".to_owned()),
    };
    validate_envelope(&jurisdiction, &signer_authority(), 1, Some(&pack))
        .expect("jurisdiction envelope should validate");

    let interlock = DefaultInterlock;
    let verdict = interlock.validate_command(
        &ActuationCommand {
            command_id: "act-1".to_owned(),
            case_cid: case_id.to_owned(),
            action: "open_valve".to_owned(),
            regime: ConsequenceRegime::Irreversible,
            consequence_class: ConsequenceClass::BodyOrLifeAffecting,
            signer_id: SignerId("human-1".to_owned()),
            signature: Signature("sig-1".to_owned()),
        },
        &decision,
        Some(&signer_authority()),
        1,
        &HumanFinalityMode::SingleSigner,
        1,
    );
    assert_eq!(verdict, InterlockVerdict::Permit);

    let refused_without_authority = interlock.validate_command(
        &ActuationCommand {
            command_id: "act-2".to_owned(),
            case_cid: case_id.to_owned(),
            action: "open_valve".to_owned(),
            regime: ConsequenceRegime::Irreversible,
            consequence_class: ConsequenceClass::BodyOrLifeAffecting,
            signer_id: SignerId("human-1".to_owned()),
            signature: Signature("sig-1".to_owned()),
        },
        &decision,
        None,
        1,
        &HumanFinalityMode::SingleSigner,
        1,
    );
    assert!(matches!(
        refused_without_authority,
        InterlockVerdict::Refuse(_)
    ));
}

#[test]
fn end_to_end_case_advances_only_after_epistemic_commit_transition() {
    let case_id = "case-epistemic-transition";
    let conclusion_id = CellId::from("conclusion");
    let ghost_id = GhostId::from("g-payment");

    let mut manager = BasicManager::new();
    manager
        .ingest(ManagerInput::Event {
            case_id: CaseId::from(case_id),
            event_cid: AtomCid("task-epistemic".to_owned()),
        })
        .expect("event ingest should succeed");
    let initial_delegate = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should delegate first");
    assert!(matches!(initial_delegate, ManagerOutput::Delegate { .. }));

    let initial_graph = graph_with_honest_gap();
    let runtime = Runtime::new(4);
    let mut noop_ops = NoopOps;
    let initial_pack = runtime.run(
        epistemic_session(case_id),
        &InitialEpistemicContract {
            graph: initial_graph.clone(),
            conclusion_id: conclusion_id.clone(),
        },
        &mut noop_ops,
    );
    assert_eq!(initial_pack.events.len(), 1);
    assert!(matches!(
        initial_pack.events[0].receipt,
        StepReceipt::EpistemicClosureEvaluated {
            constitutional_verdict: Verdict::Ghost,
            ..
        }
    ));

    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: initial_pack.events[0].receipt.clone(),
        })
        .expect("initial epistemic receipt should ingest");
    let after_initial_eval = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process initial epistemic receipt");
    assert!(matches!(after_initial_eval, ManagerOutput::Idle));

    let mut witness_ops = WitnessOps;
    let resolution_pack = runtime.run(
        epistemic_session(case_id),
        &ResolveEpistemicContract {
            graph: initial_graph,
            ghost_id: ghost_id.clone(),
            conclusion_id: conclusion_id.clone(),
        },
        &mut witness_ops,
    );
    assert_eq!(resolution_pack.events.len(), 2);
    assert!(matches!(
        resolution_pack.events[0].receipt,
        StepReceipt::WitnessProvided { .. }
    ));
    assert!(matches!(
        resolution_pack.events[1].receipt,
        StepReceipt::GhostResolved {
            ghost_id: GhostId(ref id),
            ..
        } if id == "g-payment"
    ));

    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: resolution_pack.events[1].receipt.clone(),
        })
        .expect("ghost resolution receipt should ingest");
    let after_resolution = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process ghost resolution");
    assert!(matches!(
        after_resolution,
        ManagerOutput::ReevaluateEpistemicClosure {
            ref conclusion_cell_ids,
            ..
        } if conclusion_cell_ids == &vec![CellId::from("conclusion")]
    ));
    let reassessment_actions = after_resolution
        .runtime_actions()
        .expect("re-evaluation should produce concrete runtime actions");
    assert!(matches!(
        reassessment_actions.as_slice(),
        [StepAction::Epistemic(EpistemicAction::ReassessClosure {
            conclusion_cell_id,
            previous_verdict: Verdict::Ghost,
            ..
        })] if conclusion_cell_id == &CellId::from("conclusion")
    ));

    let reassessment_pack = runtime.run(
        epistemic_session(case_id),
        &ActionListContract {
            actions: reassessment_actions,
        },
        &mut noop_ops,
    );
    assert_eq!(reassessment_pack.events.len(), 1);
    assert!(matches!(
        reassessment_pack.events[0].receipt,
        StepReceipt::EpistemicClosureTransition {
            from_verdict: Verdict::Ghost,
            to_verdict: Verdict::Commit,
            ..
        }
    ));

    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: reassessment_pack.events[0].receipt.clone(),
        })
        .expect("closure transition receipt should ingest");
    let after_transition = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process commit transition");
    assert!(matches!(
        after_transition,
        ManagerOutput::AdvancePointer { ref head_cid, .. }
            if head_cid.0 == "closure:conclusion"
    ));
}

#[test]
fn end_to_end_restart_preserves_ghost_reassessment_to_pointer_advance() {
    let runtime = Runtime::new(4);
    let mut manager = BasicManager::new();
    let case_id = "case-epistemic-restart";
    let ghost_id = GhostId::from("g-payment");
    let conclusion_id = CellId::from("conclusion");

    let initial_graph = graph_with_honest_gap();
    let mut noop_ops = NoopOps;
    let initial_pack = runtime.run(
        epistemic_session(case_id),
        &InitialEpistemicContract {
            graph: initial_graph.clone(),
            conclusion_id: conclusion_id.clone(),
        },
        &mut noop_ops,
    );
    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: initial_pack.events[0].receipt.clone(),
        })
        .expect("initial epistemic receipt should ingest");
    let initial_manager_out = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process initial receipt");
    assert!(matches!(initial_manager_out, ManagerOutput::Idle));

    let mut witness_ops = WitnessOps;
    let resolution_pack = runtime.run(
        epistemic_session(case_id),
        &ResolveEpistemicContract {
            graph: initial_graph,
            ghost_id: ghost_id.clone(),
            conclusion_id: conclusion_id.clone(),
        },
        &mut witness_ops,
    );
    let resolved_graph = match &resolution_pack.events[1].receipt {
        StepReceipt::GhostResolved { graph, .. } => graph.clone(),
        other => panic!("expected ghost resolution receipt, got {other:?}"),
    };
    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: resolution_pack.events[1].receipt.clone(),
        })
        .expect("ghost resolution receipt should ingest");
    let pre_restart_output = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process ghost resolution");
    assert!(matches!(
        pre_restart_output,
        ManagerOutput::ReevaluateEpistemicClosure {
            ref conclusion_cell_ids,
            previous_verdict: Verdict::Ghost,
            ..
        } if conclusion_cell_ids == &vec![CellId::from("conclusion")]
    ));

    let db_path = std::env::temp_dir().join(format!(
        "manager-runtime-restart-{}-{}.sqlite",
        std::process::id(),
        1_763_652_101_u64
    ));
    let _ = fs::remove_file(&db_path);

    {
        let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should open");
        let replay_seed = persist_replay_seed(
            &store,
            &epistemic_session(case_id),
            &resolved_graph,
            &[],
            300,
        )
        .expect("replay seed should persist");
        manager
            .persist_case_state(
                &store,
                &CaseId::from(case_id),
                replay_seed.pointers.clone(),
                Some(replay_seed.graph_version),
                None,
                301,
            )
            .expect("manager state should persist");
    }

    let after_transition = {
        let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should reopen");
        let mut restored_manager = BasicManager::new();
        restored_manager
            .rehydrate_case_state(&store, &CaseId::from(case_id))
            .expect("manager rehydration should work")
            .expect("persisted manager state should exist");
        let restored_seed =
            load_replay_seed(&store, &CaseId::from(case_id)).expect("replay seed should restore");

        let resumed_output = restored_manager
            .resume_case(&CaseId::from(case_id))
            .expect("resume should work");
        assert_eq!(resumed_output, pre_restart_output);

        let reassessment_actions = resumed_output
            .runtime_actions()
            .expect("re-evaluation should produce concrete runtime actions");
        let reassessment_pack = runtime.run(
            restored_seed.session,
            &ActionListContract {
                actions: reassessment_actions,
            },
            &mut noop_ops,
        );
        assert!(matches!(
            reassessment_pack.events[0].receipt,
            StepReceipt::EpistemicClosureTransition {
                from_verdict: Verdict::Ghost,
                to_verdict: Verdict::Commit,
                ..
            }
        ));

        restored_manager
            .ingest(ManagerInput::EpistemicReceipt {
                case_id: CaseId::from(case_id),
                receipt: reassessment_pack.events[0].receipt.clone(),
            })
            .expect("commit transition receipt should ingest");
        restored_manager
            .evaluate_next(&CaseId::from(case_id))
            .expect("restored manager should advance pointer")
    };

    assert!(matches!(
        after_transition,
        ManagerOutput::AdvancePointer { ref head_cid, .. }
            if head_cid.0 == "closure:conclusion"
    ));

    let _ = fs::remove_file(db_path);
}

#[test]
fn end_to_end_restart_preserves_ghost_reassessment_to_epistemic_reject() {
    let runtime = Runtime::new(4);
    let mut manager = BasicManager::new();
    let case_id = "case-epistemic-restart-reject";
    let ghost_id = GhostId::from("g-payment");
    let conclusion_id = CellId::from("conclusion");

    let initial_graph = graph_with_resolved_gap_but_unresolved_contradiction();
    let mut noop_ops = NoopOps;
    let initial_pack = runtime.run(
        epistemic_session(case_id),
        &InitialEpistemicContract {
            graph: initial_graph.clone(),
            conclusion_id: conclusion_id.clone(),
        },
        &mut noop_ops,
    );
    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: initial_pack.events[0].receipt.clone(),
        })
        .expect("initial epistemic receipt should ingest");
    let initial_manager_out = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process initial receipt");
    assert!(matches!(initial_manager_out, ManagerOutput::Idle));

    let mut witness_ops = WitnessOps;
    let resolution_pack = runtime.run(
        epistemic_session(case_id),
        &ResolveEpistemicContract {
            graph: initial_graph,
            ghost_id: ghost_id.clone(),
            conclusion_id: conclusion_id.clone(),
        },
        &mut witness_ops,
    );
    let resolved_graph = match &resolution_pack.events[1].receipt {
        StepReceipt::GhostResolved { graph, .. } => graph.clone(),
        other => panic!("expected ghost resolution receipt, got {other:?}"),
    };
    manager
        .ingest(ManagerInput::EpistemicReceipt {
            case_id: CaseId::from(case_id),
            receipt: resolution_pack.events[1].receipt.clone(),
        })
        .expect("ghost resolution receipt should ingest");
    let pre_restart_output = manager
        .evaluate_next(&CaseId::from(case_id))
        .expect("manager should process ghost resolution");
    assert!(matches!(
        pre_restart_output,
        ManagerOutput::ReevaluateEpistemicClosure {
            ref conclusion_cell_ids,
            previous_verdict: Verdict::Ghost,
            ..
        } if conclusion_cell_ids == &vec![CellId::from("conclusion")]
    ));

    let db_path = std::env::temp_dir().join(format!(
        "manager-runtime-restart-reject-{}-{}.sqlite",
        std::process::id(),
        1_763_652_102_u64
    ));
    let _ = fs::remove_file(&db_path);

    {
        let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should open");
        let replay_seed = persist_replay_seed(
            &store,
            &epistemic_session(case_id),
            &resolved_graph,
            &[],
            400,
        )
        .expect("replay seed should persist");
        manager
            .persist_case_state(
                &store,
                &CaseId::from(case_id),
                replay_seed.pointers.clone(),
                Some(replay_seed.graph_version),
                None,
                401,
            )
            .expect("manager state should persist");
    }

    let after_transition = {
        let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should reopen");
        let mut restored_manager = BasicManager::new();
        restored_manager
            .rehydrate_case_state(&store, &CaseId::from(case_id))
            .expect("manager rehydration should work")
            .expect("persisted manager state should exist");
        let restored_seed =
            load_replay_seed(&store, &CaseId::from(case_id)).expect("replay seed should restore");

        let resumed_output = restored_manager
            .resume_case(&CaseId::from(case_id))
            .expect("resume should work");
        assert_eq!(resumed_output, pre_restart_output);

        let reassessment_actions = resumed_output
            .runtime_actions()
            .expect("re-evaluation should produce concrete runtime actions");
        let reassessment_pack = runtime.run(
            restored_seed.session,
            &ActionListContract {
                actions: reassessment_actions,
            },
            &mut noop_ops,
        );
        assert!(matches!(
            reassessment_pack.events[0].receipt,
            StepReceipt::EpistemicClosureTransition {
                from_verdict: Verdict::Ghost,
                to_verdict: Verdict::Reject,
                ..
            }
        ));

        restored_manager
            .ingest(ManagerInput::EpistemicReceipt {
                case_id: CaseId::from(case_id),
                receipt: reassessment_pack.events[0].receipt.clone(),
            })
            .expect("reject transition receipt should ingest");
        restored_manager
            .evaluate_next(&CaseId::from(case_id))
            .expect("restored manager should block on reject")
    };

    assert!(matches!(
        after_transition,
        ManagerOutput::Blocked {
            reason: manager_plane::BlockReason::EpistemicReject,
            ..
        }
    ));

    let _ = fs::remove_file(db_path);
}
