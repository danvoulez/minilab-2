//! Paper 10 boundary layer: actuation interlocks and entropy-aware witness checks.

use jurisdiction::{
    ConsequenceClass, HumanFinalityMode, HumanVerdict, JurisdictionDecision, Signature,
    SignerAuthority, SignerId, authority_can_sign,
};
use serde::{Deserialize, Serialize};
use worker_abi::AtomCid;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ConsequenceRegime {
    Reversible,
    Irreversible,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ActuationCommand {
    pub command_id: String,
    pub case_cid: String,
    pub action: String,
    pub regime: ConsequenceRegime,
    pub consequence_class: ConsequenceClass,
    pub signer_id: SignerId,
    pub signature: Signature,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SensorModality {
    Camera,
    Lidar,
    Pressure,
    Thermal,
    HumanWitness,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SensorWitness {
    pub sensor_id: String,
    pub modality: SensorModality,
    pub quality_basis_points: u16,
    pub reading_cid: AtomCid,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SensorQuorumPolicy {
    pub minimum_witnesses: usize,
    pub minimum_quality_basis_points: u16,
    pub require_distinct_modalities: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SensorQuorumVerdict {
    Sufficient,
    Degraded(String),
    Refuse(String),
}

#[must_use]
pub fn evaluate_sensor_quorum(
    witnesses: &[SensorWitness],
    policy: &SensorQuorumPolicy,
) -> SensorQuorumVerdict {
    if witnesses.len() < policy.minimum_witnesses {
        return SensorQuorumVerdict::Refuse("insufficient witness count".to_owned());
    }
    if witnesses
        .iter()
        .any(|w| w.quality_basis_points < policy.minimum_quality_basis_points)
    {
        return SensorQuorumVerdict::Degraded("witness quality below threshold".to_owned());
    }
    if policy.require_distinct_modalities {
        let mut set = std::collections::BTreeSet::new();
        for witness in witnesses {
            set.insert(format!("{:?}", witness.modality));
        }
        if set.len() < witnesses.len() {
            return SensorQuorumVerdict::Degraded(
                "distinct modalities not satisfied for all witnesses".to_owned(),
            );
        }
    }
    SensorQuorumVerdict::Sufficient
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum InterlockReason {
    MissingSignature,
    MissingSignerAuthority,
    JurisdictionNotSatisfied,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum InterlockVerdict {
    Permit,
    Refuse(InterlockReason),
}

pub trait ActuatorInterlock {
    fn validate_command(
        &self,
        command: &ActuationCommand,
        jurisdiction: &JurisdictionDecision,
        authority: Option<&SignerAuthority>,
        epoch: u64,
        finality_mode: &HumanFinalityMode,
        signature_count: usize,
    ) -> InterlockVerdict;
}

pub struct DefaultInterlock;

impl ActuatorInterlock for DefaultInterlock {
    fn validate_command(
        &self,
        command: &ActuationCommand,
        jurisdiction: &JurisdictionDecision,
        authority: Option<&SignerAuthority>,
        epoch: u64,
        finality_mode: &HumanFinalityMode,
        signature_count: usize,
    ) -> InterlockVerdict {
        if command.signature.0.is_empty() {
            return InterlockVerdict::Refuse(InterlockReason::MissingSignature);
        }

        if !jurisdiction::quorum_satisfied(finality_mode, signature_count) {
            return InterlockVerdict::Refuse(InterlockReason::JurisdictionNotSatisfied);
        }

        if matches!(command.regime, ConsequenceRegime::Irreversible) {
            let JurisdictionDecision::RequiresHumanSignature {
                duty_class,
                consequence_class,
                ..
            } = jurisdiction
            else {
                return InterlockVerdict::Refuse(InterlockReason::JurisdictionNotSatisfied);
            };

            let Some(authority) = authority else {
                return InterlockVerdict::Refuse(InterlockReason::MissingSignerAuthority);
            };
            if !authority_can_sign(
                authority,
                duty_class,
                consequence_class,
                &HumanVerdict::Authorize,
                epoch,
            ) {
                return InterlockVerdict::Refuse(InterlockReason::JurisdictionNotSatisfied);
            }
        }
        InterlockVerdict::Permit
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use jurisdiction::{DutyClass, HumanFinalityMode};

    fn signer() -> SignerAuthority {
        SignerAuthority {
            signer_id: SignerId("human-1".to_owned()),
            roles: vec![jurisdiction::RoleName("accountable_signer".to_owned())],
            allowed_duty_classes: vec![DutyClass::IrreversibleAction],
            allowed_consequence_classes: vec![ConsequenceClass::BodyOrLifeAffecting],
            may_ratify: true,
            may_authorize: true,
            may_refuse: true,
            may_suspend: true,
            may_escalate: true,
            valid_from_epoch: 0,
            valid_until_epoch: None,
        }
    }

    #[test]
    fn irreversible_command_is_refused_without_valid_jurisdiction() {
        let interlock = DefaultInterlock;
        let cmd = ActuationCommand {
            command_id: "c1".to_owned(),
            case_cid: "case1".to_owned(),
            action: "dispense_chemical".to_owned(),
            regime: ConsequenceRegime::Irreversible,
            consequence_class: ConsequenceClass::BodyOrLifeAffecting,
            signer_id: SignerId("human-1".to_owned()),
            signature: Signature("sig".to_owned()),
        };
        let verdict = interlock.validate_command(
            &cmd,
            &JurisdictionDecision::AutoFinalizable,
            Some(&signer()),
            1,
            &HumanFinalityMode::SingleSigner,
            1,
        );
        assert!(matches!(
            verdict,
            InterlockVerdict::Refuse(InterlockReason::JurisdictionNotSatisfied)
        ));
    }

    #[test]
    fn sensor_quorum_degrades_on_low_quality() {
        let witnesses = vec![
            SensorWitness {
                sensor_id: "cam1".to_owned(),
                modality: SensorModality::Camera,
                quality_basis_points: 9000,
                reading_cid: AtomCid("a".to_owned()),
            },
            SensorWitness {
                sensor_id: "lidar1".to_owned(),
                modality: SensorModality::Lidar,
                quality_basis_points: 1000,
                reading_cid: AtomCid("b".to_owned()),
            },
        ];
        let verdict = evaluate_sensor_quorum(
            &witnesses,
            &SensorQuorumPolicy {
                minimum_witnesses: 2,
                minimum_quality_basis_points: 5000,
                require_distinct_modalities: true,
            },
        );
        assert!(matches!(verdict, SensorQuorumVerdict::Degraded(_)));
    }

    #[test]
    fn irreversible_command_requires_quorum() {
        let interlock = DefaultInterlock;
        let cmd = ActuationCommand {
            command_id: "c1".to_owned(),
            case_cid: "case1".to_owned(),
            action: "dispense_chemical".to_owned(),
            regime: ConsequenceRegime::Irreversible,
            consequence_class: ConsequenceClass::BodyOrLifeAffecting,
            signer_id: SignerId("human-1".to_owned()),
            signature: Signature("sig".to_owned()),
        };
        let verdict = interlock.validate_command(
            &cmd,
            &JurisdictionDecision::RequiresHumanSignature {
                duty_class: DutyClass::IrreversibleAction,
                consequence_class: ConsequenceClass::BodyOrLifeAffecting,
                minimum_signer_role: jurisdiction::RoleName("accountable_signer".to_owned()),
            },
            Some(&signer()),
            1,
            &HumanFinalityMode::DualControl,
            1,
        );
        assert!(matches!(
            verdict,
            InterlockVerdict::Refuse(InterlockReason::JurisdictionNotSatisfied)
        ));
    }
}
