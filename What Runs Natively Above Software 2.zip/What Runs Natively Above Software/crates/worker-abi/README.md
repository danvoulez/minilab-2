# worker-abi

RFC-0006 implementation surface:
- bounded worker host environment
- yield/resume contract
- gas consumption enforcement
