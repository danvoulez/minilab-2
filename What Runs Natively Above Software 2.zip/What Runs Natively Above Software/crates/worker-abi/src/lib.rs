//! RFC-0006 worker ABI: bounded execution, explicit yield, non-sovereign labour.

pub use epistemic_storage::AtomCid;
use epistemic_storage::PageFault;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WorkerManifest {
    pub name: String,
    pub version: String,
    pub class: WorkerClass,
    pub bytecode_cid: AtomCid,
    pub required_capabilities: Vec<Capability>,
    pub determinism_profile: DeterminismProfile,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum WorkerClass {
    ChipAsCode,
    SiliconAsCompute {
        epsilon_bounds_basis_points: u32,
        quantization: QuantizationLevel,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Capability {
    Compute,
    WitnessRead,
    Materialize,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum QuantizationLevel {
    None,
    Int8,
    Int4,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DeterminismProfile {
    pub deterministic: bool,
    pub bounded_divergence: bool,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum OutOfGas {
    #[error("out of gas: remaining {remaining}, requested {requested}")]
    Exhausted { remaining: u64, requested: u64 },
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum WorkerError {
    #[error("execution failed: {0}")]
    ExecutionFailed(String),
}

pub trait WorkerHostEnv {
    fn request_atom(&self, cid: &AtomCid) -> Result<&[u8], PageFault>;
    fn consume_gas(&mut self, amount: u64) -> Result<(), OutOfGas>;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReceiptCid(pub String);

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WorkerResult {
    Complete(ReceiptCid),
    Yield(Vec<AtomCid>),
    Fail(WorkerError),
}

pub trait WorkerAbi {
    fn execute(&mut self, task_cid: &AtomCid, env: &mut dyn WorkerHostEnv) -> WorkerResult;
}

#[doc = "UNSTABLE_V0"]
pub struct YieldingWorker {
    pub required_cid: AtomCid,
    pub gas_cost: u64,
}

impl WorkerAbi for YieldingWorker {
    fn execute(&mut self, _task_cid: &AtomCid, env: &mut dyn WorkerHostEnv) -> WorkerResult {
        match env.request_atom(&self.required_cid) {
            Ok(_) => match env.consume_gas(self.gas_cost) {
                Ok(()) => {
                    WorkerResult::Complete(ReceiptCid(format!("receipt:{}", self.required_cid.0)))
                }
                Err(err) => WorkerResult::Fail(WorkerError::ExecutionFailed(err.to_string())),
            },
            Err(PageFault::Absent(_) | PageFault::Cold(_)) => {
                WorkerResult::Yield(vec![self.required_cid.clone()])
            }
        }
    }
}

#[derive(Debug, Default)]
pub struct MockHostEnv {
    atoms: HashMap<String, Vec<u8>>,
    pub gas_remaining: u64,
}

impl MockHostEnv {
    #[must_use]
    pub fn with_gas(gas_remaining: u64) -> Self {
        Self {
            atoms: HashMap::new(),
            gas_remaining,
        }
    }

    pub fn put_atom(&mut self, cid: AtomCid, payload: Vec<u8>) {
        self.atoms.insert(cid.0, payload);
    }
}

impl WorkerHostEnv for MockHostEnv {
    fn request_atom(&self, cid: &AtomCid) -> Result<&[u8], PageFault> {
        self.atoms
            .get(&cid.0)
            .map(Vec::as_slice)
            .ok_or_else(|| PageFault::Absent(cid.0.clone()))
    }

    fn consume_gas(&mut self, amount: u64) -> Result<(), OutOfGas> {
        if amount > self.gas_remaining {
            return Err(OutOfGas::Exhausted {
                remaining: self.gas_remaining,
                requested: amount,
            });
        }
        self.gas_remaining -= amount;
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SiliconReceipt {
    pub task_cid: AtomCid,
    pub result_vector: Vec<i32>,
    pub hardware_signature: String,
}

#[must_use]
pub fn verify_silicon_execution(
    expected_receipt: &SiliconReceipt,
    recomputed_receipt: &SiliconReceipt,
    epsilon_basis_points: u32,
) -> bool {
    if expected_receipt.task_cid != recomputed_receipt.task_cid {
        return false;
    }
    if expected_receipt.result_vector.len() != recomputed_receipt.result_vector.len() {
        return false;
    }
    let mut distance_sum: u64 = 0;
    let mut magnitude_sum: u64 = 0;
    for (a, b) in expected_receipt
        .result_vector
        .iter()
        .zip(recomputed_receipt.result_vector.iter())
    {
        distance_sum += u64::from(a.abs_diff(*b));
        magnitude_sum += i64::from(*a).unsigned_abs().max(1);
    }
    let ratio_bp = distance_sum.saturating_mul(10_000) / magnitude_sum;
    ratio_bp <= u64::from(epsilon_basis_points)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn worker_yields_when_required_atom_is_missing() {
        let required = AtomCid("cid-missing".to_owned());
        let mut worker = YieldingWorker {
            required_cid: required.clone(),
            gas_cost: 1,
        };
        let mut env = MockHostEnv::with_gas(10);
        let result = worker.execute(&AtomCid("task".to_owned()), &mut env);
        assert_eq!(result, WorkerResult::Yield(vec![required]));
    }

    #[test]
    fn worker_fails_on_out_of_gas() {
        let required = AtomCid("cid-1".to_owned());
        let mut worker = YieldingWorker {
            required_cid: required.clone(),
            gas_cost: 10,
        };
        let mut env = MockHostEnv::with_gas(1);
        env.put_atom(required, b"x".to_vec());
        let result = worker.execute(&AtomCid("task".to_owned()), &mut env);
        assert!(matches!(result, WorkerResult::Fail(_)));
    }

    #[test]
    fn worker_yield_then_resume_completes() {
        let required = AtomCid("cid-1".to_owned());
        let mut worker = YieldingWorker {
            required_cid: required.clone(),
            gas_cost: 2,
        };
        let mut env = MockHostEnv::with_gas(5);
        let first = worker.execute(&AtomCid("task".to_owned()), &mut env);
        assert!(matches!(first, WorkerResult::Yield(_)));

        env.put_atom(required, b"ready".to_vec());
        let second = worker.execute(&AtomCid("task".to_owned()), &mut env);
        assert!(matches!(second, WorkerResult::Complete(_)));
        assert_eq!(env.gas_remaining, 3);
    }

    #[test]
    fn silicon_verifier_accepts_small_bounded_divergence() {
        let expected = SiliconReceipt {
            task_cid: AtomCid("task".to_owned()),
            result_vector: vec![100, 100, 100],
            hardware_signature: "sig-a".to_owned(),
        };
        let recomputed = SiliconReceipt {
            task_cid: AtomCid("task".to_owned()),
            result_vector: vec![101, 100, 99],
            hardware_signature: "sig-b".to_owned(),
        };
        assert!(verify_silicon_execution(&expected, &recomputed, 200));
        assert!(!verify_silicon_execution(&expected, &recomputed, 10));
    }
}
