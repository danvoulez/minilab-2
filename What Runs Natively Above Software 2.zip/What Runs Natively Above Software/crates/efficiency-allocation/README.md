# efficiency-allocation

Paper 9 implementation surface:
- differentiated offices of power
- allocation policy contract
- misallocation detection report
