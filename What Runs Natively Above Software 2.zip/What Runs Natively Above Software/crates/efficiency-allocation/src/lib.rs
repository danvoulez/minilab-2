//! Paper 9 doctrinal layer: proper office allocation and category-violence detection.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum PowerOffice {
    Law,
    Exploration,
    Execution,
    ConsequenceClosure,
    Measurement,
    Coordination,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ComponentKind {
    Contract,
    Model,
    Worker,
    HumanSigner,
    EconomicMeter,
    ManagerPlane,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OfficeAssignment {
    pub component: ComponentKind,
    pub assigned_office: PowerOffice,
    pub context: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Misallocation {
    pub assignment: OfficeAssignment,
    pub reason: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AllocationReport {
    pub valid: Vec<OfficeAssignment>,
    pub violations: Vec<Misallocation>,
}

pub trait AllocationPolicy {
    fn allowed_offices(component: &ComponentKind) -> &'static [PowerOffice];
}

pub struct CanonicalPolicy;

impl AllocationPolicy for CanonicalPolicy {
    fn allowed_offices(component: &ComponentKind) -> &'static [PowerOffice] {
        match component {
            ComponentKind::Contract => &[PowerOffice::Law],
            ComponentKind::Model => &[PowerOffice::Exploration],
            ComponentKind::Worker => &[PowerOffice::Execution],
            ComponentKind::HumanSigner => &[PowerOffice::ConsequenceClosure],
            ComponentKind::EconomicMeter => &[PowerOffice::Measurement],
            ComponentKind::ManagerPlane => &[PowerOffice::Coordination],
        }
    }
}

#[must_use]
pub fn assess_allocations<P: AllocationPolicy>(
    assignments: &[OfficeAssignment],
) -> AllocationReport {
    let mut valid = Vec::new();
    let mut violations = Vec::new();
    for assignment in assignments {
        let allowed = P::allowed_offices(&assignment.component);
        if allowed.contains(&assignment.assigned_office) {
            valid.push(assignment.clone());
        } else {
            violations.push(Misallocation {
                assignment: assignment.clone(),
                reason: "component assigned to non-canonical office".to_owned(),
            });
        }
    }
    AllocationReport { valid, violations }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_category_misallocation() {
        let assignments = vec![
            OfficeAssignment {
                component: ComponentKind::Model,
                assigned_office: PowerOffice::Law,
                context: "model used as final governor".to_owned(),
            },
            OfficeAssignment {
                component: ComponentKind::Worker,
                assigned_office: PowerOffice::Execution,
                context: "worker executes bounded task".to_owned(),
            },
        ];
        let report = assess_allocations::<CanonicalPolicy>(&assignments);
        assert_eq!(report.valid.len(), 1);
        assert_eq!(report.violations.len(), 1);
    }
}
