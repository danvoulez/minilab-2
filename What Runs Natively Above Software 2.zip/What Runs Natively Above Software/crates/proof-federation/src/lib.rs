//! RFC-0004 federation: signed pointer advances over proof-carrying state.

use epistemic_storage::AtomCid;
use proof_runtime::ProofPack;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NodeIdentity {
    pub node_id: String,
    pub role: NodeRole,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct AuthorityId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct FederationSignature(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum NodeRole {
    Edge,
    Core,
    Witness,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuthorityGrant {
    pub authority_id: AuthorityId,
    pub allowed_namespaces: Vec<String>,
    pub valid_from_epoch: u64,
    pub valid_until_epoch: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StatePointer {
    pub namespace: String,
    pub head_cid: AtomCid,
    pub prev_head_cid: Option<AtomCid>,
    pub authority_id: AuthorityId,
    pub height: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum PointerClass {
    Contract,
    State,
    Proof,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PointerPolicy {
    pub require_proof_pack: bool,
    pub require_monotonic_height: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PointerAnnouncement {
    pub pointer: StatePointer,
    pub signature: FederationSignature,
    pub proof_pack_cid: Option<AtomCid>,
}

pub trait FederationTransport {
    fn request_atoms(&mut self, _cids: &[AtomCid]) -> Result<(), FederationError>;
    fn request_proof_pack(&mut self, _cid: &AtomCid) -> Result<ProofPack, FederationError>;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum DependencyStatus {
    Complete,
    MissingProof,
    MissingAtoms,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AcceptanceVerdict {
    Accepted,
    Rejected(AcceptRejectReason),
    ForkVisible,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AcceptRejectReason {
    InvalidSignature,
    UnknownAuthority,
    ProofRequired,
    RewindDetected,
    NamespaceDenied,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AcceptanceReceipt {
    pub namespace: String,
    pub verdict: AcceptanceVerdict,
    pub resulting_head: Option<AtomCid>,
}

pub trait PointerValidator {
    fn validate(&self, ann: &PointerAnnouncement, fed: &FederationView) -> AcceptanceReceipt;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FederationView {
    pub current_heads: HashMap<String, StatePointer>,
    pub authority_grants: HashMap<String, AuthorityGrant>,
    pub policy: PointerPolicy,
    pub current_epoch: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PointerFork {
    pub namespace: String,
    pub current_head: AtomCid,
    pub announced_head: AtomCid,
    pub announced_prev: Option<AtomCid>,
}

pub trait ResolutionPolicy {
    fn resolve(&self, fork: &PointerFork, ctx: &FederationView) -> ResolutionOutcome;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ResolutionOutcome {
    KeepCurrent,
    AdoptAnnounced,
    RequireHuman,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum FederationError {
    #[error("transport unavailable")]
    TransportUnavailable,
}

pub struct DefaultPointerValidator;

impl PointerValidator for DefaultPointerValidator {
    fn validate(&self, ann: &PointerAnnouncement, fed: &FederationView) -> AcceptanceReceipt {
        if ann.signature.0.is_empty() {
            return reject(
                &ann.pointer.namespace,
                AcceptRejectReason::InvalidSignature,
                fed.current_heads.get(&ann.pointer.namespace),
            );
        }
        let Some(grant) = fed.authority_grants.get(&ann.pointer.authority_id.0) else {
            return reject(
                &ann.pointer.namespace,
                AcceptRejectReason::UnknownAuthority,
                fed.current_heads.get(&ann.pointer.namespace),
            );
        };
        if !grant.allowed_namespaces.contains(&ann.pointer.namespace) {
            return reject(
                &ann.pointer.namespace,
                AcceptRejectReason::NamespaceDenied,
                fed.current_heads.get(&ann.pointer.namespace),
            );
        }
        if grant.valid_from_epoch > fed.current_epoch
            || grant
                .valid_until_epoch
                .is_some_and(|until| fed.current_epoch > until)
        {
            return reject(
                &ann.pointer.namespace,
                AcceptRejectReason::UnknownAuthority,
                fed.current_heads.get(&ann.pointer.namespace),
            );
        }
        if fed.policy.require_proof_pack && ann.proof_pack_cid.is_none() {
            return reject(
                &ann.pointer.namespace,
                AcceptRejectReason::ProofRequired,
                fed.current_heads.get(&ann.pointer.namespace),
            );
        }

        if let Some(current) = fed.current_heads.get(&ann.pointer.namespace) {
            if fed.policy.require_monotonic_height && ann.pointer.height <= current.height {
                return reject(
                    &ann.pointer.namespace,
                    AcceptRejectReason::RewindDetected,
                    Some(current),
                );
            }
            if ann.pointer.prev_head_cid.as_ref() != Some(&current.head_cid) {
                return AcceptanceReceipt {
                    namespace: ann.pointer.namespace.clone(),
                    verdict: AcceptanceVerdict::ForkVisible,
                    resulting_head: Some(current.head_cid.clone()),
                };
            }
        }

        AcceptanceReceipt {
            namespace: ann.pointer.namespace.clone(),
            verdict: AcceptanceVerdict::Accepted,
            resulting_head: Some(ann.pointer.head_cid.clone()),
        }
    }
}

fn reject(
    namespace: &str,
    reason: AcceptRejectReason,
    current: Option<&StatePointer>,
) -> AcceptanceReceipt {
    AcceptanceReceipt {
        namespace: namespace.to_owned(),
        verdict: AcceptanceVerdict::Rejected(reason),
        resulting_head: current.map(|p| p.head_cid.clone()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn view() -> FederationView {
        let mut heads = HashMap::new();
        heads.insert(
            "state/main".to_owned(),
            StatePointer {
                namespace: "state/main".to_owned(),
                head_cid: AtomCid("h1".to_owned()),
                prev_head_cid: Some(AtomCid("h0".to_owned())),
                authority_id: AuthorityId("auth-a".to_owned()),
                height: 7,
            },
        );
        let mut grants = HashMap::new();
        grants.insert(
            "auth-a".to_owned(),
            AuthorityGrant {
                authority_id: AuthorityId("auth-a".to_owned()),
                allowed_namespaces: vec!["state/main".to_owned()],
                valid_from_epoch: 0,
                valid_until_epoch: None,
            },
        );
        FederationView {
            current_heads: heads,
            authority_grants: grants,
            policy: PointerPolicy {
                require_proof_pack: true,
                require_monotonic_height: true,
            },
            current_epoch: 10,
        }
    }

    #[test]
    fn anti_rewind_rejects_old_height() {
        let fed = view();
        let ann = PointerAnnouncement {
            pointer: StatePointer {
                namespace: "state/main".to_owned(),
                head_cid: AtomCid("h2".to_owned()),
                prev_head_cid: Some(AtomCid("h1".to_owned())),
                authority_id: AuthorityId("auth-a".to_owned()),
                height: 7,
            },
            signature: FederationSignature("sig".to_owned()),
            proof_pack_cid: Some(AtomCid("pp1".to_owned())),
        };
        let result = DefaultPointerValidator.validate(&ann, &fed);
        assert!(matches!(
            result.verdict,
            AcceptanceVerdict::Rejected(AcceptRejectReason::RewindDetected)
        ));
    }

    #[test]
    fn fork_visibility_is_explicit() {
        let fed = view();
        let ann = PointerAnnouncement {
            pointer: StatePointer {
                namespace: "state/main".to_owned(),
                head_cid: AtomCid("h2".to_owned()),
                prev_head_cid: Some(AtomCid("different".to_owned())),
                authority_id: AuthorityId("auth-a".to_owned()),
                height: 8,
            },
            signature: FederationSignature("sig".to_owned()),
            proof_pack_cid: Some(AtomCid("pp1".to_owned())),
        };
        let result = DefaultPointerValidator.validate(&ann, &fed);
        assert_eq!(result.verdict, AcceptanceVerdict::ForkVisible);
    }

    #[test]
    fn missing_signature_is_rejected() {
        let fed = view();
        let ann = PointerAnnouncement {
            pointer: StatePointer {
                namespace: "state/main".to_owned(),
                head_cid: AtomCid("h2".to_owned()),
                prev_head_cid: Some(AtomCid("h1".to_owned())),
                authority_id: AuthorityId("auth-a".to_owned()),
                height: 8,
            },
            signature: FederationSignature(String::new()),
            proof_pack_cid: Some(AtomCid("pp1".to_owned())),
        };
        let result = DefaultPointerValidator.validate(&ann, &fed);
        assert!(matches!(
            result.verdict,
            AcceptanceVerdict::Rejected(AcceptRejectReason::InvalidSignature)
        ));
    }

    #[test]
    fn proof_requirement_is_enforced() {
        let fed = view();
        let ann = PointerAnnouncement {
            pointer: StatePointer {
                namespace: "state/main".to_owned(),
                head_cid: AtomCid("h2".to_owned()),
                prev_head_cid: Some(AtomCid("h1".to_owned())),
                authority_id: AuthorityId("auth-a".to_owned()),
                height: 8,
            },
            signature: FederationSignature("sig".to_owned()),
            proof_pack_cid: None,
        };
        let result = DefaultPointerValidator.validate(&ann, &fed);
        assert!(matches!(
            result.verdict,
            AcceptanceVerdict::Rejected(AcceptRejectReason::ProofRequired)
        ));
    }

    #[test]
    fn unknown_authority_is_rejected() {
        let fed = view();
        let ann = PointerAnnouncement {
            pointer: StatePointer {
                namespace: "state/main".to_owned(),
                head_cid: AtomCid("h2".to_owned()),
                prev_head_cid: Some(AtomCid("h1".to_owned())),
                authority_id: AuthorityId("auth-z".to_owned()),
                height: 8,
            },
            signature: FederationSignature("sig".to_owned()),
            proof_pack_cid: Some(AtomCid("pp1".to_owned())),
        };
        let result = DefaultPointerValidator.validate(&ann, &fed);
        assert!(matches!(
            result.verdict,
            AcceptanceVerdict::Rejected(AcceptRejectReason::UnknownAuthority)
        ));
    }
}
