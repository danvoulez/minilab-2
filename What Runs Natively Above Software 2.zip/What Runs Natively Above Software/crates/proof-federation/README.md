# proof-federation

RFC-0004 implementation surface:
- signed pointer announcement validation
- anti-rewind checks
- explicit fork visibility
