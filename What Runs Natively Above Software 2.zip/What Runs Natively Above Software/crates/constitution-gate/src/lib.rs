//! RFC-0001 constitutional gate: law of outcome, no-guess, and error contract.

use rand::{RngCore, SeedableRng};
use rand_chacha::ChaCha20Rng;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Verdict {
    Commit,
    Ghost,
    Reject,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ErrorContract {
    pub epsilon: f32,
    pub zero_guess_domains: Vec<String>,
    pub max_questions: u8,
}

impl ErrorContract {
    #[must_use]
    pub fn forbids_guess(&self, domain: &str) -> bool {
        self.zero_guess_domains.iter().any(|d| d == domain)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SiliconProposal {
    pub score_q16: u32,
    pub risk_q16: u32,
    pub kernel_hash: String,
}

#[must_use]
pub fn silicon_propose(seed: u64, idx: u64) -> SiliconProposal {
    let mut rng = ChaCha20Rng::seed_from_u64(seed ^ idx.wrapping_mul(0x9E37));
    let score_q16 = rng.next_u32() % 65_536;
    let mid = 52_000_i64;
    let dist = (i64::from(score_q16) - mid).abs().min(65_535);
    let risk_q16 = u32::try_from(dist).expect("risk distance is bounded to u32");

    SiliconProposal {
        score_q16,
        risk_q16,
        kernel_hash: "cpu_v1".to_owned(),
    }
}

pub const OK_MIN_Q16: u32 = 52_000;
pub const DOUBT_BELOW_Q16: u32 = 48_000;

pub const R_MISSING_EVIDENCE: u32 = 0x01;
pub const R_UNANCHORED: u32 = 0x02;
pub const R_POLICY_VIOLATION: u32 = 0x04;
pub const R_SILICON_DOUBT: u32 = 0x08;
pub const R_SILICON_NOT_OK: u32 = 0x10;

#[derive(Debug, Clone)]
pub struct GateInputs<'a> {
    pub domain: &'a str,
    pub has_intent: bool,
    pub has_evidence: bool,
    pub evidence_anchored: bool,
    pub policy_ok: bool,
    pub contract: &'a ErrorContract,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GateDecision {
    pub verdict: Verdict,
    pub reason_code: u32,
    pub question: Option<String>,
}

#[must_use]
pub fn gate_run(inp: GateInputs<'_>, silicon: SiliconProposal) -> GateDecision {
    let mut reason = 0_u32;

    if !inp.has_intent || !inp.has_evidence {
        reason |= R_MISSING_EVIDENCE;
        return GateDecision {
            verdict: Verdict::Ghost,
            reason_code: reason,
            question: Some("Which evidence is missing to confirm the case?".to_owned()),
        };
    }

    if !inp.evidence_anchored {
        reason |= R_UNANCHORED;
        return GateDecision {
            verdict: Verdict::Reject,
            reason_code: reason,
            question: None,
        };
    }

    if !inp.policy_ok {
        reason |= R_POLICY_VIOLATION;
        return GateDecision {
            verdict: Verdict::Reject,
            reason_code: reason,
            question: None,
        };
    }

    if inp.contract.forbids_guess(inp.domain) {
        if silicon.score_q16 < OK_MIN_Q16 {
            reason |= R_SILICON_NOT_OK;
            return GateDecision {
                verdict: Verdict::Reject,
                reason_code: reason,
                question: None,
            };
        }

        return GateDecision {
            verdict: Verdict::Commit,
            reason_code: reason,
            question: None,
        };
    }

    if silicon.score_q16 < DOUBT_BELOW_Q16 {
        reason |= R_SILICON_DOUBT;
        return GateDecision {
            verdict: Verdict::Ghost,
            reason_code: reason,
            question: Some("Material doubt detected; provide additional witness.".to_owned()),
        };
    }

    if silicon.score_q16 < OK_MIN_Q16 {
        reason |= R_SILICON_NOT_OK;
        return GateDecision {
            verdict: Verdict::Reject,
            reason_code: reason,
            question: None,
        };
    }

    GateDecision {
        verdict: Verdict::Commit,
        reason_code: reason,
        question: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn default_contract() -> ErrorContract {
        ErrorContract {
            epsilon: 0.05,
            zero_guess_domains: vec!["finance".to_owned()],
            max_questions: 1,
        }
    }

    #[test]
    fn gate_totality_is_preserved() {
        let c = default_contract();
        let inp = GateInputs {
            domain: "media",
            has_intent: true,
            has_evidence: true,
            evidence_anchored: true,
            policy_ok: true,
            contract: &c,
        };
        let verdict = gate_run(
            inp,
            SiliconProposal {
                score_q16: 50_000,
                risk_q16: 10,
                kernel_hash: "k".to_owned(),
            },
        )
        .verdict;
        assert!(matches!(
            verdict,
            Verdict::Commit | Verdict::Ghost | Verdict::Reject
        ));
    }

    #[test]
    fn no_guess_domain_rejects_sub_threshold_proposal() {
        let c = default_contract();
        let inp = GateInputs {
            domain: "finance",
            has_intent: true,
            has_evidence: true,
            evidence_anchored: true,
            policy_ok: true,
            contract: &c,
        };
        let decision = gate_run(
            inp,
            SiliconProposal {
                score_q16: OK_MIN_Q16 - 1,
                risk_q16: 9,
                kernel_hash: "k".to_owned(),
            },
        );
        assert_eq!(decision.verdict, Verdict::Reject);
        assert_ne!(decision.reason_code & R_SILICON_NOT_OK, 0);
    }

    #[test]
    fn missing_evidence_always_ghosts() {
        let c = default_contract();
        let inp = GateInputs {
            domain: "media",
            has_intent: true,
            has_evidence: false,
            evidence_anchored: true,
            policy_ok: true,
            contract: &c,
        };
        let decision = gate_run(inp, silicon_propose(7, 4));
        assert_eq!(decision.verdict, Verdict::Ghost);
        assert!(decision.question.is_some());
    }
}
