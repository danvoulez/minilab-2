# constitution-gate

RFC-0001 implementation surface:
- `Verdict`
- `ErrorContract`
- `gate_run`

This crate is the constitutional law boundary for decision legitimacy.
