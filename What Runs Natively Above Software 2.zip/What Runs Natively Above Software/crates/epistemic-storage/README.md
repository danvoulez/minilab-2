# epistemic-storage

RFC-0003 implementation surface:
- immutable `UniversalAtom` CAS model
- thermal states (`Hot/Warm/Cold/Absent`)
- pointer registry for state advancement
