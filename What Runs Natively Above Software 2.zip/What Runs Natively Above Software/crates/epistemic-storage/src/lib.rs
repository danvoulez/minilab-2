//! RFC-0003 atom space: immutable CID knowledge with explicit thermal state.

use blake3::Hasher;
use rusqlite::{Connection, OptionalExtension, params};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap};
use std::path::Path;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AtomCid(pub String);

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct CellId(pub String);

impl From<&str> for CellId {
    fn from(value: &str) -> Self {
        Self(value.to_owned())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct GhostId(pub String);

impl From<&str> for GhostId {
    fn from(value: &str) -> Self {
        Self(value.to_owned())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CellKind {
    Observation,
    Inference,
    Conclusion,
    Ghost,
    Resolution,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CellStatus {
    Ok,
    Doubt,
    Not,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum JustificationRef {
    Anchor(String),
    Cell(CellId),
    Ghost(GhostId),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum DoubtPolicy {
    SpawnGhost,
    AskWitness,
    Escalate,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ClosureClass {
    Provisional,
    Conditional,
    Final,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CellMeta {
    pub provenance: Vec<String>,
    pub closure_class: ClosureClass,
    pub causal_strength: u8,
    pub contradiction_with: Vec<CellId>,
}

impl Default for CellMeta {
    fn default() -> Self {
        Self {
            provenance: Vec::new(),
            closure_class: ClosureClass::Provisional,
            causal_strength: 0,
            contradiction_with: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CanonicalCell {
    pub id: CellId,
    pub kind: CellKind,
    pub content: String,
    pub status: CellStatus,
    pub depends_on: Vec<CellId>,
    pub confirmed_by: Vec<JustificationRef>,
    pub if_doubt: DoubtPolicy,
    pub created_at: u64,
    pub meta: CellMeta,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum GhostCriticality {
    Low,
    Medium,
    High,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum GhostStatus {
    Open,
    Resolved,
    Waived,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GhostRecord {
    pub id: GhostId,
    pub reason: String,
    pub criticality: GhostCriticality,
    pub opened_from: CellId,
    pub required_for: Vec<CellId>,
    pub status: GhostStatus,
    pub resolution_ref: Option<JustificationRef>,
}

#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct EpistemicGraph {
    pub cells: BTreeMap<CellId, CanonicalCell>,
    pub ghosts: BTreeMap<GhostId, GhostRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PersistedGraphSnapshot {
    pub case_id: String,
    pub version: u64,
    pub graph: EpistemicGraph,
    pub graph_hash: String,
    pub saved_at: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PersistedCaseState {
    pub case_id: String,
    pub pointers: Vec<StatePointer>,
    pub graph_version: Option<u64>,
    #[serde(default)]
    pub session_json: Option<String>,
    #[serde(default)]
    pub manager_state_json: Option<String>,
    #[serde(default)]
    pub state_hash: String,
    pub updated_at: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PersistedReceipt {
    pub case_id: String,
    pub sequence: u64,
    pub receipt_kind: String,
    pub payload_json: String,
    #[serde(default)]
    pub payload_hash: String,
    #[serde(default)]
    pub prev_record_hash: Option<String>,
    #[serde(default)]
    pub record_hash: String,
    pub recorded_at: u64,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum EpistemicGraphError {
    #[error("ghost not found: {0}")]
    GhostNotFound(String),
    #[error("ghost already closed: {0}")]
    GhostAlreadyClosed(String),
}

#[derive(Debug, Error)]
pub enum PersistenceError {
    #[error("sqlite error: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    #[error("numeric conversion failed for persisted field `{0}`")]
    NumericOverflow(&'static str),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct IntegrityReport {
    pub case_id: String,
    pub graph_hash_valid: bool,
    pub state_hash_valid: bool,
    pub receipt_chain_valid: bool,
    pub violation_count: u32,
    pub violations: Vec<String>,
}

impl EpistemicGraph {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert_cell(&mut self, cell: CanonicalCell) -> Option<CanonicalCell> {
        self.cells.insert(cell.id.clone(), cell)
    }

    pub fn insert_ghost(&mut self, ghost: GhostRecord) -> Option<GhostRecord> {
        self.ghosts.insert(ghost.id.clone(), ghost)
    }

    pub fn resolve_ghost(
        &mut self,
        ghost_id: &GhostId,
        resolution_ref: JustificationRef,
    ) -> Result<(), EpistemicGraphError> {
        let Some(ghost) = self.ghosts.get_mut(ghost_id) else {
            return Err(EpistemicGraphError::GhostNotFound(ghost_id.0.clone()));
        };
        if ghost.status != GhostStatus::Open {
            return Err(EpistemicGraphError::GhostAlreadyClosed(ghost_id.0.clone()));
        }

        ghost.status = GhostStatus::Resolved;
        ghost.resolution_ref = Some(resolution_ref);
        Ok(())
    }

    #[must_use]
    pub fn cell(&self, cell_id: &CellId) -> Option<&CanonicalCell> {
        self.cells.get(cell_id)
    }

    #[must_use]
    pub fn ghost(&self, ghost_id: &GhostId) -> Option<&GhostRecord> {
        self.ghosts.get(ghost_id)
    }

    #[must_use]
    pub fn dependents_of(&self, cell_id: &CellId) -> Vec<&CanonicalCell> {
        self.cells
            .values()
            .filter(|cell| cell.depends_on.iter().any(|dep| dep == cell_id))
            .collect()
    }

    #[must_use]
    pub fn has_open_ghost_for(&self, cell_id: &CellId) -> bool {
        self.ghosts.values().any(|ghost| {
            ghost.status == GhostStatus::Open
                && (&ghost.opened_from == cell_id
                    || ghost
                        .required_for
                        .iter()
                        .any(|required| required == cell_id))
        })
    }
}

pub trait EpistemicStateStore {
    fn save_graph(
        &self,
        case_id: &str,
        graph: &EpistemicGraph,
        saved_at: u64,
    ) -> Result<PersistedGraphSnapshot, PersistenceError>;

    fn load_graph(&self, case_id: &str)
    -> Result<Option<PersistedGraphSnapshot>, PersistenceError>;

    fn save_case_state(&self, state: &PersistedCaseState) -> Result<(), PersistenceError>;

    fn load_case_state(
        &self,
        case_id: &str,
    ) -> Result<Option<PersistedCaseState>, PersistenceError>;

    fn append_receipt(&self, receipt: &PersistedReceipt) -> Result<(), PersistenceError>;

    fn load_receipts(&self, case_id: &str) -> Result<Vec<PersistedReceipt>, PersistenceError>;
}

#[derive(Debug)]
pub struct SqliteEpistemicStore {
    conn: Connection,
}

impl SqliteEpistemicStore {
    pub fn open(path: impl AsRef<Path>) -> Result<Self, PersistenceError> {
        let conn = Connection::open(path)?;
        let store = Self { conn };
        store.init_schema()?;
        Ok(store)
    }

    pub fn open_in_memory() -> Result<Self, PersistenceError> {
        let conn = Connection::open_in_memory()?;
        let store = Self { conn };
        store.init_schema()?;
        Ok(store)
    }

    fn init_schema(&self) -> Result<(), PersistenceError> {
        self.conn.execute_batch(
            "BEGIN;
             CREATE TABLE IF NOT EXISTS epistemic_graph_snapshots (
                case_id TEXT NOT NULL,
                version INTEGER NOT NULL,
                graph_json TEXT NOT NULL,
                graph_hash TEXT NOT NULL DEFAULT '',
                saved_at INTEGER NOT NULL,
                PRIMARY KEY (case_id, version)
             );
             CREATE TABLE IF NOT EXISTS case_state (
                case_id TEXT PRIMARY KEY NOT NULL,
                state_json TEXT NOT NULL,
                state_hash TEXT NOT NULL DEFAULT '',
                updated_at INTEGER NOT NULL
             );
             CREATE TABLE IF NOT EXISTS epistemic_receipts (
                case_id TEXT NOT NULL,
                sequence INTEGER NOT NULL,
                receipt_kind TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                payload_hash TEXT NOT NULL DEFAULT '',
                prev_record_hash TEXT,
                record_hash TEXT NOT NULL DEFAULT '',
                recorded_at INTEGER NOT NULL,
                PRIMARY KEY (case_id, sequence)
             );
             COMMIT;",
        )?;
        self.ensure_column(
            "epistemic_graph_snapshots",
            "graph_hash",
            "TEXT NOT NULL DEFAULT ''",
        )?;
        self.ensure_column("case_state", "state_hash", "TEXT NOT NULL DEFAULT ''")?;
        self.ensure_column(
            "epistemic_receipts",
            "payload_hash",
            "TEXT NOT NULL DEFAULT ''",
        )?;
        self.ensure_column("epistemic_receipts", "prev_record_hash", "TEXT")?;
        self.ensure_column(
            "epistemic_receipts",
            "record_hash",
            "TEXT NOT NULL DEFAULT ''",
        )?;
        Ok(())
    }

    fn ensure_column(
        &self,
        table: &str,
        column: &str,
        definition: &str,
    ) -> Result<(), PersistenceError> {
        let pragma = format!("PRAGMA table_info({table})");
        let mut statement = self.conn.prepare(&pragma)?;
        let columns = statement.query_map([], |row| row.get::<_, String>(1))?;
        for existing in columns {
            if existing? == column {
                return Ok(());
            }
        }

        let alter = format!("ALTER TABLE {table} ADD COLUMN {column} {definition}");
        self.conn.execute(&alter, [])?;
        Ok(())
    }

    fn next_graph_version(&self, case_id: &str) -> Result<u64, PersistenceError> {
        let version: Option<i64> = self.conn.query_row(
            "SELECT MAX(version) FROM epistemic_graph_snapshots WHERE case_id = ?1",
            params![case_id],
            |row| row.get(0),
        )?;
        match version {
            Some(existing) => u64::try_from(existing)
                .map(|v| v + 1)
                .map_err(|_| PersistenceError::NumericOverflow("graph_snapshot.version")),
            None => Ok(1),
        }
    }

    fn decode_snapshot(
        case_id: String,
        version: i64,
        graph_json: String,
        graph_hash: String,
        saved_at: i64,
    ) -> Result<PersistedGraphSnapshot, PersistenceError> {
        Ok(PersistedGraphSnapshot {
            case_id,
            version: u64::try_from(version)
                .map_err(|_| PersistenceError::NumericOverflow("graph_snapshot.version"))?,
            graph: serde_json::from_str(&graph_json)?,
            graph_hash,
            saved_at: u64::try_from(saved_at)
                .map_err(|_| PersistenceError::NumericOverflow("graph_snapshot.saved_at"))?,
        })
    }

    fn hash_bytes(bytes: &[u8]) -> String {
        let mut hasher = Hasher::new();
        hasher.update(bytes);
        hex::encode(hasher.finalize().as_bytes())
    }

    fn hash_graph_json(graph_json: &str) -> String {
        Self::hash_bytes(graph_json.as_bytes())
    }

    fn hash_case_state(state: &PersistedCaseState) -> Result<String, PersistenceError> {
        let canonical = serde_json::json!({
            "case_id": state.case_id,
            "pointers": state.pointers,
            "graph_version": state.graph_version,
            "session_json": state.session_json,
            "manager_state_json": state.manager_state_json,
            "updated_at": state.updated_at
        });
        Ok(Self::hash_bytes(
            serde_json::to_string(&canonical)?.as_bytes(),
        ))
    }

    fn hash_receipt_payload(payload_json: &str) -> String {
        Self::hash_bytes(payload_json.as_bytes())
    }

    fn hash_receipt_record(receipt: &PersistedReceipt) -> Result<String, PersistenceError> {
        let canonical = serde_json::json!({
            "case_id": receipt.case_id,
            "sequence": receipt.sequence,
            "receipt_kind": receipt.receipt_kind,
            "payload_hash": receipt.payload_hash,
            "prev_record_hash": receipt.prev_record_hash,
            "recorded_at": receipt.recorded_at
        });
        Ok(Self::hash_bytes(
            serde_json::to_string(&canonical)?.as_bytes(),
        ))
    }

    fn latest_receipt_record_hash(
        &self,
        case_id: &str,
    ) -> Result<Option<String>, PersistenceError> {
        self.conn
            .query_row(
                "SELECT record_hash
                 FROM epistemic_receipts
                 WHERE case_id = ?1
                 ORDER BY sequence DESC
                 LIMIT 1",
                params![case_id],
                |row| row.get::<_, String>(0),
            )
            .optional()
            .map_err(Into::into)
    }

    pub fn verify_case_integrity(
        &self,
        case_id: &str,
    ) -> Result<IntegrityReport, PersistenceError> {
        let mut violations = Vec::new();

        let graph_hash_valid = match self
            .conn
            .query_row(
                "SELECT graph_json, graph_hash
             FROM epistemic_graph_snapshots
             WHERE case_id = ?1
             ORDER BY version DESC
             LIMIT 1",
                params![case_id],
                |row| Ok((row.get::<_, String>(0)?, row.get::<_, String>(1)?)),
            )
            .optional()?
        {
            Some((graph_json, graph_hash)) => {
                let expected = Self::hash_graph_json(&graph_json);
                if graph_hash != expected {
                    violations.push("graph_hash_mismatch".to_owned());
                    false
                } else {
                    true
                }
            }
            None => true,
        };

        let state_hash_valid = match self.load_case_state(case_id)? {
            Some(state) => {
                let expected = Self::hash_case_state(&state)?;
                if state.state_hash != expected {
                    violations.push("state_hash_mismatch".to_owned());
                    false
                } else {
                    true
                }
            }
            None => true,
        };

        let receipts = self.load_receipts(case_id)?;
        let mut receipt_chain_valid = true;
        let mut previous_hash: Option<String> = None;
        for receipt in receipts {
            let expected_payload_hash = Self::hash_receipt_payload(&receipt.payload_json);
            if receipt.payload_hash != expected_payload_hash {
                violations.push(format!(
                    "receipt_payload_hash_mismatch:{}",
                    receipt.sequence
                ));
                receipt_chain_valid = false;
            }
            if receipt.prev_record_hash != previous_hash {
                violations.push(format!("receipt_prev_hash_mismatch:{}", receipt.sequence));
                receipt_chain_valid = false;
            }
            let mut canonical_receipt = receipt.clone();
            canonical_receipt.payload_hash = expected_payload_hash;
            let expected_record_hash = Self::hash_receipt_record(&canonical_receipt)?;
            if receipt.record_hash != expected_record_hash {
                violations.push(format!("receipt_record_hash_mismatch:{}", receipt.sequence));
                receipt_chain_valid = false;
            }
            previous_hash = Some(receipt.record_hash);
        }

        Ok(IntegrityReport {
            case_id: case_id.to_owned(),
            graph_hash_valid,
            state_hash_valid,
            receipt_chain_valid,
            violation_count: violations.len() as u32,
            violations,
        })
    }
}

impl EpistemicStateStore for SqliteEpistemicStore {
    fn save_graph(
        &self,
        case_id: &str,
        graph: &EpistemicGraph,
        saved_at: u64,
    ) -> Result<PersistedGraphSnapshot, PersistenceError> {
        let version = self.next_graph_version(case_id)?;
        let graph_json = serde_json::to_string(graph)?;
        let graph_hash = Self::hash_graph_json(&graph_json);
        self.conn.execute(
            "INSERT INTO epistemic_graph_snapshots (case_id, version, graph_json, graph_hash, saved_at)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![case_id, version as i64, graph_json, graph_hash, saved_at as i64],
        )?;
        Ok(PersistedGraphSnapshot {
            case_id: case_id.to_owned(),
            version,
            graph: graph.clone(),
            graph_hash,
            saved_at,
        })
    }

    fn load_graph(
        &self,
        case_id: &str,
    ) -> Result<Option<PersistedGraphSnapshot>, PersistenceError> {
        self.conn
            .query_row(
                "SELECT case_id, version, graph_json, graph_hash, saved_at
                 FROM epistemic_graph_snapshots
                 WHERE case_id = ?1
                 ORDER BY version DESC
                 LIMIT 1",
                params![case_id],
                |row| {
                    let case_id: String = row.get(0)?;
                    let version: i64 = row.get(1)?;
                    let graph_json: String = row.get(2)?;
                    let graph_hash: String = row.get(3)?;
                    let saved_at: i64 = row.get(4)?;
                    Ok((case_id, version, graph_json, graph_hash, saved_at))
                },
            )
            .optional()?
            .map(
                |(stored_case_id, version, graph_json, graph_hash, saved_at)| {
                    Self::decode_snapshot(stored_case_id, version, graph_json, graph_hash, saved_at)
                },
            )
            .transpose()
    }

    fn save_case_state(&self, state: &PersistedCaseState) -> Result<(), PersistenceError> {
        let mut state_to_persist = state.clone();
        state_to_persist.state_hash = Self::hash_case_state(&state_to_persist)?;
        let state_json = serde_json::to_string(&state_to_persist)?;
        self.conn.execute(
            "INSERT INTO case_state (case_id, state_json, state_hash, updated_at)
             VALUES (?1, ?2, ?3, ?4)
             ON CONFLICT(case_id) DO UPDATE SET
                 state_json = excluded.state_json,
                 state_hash = excluded.state_hash,
                 updated_at = excluded.updated_at",
            params![
                state_to_persist.case_id,
                state_json,
                state_to_persist.state_hash,
                state_to_persist.updated_at as i64
            ],
        )?;
        Ok(())
    }

    fn load_case_state(
        &self,
        case_id: &str,
    ) -> Result<Option<PersistedCaseState>, PersistenceError> {
        self.conn
            .query_row(
                "SELECT state_json FROM case_state WHERE case_id = ?1",
                params![case_id],
                |row| row.get::<_, String>(0),
            )
            .optional()?
            .map(|json| serde_json::from_str(&json))
            .transpose()
            .map_err(Into::into)
    }

    fn append_receipt(&self, receipt: &PersistedReceipt) -> Result<(), PersistenceError> {
        let mut receipt_to_persist = receipt.clone();
        receipt_to_persist.payload_hash =
            Self::hash_receipt_payload(&receipt_to_persist.payload_json);
        receipt_to_persist.prev_record_hash =
            self.latest_receipt_record_hash(&receipt_to_persist.case_id)?;
        receipt_to_persist.record_hash = Self::hash_receipt_record(&receipt_to_persist)?;
        self.conn.execute(
            "INSERT INTO epistemic_receipts (case_id, sequence, receipt_kind, payload_json, payload_hash, prev_record_hash, record_hash, recorded_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
            params![
                receipt_to_persist.case_id,
                receipt_to_persist.sequence as i64,
                receipt_to_persist.receipt_kind,
                receipt_to_persist.payload_json,
                receipt_to_persist.payload_hash,
                receipt_to_persist.prev_record_hash,
                receipt_to_persist.record_hash,
                receipt_to_persist.recorded_at as i64
            ],
        )?;
        Ok(())
    }

    fn load_receipts(&self, case_id: &str) -> Result<Vec<PersistedReceipt>, PersistenceError> {
        let mut statement = self.conn.prepare(
            "SELECT case_id, sequence, receipt_kind, payload_json, payload_hash, prev_record_hash, record_hash, recorded_at
             FROM epistemic_receipts
             WHERE case_id = ?1
             ORDER BY sequence ASC",
        )?;
        let rows = statement.query_map(params![case_id], |row| {
            Ok((
                row.get::<_, String>(0)?,
                row.get::<_, i64>(1)?,
                row.get::<_, String>(2)?,
                row.get::<_, String>(3)?,
                row.get::<_, String>(4)?,
                row.get::<_, Option<String>>(5)?,
                row.get::<_, String>(6)?,
                row.get::<_, i64>(7)?,
            ))
        })?;

        let mut receipts = Vec::new();
        for row in rows {
            let (
                case_id,
                sequence,
                receipt_kind,
                payload_json,
                payload_hash,
                prev_record_hash,
                record_hash,
                recorded_at,
            ) = row?;
            receipts.push(PersistedReceipt {
                case_id,
                sequence: u64::try_from(sequence)
                    .map_err(|_| PersistenceError::NumericOverflow("receipt.sequence"))?,
                receipt_kind,
                payload_json,
                payload_hash,
                prev_record_hash,
                record_hash,
                recorded_at: u64::try_from(recorded_at)
                    .map_err(|_| PersistenceError::NumericOverflow("receipt.recorded_at"))?,
            });
        }
        Ok(receipts)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct UniversalAtom {
    pub cid: AtomCid,
    pub header: AtomHeader,
    pub payload: Vec<u8>,
}

impl UniversalAtom {
    #[must_use]
    pub fn new(kind: AtomKind, payload: Vec<u8>) -> Self {
        let mut hasher = Hasher::new();
        hasher.update(kind.as_tag().as_bytes());
        hasher.update(&payload);
        let cid = hex::encode(hasher.finalize().as_bytes());
        Self {
            cid: AtomCid(cid),
            header: AtomHeader { kind },
            payload,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AtomHeader {
    pub kind: AtomKind,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AtomKind {
    Fact,
    Set,
    Derivation,
    Receipt,
    Witness,
    Module,
}

impl AtomKind {
    #[must_use]
    fn as_tag(&self) -> &'static str {
        match self {
            Self::Fact => "fact",
            Self::Set => "set",
            Self::Derivation => "derivation",
            Self::Receipt => "receipt",
            Self::Witness => "witness",
            Self::Module => "module",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum EpistemicHeat {
    Hot,
    Warm,
    Cold,
    Absent,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ThermalMetrics {
    pub hot: u64,
    pub warm: u64,
    pub cold: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StatePointer {
    pub namespace: String,
    pub head_cid: AtomCid,
    pub prev_head_cid: Option<AtomCid>,
    pub height: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AtomStoreView {
    pub present_cids: Vec<AtomCid>,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum StorageError {
    #[error("immutable atom conflict for cid {0}")]
    ImmutableConflict(String),
    #[error("atom not found for cid {0}")]
    Missing(String),
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum PageFault {
    #[error("absent cid {0}")]
    Absent(String),
    #[error("cold cid {0}")]
    Cold(String),
}

pub trait AtomSpace {
    fn materialize(&mut self, atom: UniversalAtom) -> Result<AtomCid, StorageError>;
    fn get_payload(&self, cid: &AtomCid) -> Result<&[u8], PageFault>;
    fn get_heat(&self, cid: &AtomCid) -> EpistemicHeat;
    fn set_heat(&mut self, cid: &AtomCid, heat: EpistemicHeat) -> Result<(), StorageError>;
    fn metrics(&self) -> ThermalMetrics;
    fn view(&self) -> AtomStoreView;
}

#[derive(Debug, Default)]
pub struct InMemoryAtomSpace {
    atoms: HashMap<String, UniversalAtom>,
    heat: HashMap<String, EpistemicHeat>,
}

impl InMemoryAtomSpace {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }
}

impl AtomSpace for InMemoryAtomSpace {
    fn materialize(&mut self, atom: UniversalAtom) -> Result<AtomCid, StorageError> {
        let key = atom.cid.0.clone();
        if let Some(existing) = self.atoms.get(&key) {
            if existing.payload != atom.payload || existing.header != atom.header {
                return Err(StorageError::ImmutableConflict(key));
            }
            return Ok(atom.cid);
        }
        self.heat.insert(key.clone(), EpistemicHeat::Warm);
        self.atoms.insert(key, atom.clone());
        Ok(atom.cid)
    }

    fn get_payload(&self, cid: &AtomCid) -> Result<&[u8], PageFault> {
        match self.get_heat(cid) {
            EpistemicHeat::Absent => Err(PageFault::Absent(cid.0.clone())),
            EpistemicHeat::Cold => Err(PageFault::Cold(cid.0.clone())),
            EpistemicHeat::Warm | EpistemicHeat::Hot => {
                let atom = self
                    .atoms
                    .get(&cid.0)
                    .expect("heat map and atom map are kept in sync");
                Ok(&atom.payload)
            }
        }
    }

    fn get_heat(&self, cid: &AtomCid) -> EpistemicHeat {
        self.heat
            .get(&cid.0)
            .copied()
            .unwrap_or(EpistemicHeat::Absent)
    }

    fn set_heat(&mut self, cid: &AtomCid, heat: EpistemicHeat) -> Result<(), StorageError> {
        if !self.atoms.contains_key(&cid.0) {
            return Err(StorageError::Missing(cid.0.clone()));
        }
        self.heat.insert(cid.0.clone(), heat);
        Ok(())
    }

    fn metrics(&self) -> ThermalMetrics {
        let mut metrics = ThermalMetrics {
            hot: 0,
            warm: 0,
            cold: 0,
        };
        for h in self.heat.values() {
            match h {
                EpistemicHeat::Hot => metrics.hot += 1,
                EpistemicHeat::Warm => metrics.warm += 1,
                EpistemicHeat::Cold => metrics.cold += 1,
                EpistemicHeat::Absent => {}
            }
        }
        metrics
    }

    fn view(&self) -> AtomStoreView {
        AtomStoreView {
            present_cids: self.atoms.keys().cloned().map(AtomCid).collect(),
        }
    }
}

#[derive(Debug, Default)]
pub struct PointerRegistry {
    heads: BTreeMap<String, StatePointer>,
}

impl PointerRegistry {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn advance(
        &mut self,
        namespace: &str,
        new_head: AtomCid,
        expected_prev: Option<AtomCid>,
    ) -> Result<StatePointer, StorageError> {
        match self.heads.get(namespace) {
            None => {
                if expected_prev.is_some() {
                    return Err(StorageError::Missing("prev_head_mismatch".to_owned()));
                }
                let pointer = StatePointer {
                    namespace: namespace.to_owned(),
                    head_cid: new_head,
                    prev_head_cid: None,
                    height: 1,
                };
                self.heads.insert(namespace.to_owned(), pointer.clone());
                Ok(pointer)
            }
            Some(current) => {
                if current.head_cid != expected_prev.unwrap_or_else(|| AtomCid(String::new())) {
                    return Err(StorageError::Missing("prev_head_mismatch".to_owned()));
                }
                let pointer = StatePointer {
                    namespace: namespace.to_owned(),
                    head_cid: new_head,
                    prev_head_cid: Some(current.head_cid.clone()),
                    height: current.height + 1,
                };
                self.heads.insert(namespace.to_owned(), pointer.clone());
                Ok(pointer)
            }
        }
    }

    #[must_use]
    pub fn head(&self, namespace: &str) -> Option<&StatePointer> {
        self.heads.get(namespace)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    #[test]
    fn atom_is_immutable_once_materialized() {
        let mut space = InMemoryAtomSpace::new();
        let first = UniversalAtom::new(AtomKind::Fact, b"x".to_vec());
        let cid = first.cid.clone();
        assert!(space.materialize(first).is_ok());
        let conflicting = UniversalAtom {
            cid,
            header: AtomHeader {
                kind: AtomKind::Fact,
            },
            payload: b"y".to_vec(),
        };
        assert!(matches!(
            space.materialize(conflicting),
            Err(StorageError::ImmutableConflict(_))
        ));
    }

    #[test]
    fn cas_identity_is_stable_for_same_payload() {
        let a = UniversalAtom::new(AtomKind::Witness, b"payload".to_vec());
        let b = UniversalAtom::new(AtomKind::Witness, b"payload".to_vec());
        assert_eq!(a.cid, b.cid);
    }

    #[test]
    fn cold_payload_triggers_page_fault() {
        let mut space = InMemoryAtomSpace::new();
        let atom = UniversalAtom::new(AtomKind::Set, b"abc".to_vec());
        let cid = atom.cid.clone();
        let _ = space.materialize(atom);
        let _ = space.set_heat(&cid, EpistemicHeat::Cold);
        assert!(matches!(space.get_payload(&cid), Err(PageFault::Cold(_))));
    }

    #[test]
    fn epistemic_graph_tracks_open_ghosts_for_cells() {
        let mut graph = EpistemicGraph::new();
        let cell_id = CellId::from("c1");
        graph.insert_cell(CanonicalCell {
            id: cell_id.clone(),
            kind: CellKind::Inference,
            content: "claim".to_owned(),
            status: CellStatus::Doubt,
            depends_on: Vec::new(),
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g1"),
            reason: "missing support".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: cell_id.clone(),
            required_for: vec![cell_id.clone()],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        assert!(graph.has_open_ghost_for(&cell_id));
        assert_eq!(graph.dependents_of(&cell_id).len(), 0);
    }

    #[test]
    fn graph_resolves_ghost_with_explicit_resolution_ref() {
        let mut graph = EpistemicGraph::new();
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g1"),
            reason: "missing support".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("c1"),
            required_for: vec![CellId::from("c2")],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        graph
            .resolve_ghost(
                &GhostId::from("g1"),
                JustificationRef::Anchor("witness:bank_statement".to_owned()),
            )
            .expect("ghost should resolve");

        let ghost = graph
            .ghost(&GhostId::from("g1"))
            .expect("ghost should still exist");
        assert_eq!(ghost.status, GhostStatus::Resolved);
        assert_eq!(
            ghost.resolution_ref,
            Some(JustificationRef::Anchor(
                "witness:bank_statement".to_owned()
            ))
        );
    }

    #[test]
    fn sqlite_store_round_trips_graph_case_state_and_receipts_across_reopen() {
        let db_path = std::env::temp_dir().join(format!(
            "epistemic-store-roundtrip-{}-{}.sqlite",
            std::process::id(),
            1_763_651_111_u64
        ));
        let _ = fs::remove_file(&db_path);

        let mut graph = EpistemicGraph::new();
        let cell_id = CellId::from("c1");
        graph.insert_cell(CanonicalCell {
            id: cell_id.clone(),
            kind: CellKind::Conclusion,
            content: "wire transfer completed".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("o1")],
            confirmed_by: vec![JustificationRef::Anchor("witness:ledger".to_owned())],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 10,
            meta: CellMeta::default(),
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g1"),
            reason: "missing settlement confirmation".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: cell_id.clone(),
            required_for: vec![cell_id],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        let pointer = StatePointer {
            namespace: "case:transfer-1".to_owned(),
            head_cid: AtomCid("cid-head-1".to_owned()),
            prev_head_cid: Some(AtomCid("cid-head-0".to_owned())),
            height: 2,
        };

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should open");
            let snapshot = store
                .save_graph("case-1", &graph, 100)
                .expect("graph should persist");
            assert_eq!(snapshot.version, 1);
            store
                .save_case_state(&PersistedCaseState {
                    case_id: "case-1".to_owned(),
                    pointers: vec![pointer.clone()],
                    graph_version: Some(snapshot.version),
                    session_json: Some("{\"case_id\":\"case-1\"}".to_owned()),
                    manager_state_json: Some("{\"state\":\"ReadyToAdvance\"}".to_owned()),
                    state_hash: String::new(),
                    updated_at: 101,
                })
                .expect("case state should persist");
            store
                .append_receipt(&PersistedReceipt {
                    case_id: "case-1".to_owned(),
                    sequence: 1,
                    receipt_kind: "EpistemicClosureEvaluated".to_owned(),
                    payload_json: "{\"verdict\":\"Ghost\"}".to_owned(),
                    payload_hash: String::new(),
                    prev_record_hash: None,
                    record_hash: String::new(),
                    recorded_at: 102,
                })
                .expect("receipt should append");
        }

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should reopen");
            let restored_snapshot = store
                .load_graph("case-1")
                .expect("graph load should succeed")
                .expect("graph snapshot should exist");
            let restored_state = store
                .load_case_state("case-1")
                .expect("case state load should succeed")
                .expect("case state should exist");
            let restored_receipts = store
                .load_receipts("case-1")
                .expect("receipt load should succeed");

            assert_eq!(restored_snapshot.case_id, "case-1");
            assert_eq!(restored_snapshot.saved_at, 100);
            assert_eq!(restored_snapshot.graph, graph);
            assert_eq!(restored_state.pointers, vec![pointer]);
            assert_eq!(
                restored_state.graph_version,
                Some(restored_snapshot.version)
            );
            assert_eq!(
                restored_state.session_json,
                Some("{\"case_id\":\"case-1\"}".to_owned())
            );
            assert_eq!(
                restored_state.manager_state_json,
                Some("{\"state\":\"ReadyToAdvance\"}".to_owned())
            );
            assert!(!restored_state.state_hash.is_empty());
            assert_eq!(restored_receipts.len(), 1);
            assert_eq!(
                restored_receipts[0].receipt_kind,
                "EpistemicClosureEvaluated"
            );
            assert_eq!(restored_receipts[0].payload_json, "{\"verdict\":\"Ghost\"}");
            assert!(!restored_receipts[0].payload_hash.is_empty());
            assert!(restored_receipts[0].prev_record_hash.is_none());
            assert!(!restored_receipts[0].record_hash.is_empty());

            let integrity = store
                .verify_case_integrity("case-1")
                .expect("integrity verification should succeed");
            assert!(integrity.graph_hash_valid);
            assert!(integrity.state_hash_valid);
            assert!(integrity.receipt_chain_valid);
            assert_eq!(integrity.violation_count, 0);
        }

        let _ = fs::remove_file(db_path);
    }

    #[test]
    fn sqlite_store_detects_manual_receipt_tampering() {
        let store = SqliteEpistemicStore::open_in_memory().expect("sqlite store should open");

        let graph = EpistemicGraph::new();
        store
            .save_graph("case-tamper", &graph, 10)
            .expect("graph should persist");
        store
            .save_case_state(&PersistedCaseState {
                case_id: "case-tamper".to_owned(),
                pointers: Vec::new(),
                graph_version: Some(1),
                session_json: None,
                manager_state_json: None,
                state_hash: String::new(),
                updated_at: 11,
            })
            .expect("state should persist");
        store
            .append_receipt(&PersistedReceipt {
                case_id: "case-tamper".to_owned(),
                sequence: 1,
                receipt_kind: "EpistemicClosureEvaluated".to_owned(),
                payload_json: "{\"verdict\":\"Ghost\"}".to_owned(),
                payload_hash: String::new(),
                prev_record_hash: None,
                record_hash: String::new(),
                recorded_at: 12,
            })
            .expect("receipt should persist");

        store
            .conn
            .execute(
                "UPDATE epistemic_receipts
                 SET payload_json = ?1
                 WHERE case_id = ?2 AND sequence = ?3",
                params!["{\"verdict\":\"Commit\"}", "case-tamper", 1_i64],
            )
            .expect("manual tamper update should succeed");

        let integrity = store
            .verify_case_integrity("case-tamper")
            .expect("integrity verification should succeed");
        assert!(integrity.graph_hash_valid);
        assert!(integrity.state_hash_valid);
        assert!(!integrity.receipt_chain_valid);
        assert!(
            integrity
                .violations
                .iter()
                .any(|issue| issue.starts_with("receipt_payload_hash_mismatch:1"))
        );
        assert!(
            integrity
                .violations
                .iter()
                .any(|issue| issue.starts_with("receipt_record_hash_mismatch:1"))
        );
    }
}
