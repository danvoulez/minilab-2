use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::collections::HashMap;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::Duration;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ProposalStage {
    Initial,
    Resolution,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkPrompt {
    pub case_id: String,
    pub stage: ProposalStage,
    pub input: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProposalSubmission {
    pub raw_output: String,
    pub proposal_json: String,
}

#[derive(Debug, Error, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ProposerError {
    #[error("missing mock proposal for case `{case_id}` at stage `{stage:?}`")]
    MissingMockProposal {
        case_id: String,
        stage: ProposalStage,
    },
    #[error("structured backend failure: {0}")]
    Backend(String),
}

pub trait Proposer {
    fn propose(&self, prompt: &BenchmarkPrompt) -> Result<ProposalSubmission, ProposerError>;
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct MockProposalKey {
    case_id: String,
    stage: ProposalStage,
}

#[derive(Debug, Clone, Default)]
pub struct MockProposer {
    outputs: HashMap<MockProposalKey, ProposalSubmission>,
}

impl MockProposer {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    #[must_use]
    pub fn with_submission(
        mut self,
        case_id: &str,
        stage: ProposalStage,
        submission: ProposalSubmission,
    ) -> Self {
        self.outputs.insert(
            MockProposalKey {
                case_id: case_id.to_owned(),
                stage,
            },
            submission,
        );
        self
    }
}

impl Proposer for MockProposer {
    fn propose(&self, prompt: &BenchmarkPrompt) -> Result<ProposalSubmission, ProposerError> {
        self.outputs
            .get(&MockProposalKey {
                case_id: prompt.case_id.clone(),
                stage: prompt.stage.clone(),
            })
            .cloned()
            .ok_or_else(|| ProposerError::MissingMockProposal {
                case_id: prompt.case_id.clone(),
                stage: prompt.stage.clone(),
            })
    }
}

pub trait StructuredJsonBackend {
    fn generate_submission(
        &self,
        prompt: &BenchmarkPrompt,
    ) -> Result<ProposalSubmission, ProposerError>;

    fn generate_json(&self, prompt: &BenchmarkPrompt) -> Result<String, ProposerError> {
        Ok(self.generate_submission(prompt)?.proposal_json)
    }
}

#[derive(Debug)]
pub struct OpenAiResponsesBackend {
    client: Client,
    api_key: String,
    model: String,
    base_url: String,
    system_prompt: String,
    reasoning_effort: Option<String>,
    background: bool,
}

impl OpenAiResponsesBackend {
    pub fn new(
        api_key: impl Into<String>,
        model: impl Into<String>,
    ) -> Result<Self, ProposerError> {
        Self::with_base_url(api_key, model, "https://api.openai.com/v1/responses")
    }

    pub fn with_base_url(
        api_key: impl Into<String>,
        model: impl Into<String>,
        base_url: impl Into<String>,
    ) -> Result<Self, ProposerError> {
        let client = Client::builder()
            .timeout(Duration::from_secs(60))
            .build()
            .map_err(|err| ProposerError::Backend(format!("failed to build http client: {err}")))?;
        Ok(Self {
            client,
            api_key: api_key.into(),
            model: model.into(),
            base_url: base_url.into(),
            system_prompt: default_openai_system_prompt(),
            reasoning_effort: None,
            background: false,
        })
    }

    #[must_use]
    pub fn with_system_prompt(mut self, system_prompt: impl Into<String>) -> Self {
        self.system_prompt = system_prompt.into();
        self
    }

    #[must_use]
    pub fn with_reasoning_effort(mut self, reasoning_effort: impl Into<String>) -> Self {
        self.reasoning_effort = Some(reasoning_effort.into());
        self
    }

    #[must_use]
    pub fn with_background(mut self, background: bool) -> Self {
        self.background = background;
        self
    }

    fn request_body(&self, prompt: &BenchmarkPrompt) -> Value {
        let mut body = json!({
            "model": self.model,
            "instructions": self.system_prompt,
            "input": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": format!(
                                "Case ID: {}\nStage: {:?}\n\nBenchmark input:\n{}",
                                prompt.case_id, prompt.stage, prompt.input
                            ),
                        }
                    ]
                }
            ],
            "store": false,
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": "epistemic_proposal",
                    "strict": true,
                    "schema": proposal_json_schema(),
                }
            }
        });
        if let Some(reasoning_effort) = &self.reasoning_effort {
            body["reasoning"] = json!({
                "effort": reasoning_effort,
            });
        }
        if self.background {
            body["background"] = json!(true);
        }
        body
    }
}

impl StructuredJsonBackend for OpenAiResponsesBackend {
    fn generate_submission(
        &self,
        prompt: &BenchmarkPrompt,
    ) -> Result<ProposalSubmission, ProposerError> {
        let body = self.request_body(prompt);
        let response = self
            .client
            .post(&self.base_url)
            .bearer_auth(&self.api_key)
            .json(&body)
            .send()
            .map_err(|err| {
                ProposerError::Backend(format!(
                    "openai responses request failed for case `{}`: {err}",
                    prompt.case_id
                ))
            })?;

        let status = response.status();
        let raw_output = response.text().map_err(|err| {
            ProposerError::Backend(format!(
                "failed to read openai responses body for case `{}`: {err}",
                prompt.case_id
            ))
        })?;
        if !status.is_success() {
            return Err(ProposerError::Backend(format!(
                "openai responses request failed with status {} for case `{}`: {}",
                status, prompt.case_id, raw_output
            )));
        }

        let proposal_json = extract_openai_output_json(&raw_output)?;
        Ok(ProposalSubmission {
            raw_output,
            proposal_json,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CommandStructuredJsonBackend {
    program: PathBuf,
    args: Vec<String>,
    cwd: Option<PathBuf>,
    env: Vec<(String, String)>,
}

impl CommandStructuredJsonBackend {
    #[must_use]
    pub fn new(program: impl Into<PathBuf>) -> Self {
        Self {
            program: program.into(),
            args: Vec::new(),
            cwd: None,
            env: Vec::new(),
        }
    }

    #[must_use]
    pub fn arg(mut self, arg: impl Into<String>) -> Self {
        self.args.push(arg.into());
        self
    }

    #[must_use]
    pub fn args<I, S>(mut self, args: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.args.extend(args.into_iter().map(Into::into));
        self
    }

    #[must_use]
    pub fn cwd(mut self, cwd: impl Into<PathBuf>) -> Self {
        self.cwd = Some(cwd.into());
        self
    }

    #[must_use]
    pub fn env(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.env.push((key.into(), value.into()));
        self
    }
}

impl StructuredJsonBackend for CommandStructuredJsonBackend {
    fn generate_submission(
        &self,
        prompt: &BenchmarkPrompt,
    ) -> Result<ProposalSubmission, ProposerError> {
        let prompt_json = serde_json::to_vec(prompt).map_err(|err| {
            ProposerError::Backend(format!(
                "failed to serialize benchmark prompt for {}: {err}",
                prompt.case_id
            ))
        })?;

        let mut command = Command::new(&self.program);
        command.args(&self.args);
        command.stdin(Stdio::piped());
        command.stdout(Stdio::piped());
        command.stderr(Stdio::piped());
        if let Some(cwd) = &self.cwd {
            command.current_dir(cwd);
        }
        for (key, value) in &self.env {
            command.env(key, value);
        }

        let mut child = command.spawn().map_err(|err| {
            ProposerError::Backend(format!(
                "failed to spawn structured proposer command `{}`: {err}",
                self.program.display()
            ))
        })?;

        let mut stdin = child.stdin.take().ok_or_else(|| {
            ProposerError::Backend(format!(
                "structured proposer command `{}` did not expose stdin",
                self.program.display()
            ))
        })?;
        stdin.write_all(&prompt_json).map_err(|err| {
            ProposerError::Backend(format!(
                "failed to write benchmark prompt to `{}` stdin: {err}",
                self.program.display()
            ))
        })?;
        drop(stdin);

        let output = child.wait_with_output().map_err(|err| {
            ProposerError::Backend(format!(
                "failed to wait for structured proposer command `{}`: {err}",
                self.program.display()
            ))
        })?;

        let stdout = String::from_utf8(output.stdout).map_err(|err| {
            ProposerError::Backend(format!(
                "structured proposer command `{}` returned non-utf8 stdout: {err}",
                self.program.display()
            ))
        })?;
        let stderr = String::from_utf8(output.stderr).map_err(|err| {
            ProposerError::Backend(format!(
                "structured proposer command `{}` returned non-utf8 stderr: {err}",
                self.program.display()
            ))
        })?;

        if !output.status.success() {
            return Err(ProposerError::Backend(format!(
                "structured proposer command `{}` exited with status {}. stderr: {}",
                self.program.display(),
                output.status,
                stderr.trim()
            )));
        }

        let proposal_json = stdout.trim().to_owned();
        if proposal_json.is_empty() {
            return Err(ProposerError::Backend(format!(
                "structured proposer command `{}` returned empty stdout. stderr: {}",
                self.program.display(),
                stderr.trim()
            )));
        }

        Ok(ProposalSubmission {
            raw_output: stdout,
            proposal_json,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileStructuredJsonBackend {
    root: PathBuf,
}

impl FileStructuredJsonBackend {
    #[must_use]
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    #[must_use]
    pub fn root(&self) -> &Path {
        &self.root
    }

    fn path_for(&self, prompt: &BenchmarkPrompt) -> PathBuf {
        let stage = match prompt.stage {
            ProposalStage::Initial => "initial.json",
            ProposalStage::Resolution => "resolution.json",
        };
        self.root.join(&prompt.case_id).join(stage)
    }
}

impl StructuredJsonBackend for FileStructuredJsonBackend {
    fn generate_submission(
        &self,
        prompt: &BenchmarkPrompt,
    ) -> Result<ProposalSubmission, ProposerError> {
        let path = self.path_for(prompt);
        let proposal_json = fs::read_to_string(&path).map_err(|err| {
            ProposerError::Backend(format!(
                "failed to read structured proposal from {}: {err}",
                path.display()
            ))
        })?;
        Ok(ProposalSubmission {
            raw_output: proposal_json.clone(),
            proposal_json,
        })
    }
}

#[derive(Debug, Clone)]
pub struct StructuredJsonProposer<B> {
    backend: B,
}

impl<B> StructuredJsonProposer<B> {
    #[must_use]
    pub fn new(backend: B) -> Self {
        Self { backend }
    }
}

impl<B> Proposer for StructuredJsonProposer<B>
where
    B: StructuredJsonBackend,
{
    fn propose(&self, prompt: &BenchmarkPrompt) -> Result<ProposalSubmission, ProposerError> {
        self.backend.generate_submission(prompt)
    }
}

fn default_openai_system_prompt() -> String {
    "You convert benchmark inputs into strict epistemic proposal JSON. \
Never invent anchors, witnesses, confirmations, or resolved support. \
If support is missing but recoverable, represent the gap explicitly with Ghost records and appropriate if_doubt policies. \
If support is missing and closure is illegitimate, do not pretend it is grounded. \
Return only JSON that matches the provided schema."
        .to_owned()
}

fn proposal_json_schema() -> Value {
    json!({
        "type": "object",
        "additionalProperties": false,
        "$defs": {
            "justification_anchor": {
                "type": "object",
                "additionalProperties": false,
                "properties": {
                    "anchor": { "type": "string" }
                },
                "required": ["anchor"]
            },
            "justification_cell": {
                "type": "object",
                "additionalProperties": false,
                "properties": {
                    "cell": { "type": "string" }
                },
                "required": ["cell"]
            },
            "justification_ghost": {
                "type": "object",
                "additionalProperties": false,
                "properties": {
                    "ghost": { "type": "string" }
                },
                "required": ["ghost"]
            },
            "cell_meta": {
                "type": "object",
                "additionalProperties": false,
                "properties": {
                    "provenance": {
                        "type": "array",
                        "items": { "type": "string" }
                    },
                    "closure_class": {
                        "anyOf": [
                            {
                                "type": "string",
                                "enum": ["Stable", "Provisional", "Fraudulent"]
                            },
                            { "type": "null" }
                        ]
                    },
                    "causal_strength": {
                        "anyOf": [
                            {
                                "type": "integer",
                                "minimum": 0,
                                "maximum": 255
                            },
                            { "type": "null" }
                        ]
                    },
                    "contradiction_with": {
                        "type": "array",
                        "items": { "type": "string" }
                    }
                },
                "required": ["provenance", "closure_class", "causal_strength", "contradiction_with"]
            }
        },
        "properties": {
            "cells": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": false,
                    "properties": {
                        "id": { "type": "string" },
                        "kind": {
                            "type": "string",
                            "enum": ["Observation", "Inference", "Conclusion", "Ghost", "Resolution"]
                        },
                        "content": { "type": "string" },
                        "status": {
                            "anyOf": [
                                {
                                    "type": "string",
                                    "enum": ["Proposed", "Supported", "Blocked", "Committed"]
                                },
                                { "type": "null" }
                            ]
                        },
                        "depends_on": {
                            "type": "array",
                            "items": { "type": "string" }
                        },
                        "confirmed_by": {
                            "type": "array",
                            "items": {
                                "anyOf": [
                                    { "$ref": "#/$defs/justification_anchor" },
                                    { "$ref": "#/$defs/justification_cell" },
                                    { "$ref": "#/$defs/justification_ghost" }
                                ]
                            }
                        },
                        "if_doubt": {
                            "anyOf": [
                                {
                                    "type": "string",
                                    "enum": ["Block", "AskWitness", "SpawnGhost"]
                                },
                                { "type": "null" }
                            ]
                        },
                        "created_at": {
                            "anyOf": [
                                { "type": "integer" },
                                { "type": "null" }
                            ]
                        },
                        "meta": {
                            "anyOf": [
                                { "$ref": "#/$defs/cell_meta" },
                                { "type": "null" }
                            ]
                        }
                    },
                    "required": [
                        "id",
                        "kind",
                        "content",
                        "status",
                        "depends_on",
                        "confirmed_by",
                        "if_doubt",
                        "created_at",
                        "meta"
                    ]
                }
            },
            "ghosts": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": false,
                    "properties": {
                        "id": { "type": "string" },
                        "reason": { "type": "string" },
                        "criticality": {
                            "anyOf": [
                                {
                                    "type": "string",
                                    "enum": ["Low", "Medium", "High"]
                                },
                                { "type": "null" }
                            ]
                        },
                        "opened_from": { "type": "string" },
                        "required_for": {
                            "type": "array",
                            "items": { "type": "string" }
                        },
                        "status": {
                            "anyOf": [
                                {
                                    "type": "string",
                                    "enum": ["Open", "Resolved", "Waived"]
                                },
                                { "type": "null" }
                            ]
                        }
                    },
                    "required": ["id", "reason", "criticality", "opened_from", "required_for", "status"]
                }
            }
        },
        "required": ["cells", "ghosts"]
    })
}

fn extract_openai_output_json(raw_response: &str) -> Result<String, ProposerError> {
    let parsed: Value = serde_json::from_str(raw_response).map_err(|err| {
        ProposerError::Backend(format!("openai responses body was not valid json: {err}"))
    })?;

    let mut text_chunks = Vec::new();
    let mut refusals = Vec::new();
    if let Some(outputs) = parsed.get("output").and_then(Value::as_array) {
        for output in outputs {
            if output.get("type").and_then(Value::as_str) != Some("message") {
                continue;
            }
            if let Some(contents) = output.get("content").and_then(Value::as_array) {
                for item in contents {
                    match item.get("type").and_then(Value::as_str) {
                        Some("output_text") => {
                            if let Some(text) = item.get("text").and_then(Value::as_str) {
                                text_chunks.push(text.to_owned());
                            }
                        }
                        Some("refusal") => {
                            if let Some(text) = item.get("refusal").and_then(Value::as_str) {
                                refusals.push(text.to_owned());
                            }
                        }
                        _ => {}
                    }
                }
            }
        }
    }

    let proposal_json = text_chunks.join("").trim().to_owned();
    if proposal_json.is_empty() {
        if !refusals.is_empty() {
            return Err(ProposerError::Backend(format!(
                "openai model refused structured proposal output: {}",
                refusals.join(" | ")
            )));
        }
        return Err(ProposerError::Backend(
            "openai responses body contained no output_text payload".to_owned(),
        ));
    }

    Ok(proposal_json)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::PermissionsExt;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn unique_temp_dir() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("time should move forward")
            .as_nanos();
        std::env::temp_dir().join(format!("manager-plane-proposer-{nanos}"))
    }

    #[test]
    fn file_backend_reads_stage_specific_json() {
        let root = unique_temp_dir();
        let case_dir = root.join("case-file");
        fs::create_dir_all(&case_dir).expect("temp directory should be created");
        fs::write(
            case_dir.join("initial.json"),
            r#"{"cells":[{"id":"c1","kind":"Conclusion","content":"initial"}]}"#,
        )
        .expect("initial json should be written");
        fs::write(
            case_dir.join("resolution.json"),
            r#"{"cells":[{"id":"c1","kind":"Conclusion","content":"resolved"}]}"#,
        )
        .expect("resolution json should be written");

        let backend = FileStructuredJsonBackend::new(&root);
        let initial = backend
            .generate_json(&BenchmarkPrompt {
                case_id: "case-file".to_owned(),
                stage: ProposalStage::Initial,
                input: "ignored".to_owned(),
            })
            .expect("initial json should load");
        let resolution = backend
            .generate_json(&BenchmarkPrompt {
                case_id: "case-file".to_owned(),
                stage: ProposalStage::Resolution,
                input: "ignored".to_owned(),
            })
            .expect("resolution json should load");

        assert!(initial.contains("initial"));
        assert!(resolution.contains("resolved"));

        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn command_backend_passes_prompt_via_stdin_and_reads_stdout_json() {
        let root = unique_temp_dir();
        fs::create_dir_all(&root).expect("temp directory should be created");
        let capture_path = root.join("captured-prompt.json");
        let script_path = root.join("emit-json.sh");
        fs::write(
            &script_path,
            format!(
                "#!/bin/sh\ncat > \"{}\"\nprintf '%s' '{{\"cells\":[{{\"id\":\"c1\",\"kind\":\"Conclusion\",\"content\":\"from-command\"}}]}}'\n",
                capture_path.display()
            ),
        )
        .expect("script should be written");
        let mut permissions = fs::metadata(&script_path)
            .expect("script metadata should exist")
            .permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&script_path, permissions).expect("script should be executable");

        let backend = CommandStructuredJsonBackend::new(&script_path);
        let output = backend
            .generate_json(&BenchmarkPrompt {
                case_id: "case-command".to_owned(),
                stage: ProposalStage::Initial,
                input: "prove grounding".to_owned(),
            })
            .expect("command backend should emit proposal json");

        let captured_prompt =
            fs::read_to_string(&capture_path).expect("prompt should be captured to disk");
        assert!(captured_prompt.contains("\"case_id\":\"case-command\""));
        assert!(captured_prompt.contains("\"input\":\"prove grounding\""));
        assert!(output.contains("\"from-command\""));

        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn command_backend_surfaces_non_zero_exit_as_backend_error() {
        let backend =
            CommandStructuredJsonBackend::new("/bin/sh").args(["-c", "echo nope >&2; exit 9"]);
        let err = backend
            .generate_json(&BenchmarkPrompt {
                case_id: "case-command-error".to_owned(),
                stage: ProposalStage::Initial,
                input: "ignored".to_owned(),
            })
            .expect_err("non-zero command must fail");

        match err {
            ProposerError::Backend(message) => {
                assert!(message.contains("status"));
                assert!(message.contains("nope"));
            }
            other => panic!("unexpected proposer error: {other:?}"),
        }
    }

    #[test]
    fn structured_backend_default_generate_json_uses_submission_payload() {
        struct SubmissionOnlyBackend;

        impl StructuredJsonBackend for SubmissionOnlyBackend {
            fn generate_submission(
                &self,
                _prompt: &BenchmarkPrompt,
            ) -> Result<ProposalSubmission, ProposerError> {
                Ok(ProposalSubmission {
                    raw_output: "raw".to_owned(),
                    proposal_json: "{\"cells\":[],\"ghosts\":[]}".to_owned(),
                })
            }
        }

        let json = SubmissionOnlyBackend
            .generate_json(&BenchmarkPrompt {
                case_id: "case-submission".to_owned(),
                stage: ProposalStage::Initial,
                input: "ignored".to_owned(),
            })
            .expect("default generate_json should use proposal_json");
        assert_eq!(json, "{\"cells\":[],\"ghosts\":[]}");
    }

    #[test]
    fn extract_openai_output_json_reads_message_output_text() {
        let raw = r#"{
            "id": "resp_123",
            "output": [
                {
                    "type": "message",
                    "content": [
                        {
                            "type": "output_text",
                            "text": "{\"cells\":[],\"ghosts\":[]}"
                        }
                    ]
                }
            ]
        }"#;

        let proposal_json =
            extract_openai_output_json(raw).expect("output_text payload should be extracted");
        assert_eq!(proposal_json, "{\"cells\":[],\"ghosts\":[]}");
    }

    #[test]
    fn extract_openai_output_json_surfaces_refusal() {
        let raw = r#"{
            "output": [
                {
                    "type": "message",
                    "content": [
                        {
                            "type": "refusal",
                            "refusal": "I cannot comply."
                        }
                    ]
                }
            ]
        }"#;

        let err =
            extract_openai_output_json(raw).expect_err("refusal should surface as backend error");
        match err {
            ProposerError::Backend(message) => {
                assert!(message.contains("refused"));
                assert!(message.contains("cannot comply"));
            }
            other => panic!("unexpected proposer error: {other:?}"),
        }
    }

    #[test]
    fn openai_backend_request_body_uses_json_schema_format() {
        let backend = OpenAiResponsesBackend::with_base_url(
            "test-key",
            "gpt-5.4-2026-03-05",
            "https://example.invalid/v1/responses",
        )
        .expect("backend should build")
        .with_reasoning_effort("none")
        .with_background(true);
        let body = backend.request_body(&BenchmarkPrompt {
            case_id: "case-openai".to_owned(),
            stage: ProposalStage::Initial,
            input: "input".to_owned(),
        });

        assert_eq!(body["model"], "gpt-5.4-2026-03-05");
        assert_eq!(body["text"]["format"]["type"], "json_schema");
        assert_eq!(body["text"]["format"]["strict"], true);
        assert_eq!(body["text"]["format"]["schema"]["required"][0], "cells");
        assert_eq!(body["reasoning"]["effort"], "none");
        assert_eq!(body["background"], true);
    }
}
