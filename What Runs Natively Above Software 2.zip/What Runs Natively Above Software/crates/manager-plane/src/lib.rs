//! RFC-0005 manager plane: typed non-chat case orchestration.

mod benchmark;
mod proposer;

use constitution_gate::Verdict;
use epistemic_storage::{
    CanonicalCell, CellId, CellKind, CellMeta, CellStatus, ClosureClass, DoubtPolicy,
    EpistemicGraph, EpistemicStateStore, GhostCriticality, GhostId, GhostRecord, GhostStatus,
    JustificationRef, PersistedCaseState, PersistenceError, StatePointer,
};
use proof_federation::AcceptanceReceipt;
use proof_runtime::{
    CaseId, ClosureVerdict, EpistemicAction, StepAction, StepReceipt, closure_guard,
};
use serde::{Deserialize, Serialize};
use serde_json::Error as SerdeJsonError;
use std::collections::{HashMap, VecDeque};
use thiserror::Error;
use worker_abi::{AtomCid, ReceiptCid};

pub use benchmark::{
    BENCHMARK_REPORT_SCHEMA_VERSION, BenchmarkCase, BenchmarkCaseReport, BenchmarkClass,
    BenchmarkDimensionIdentity, BenchmarkError, BenchmarkIoError, BenchmarkMetrics,
    BenchmarkProvActivity, BenchmarkProvBundle, BenchmarkProvEntity, BenchmarkProviderDescriptor,
    BenchmarkReport, BenchmarkResolvedReport, BenchmarkRunIdentity, BenchmarkRunManifest,
    BenchmarkRunTiming, BenchmarkTrackedPaths, BenchmarkVersionLabels, BenchmarkVersionRecord,
    BenchmarkVersionRegistry, VersionedBenchmarkReport, capture_run_timing,
    default_benchmark_run_manifest, default_version_registry_path, load_benchmark_cases,
    load_benchmark_run_manifest, load_benchmark_version_registry, resolve_run_identity,
    run_proposal_benchmark, write_benchmark_report, write_benchmark_version_registry,
    write_versioned_benchmark_report,
};
pub use proposer::{
    BenchmarkPrompt, CommandStructuredJsonBackend, FileStructuredJsonBackend, MockProposer,
    OpenAiResponsesBackend, ProposalStage, ProposalSubmission, Proposer, ProposerError,
    StructuredJsonBackend, StructuredJsonProposer,
};

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct WorkerId(pub String);

impl From<&str> for WorkerId {
    fn from(value: &str) -> Self {
        Self(value.to_owned())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct PointerAlias(pub String);

impl From<&str> for PointerAlias {
    fn from(value: &str) -> Self {
        Self(value.to_owned())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ProposalAdequacy {
    CommitReady,
    RequiresEpistemicResolution,
    Rejected,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ProposalIssueCode {
    UnknownCellKind,
    UnknownCellStatus,
    UnknownDoubtPolicy,
    UnknownClosureClass,
    MissingConclusion,
    DanglingDependency,
    ReferencedGhostSynthesized,
    MissingSupportGhostSynthesized,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProposalIssue {
    pub code: ProposalIssueCode,
    pub cell_id: Option<CellId>,
    pub detail: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProposalNormalizationReport {
    pub graph: EpistemicGraph,
    pub adequacy: ProposalAdequacy,
    pub issues: Vec<ProposalIssue>,
    pub conclusion_cell_ids: Vec<CellId>,
}

#[derive(Debug, Error)]
pub enum ProposalAdapterError {
    #[error("invalid proposal json: {0}")]
    InvalidJson(String),
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct LlmProposalEnvelope {
    cells: Vec<LlmProposalCell>,
    #[serde(default)]
    ghosts: Vec<LlmProposalGhost>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct LlmProposalCell {
    id: String,
    kind: String,
    content: String,
    #[serde(default)]
    status: Option<String>,
    #[serde(default)]
    depends_on: Vec<String>,
    #[serde(default)]
    confirmed_by: Vec<LlmProposalJustification>,
    #[serde(default)]
    if_doubt: Option<String>,
    #[serde(default)]
    created_at: Option<u64>,
    #[serde(default)]
    meta: Option<LlmProposalCellMeta>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct LlmProposalCellMeta {
    #[serde(default)]
    provenance: Vec<String>,
    #[serde(default)]
    closure_class: Option<String>,
    #[serde(default)]
    causal_strength: Option<u8>,
    #[serde(default)]
    contradiction_with: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct LlmProposalGhost {
    id: String,
    reason: String,
    #[serde(default)]
    criticality: Option<String>,
    opened_from: String,
    #[serde(default)]
    required_for: Vec<String>,
    #[serde(default)]
    status: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(untagged)]
enum LlmProposalJustification {
    Anchor { anchor: String },
    Cell { cell: String },
    Ghost { ghost: String },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ManagerInput {
    Event {
        case_id: CaseId,
        event_cid: AtomCid,
    },
    EpistemicReceipt {
        case_id: CaseId,
        receipt: StepReceipt,
    },
    WorkerReceipt {
        case_id: CaseId,
        receipt_cid: ReceiptCid,
    },
    Witness {
        case_id: CaseId,
        witness_cid: String,
    },
    PointerAdvanced {
        case_id: CaseId,
        receipt: AcceptanceReceipt,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ManagerOutput {
    Delegate {
        case_id: CaseId,
        worker_id: WorkerId,
        task_cid: AtomCid,
    },
    AskHumanWitness {
        case_id: CaseId,
        question: String,
    },
    SpawnGhost {
        case_id: CaseId,
        ghost_id: GhostId,
        reason: String,
    },
    ReevaluateEpistemicClosure {
        case_id: CaseId,
        previous_verdict: Verdict,
        graph: EpistemicGraph,
        conclusion_cell_ids: Vec<CellId>,
    },
    AdvancePointer {
        case_id: CaseId,
        head_cid: PointerAlias,
    },
    Terminate {
        case_id: CaseId,
        reason: String,
    },
    Blocked {
        case_id: CaseId,
        reason: BlockReason,
    },
    Idle,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WorkerSelection {
    pub worker_id: WorkerId,
    pub reason: String,
}

pub trait Worker {
    fn id(&self) -> &str;
    fn can_handle(&self, task_kind: &str) -> bool;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ManagedCase {
    pub case_id: CaseId,
    pub state: CaseState,
    pub last_receipt: Option<StepReceipt>,
    pub last_epistemic_verdict: Option<Verdict>,
    #[serde(default)]
    pub pending_output: Option<ManagerOutput>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CaseState {
    WaitingForInput,
    Delegated,
    WaitingForWorker,
    WaitingForWitness,
    ReadyToAdvance,
    Closed,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum BlockReason {
    BudgetExhausted,
    WaitingForForkResolution,
    MissingWitness,
    GhostPending,
    EpistemicReject,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ManagerReceipt {
    Delegated {
        case_id: CaseId,
        worker_id: WorkerId,
    },
    WitnessRequested {
        case_id: CaseId,
    },
    PointerAdvanced {
        case_id: CaseId,
        head_cid: PointerAlias,
    },
    ManagerRejected {
        case_id: CaseId,
        reason: String,
    },
}

#[derive(Debug, Error)]
pub enum ManagerError {
    #[error("case not found: {0}")]
    CaseNotFound(String),
}

#[derive(Debug, Error)]
pub enum ManagerPersistenceError {
    #[error(transparent)]
    Store(#[from] PersistenceError),
    #[error(transparent)]
    Serialization(#[from] SerdeJsonError),
    #[error("case not found for persistence: {0}")]
    CaseNotFound(String),
}

pub trait ManagerPlane {
    fn ingest(&mut self, input: ManagerInput) -> Result<(), ManagerError>;
    fn evaluate_next(&mut self, case_id: &CaseId) -> Result<ManagerOutput, ManagerError>;
}

#[doc = "UNSTABLE_V0"]
pub struct BasicManager {
    cases: HashMap<CaseId, ManagedCase>,
    queue: VecDeque<ManagerInput>,
}

impl BasicManager {
    #[must_use]
    pub fn new() -> Self {
        Self {
            cases: HashMap::new(),
            queue: VecDeque::new(),
        }
    }
}

impl Default for BasicManager {
    fn default() -> Self {
        Self::new()
    }
}

fn remember_output(case: &mut ManagedCase, output: &ManagerOutput) {
    case.pending_output = match output {
        ManagerOutput::Idle => None,
        other => Some(other.clone()),
    };
}

fn parse_kind(raw: &str, issues: &mut Vec<ProposalIssue>, cell_id: &CellId) -> CellKind {
    match raw.to_ascii_lowercase().as_str() {
        "observation" => CellKind::Observation,
        "inference" => CellKind::Inference,
        "conclusion" => CellKind::Conclusion,
        "ghost" => CellKind::Ghost,
        "resolution" => CellKind::Resolution,
        _ => {
            issues.push(ProposalIssue {
                code: ProposalIssueCode::UnknownCellKind,
                cell_id: Some(cell_id.clone()),
                detail: format!("unknown cell kind `{raw}`, defaulted to inference"),
            });
            CellKind::Inference
        }
    }
}

fn parse_status(
    raw: Option<&str>,
    default: CellStatus,
    issues: &mut Vec<ProposalIssue>,
    cell_id: &CellId,
) -> CellStatus {
    match raw.map(str::to_ascii_lowercase).as_deref() {
        None => default,
        Some("ok") | Some("supported") | Some("committed") => CellStatus::Ok,
        Some("doubt") | Some("proposed") | Some("blocked") => CellStatus::Doubt,
        Some("not") => CellStatus::Not,
        Some(other) => {
            issues.push(ProposalIssue {
                code: ProposalIssueCode::UnknownCellStatus,
                cell_id: Some(cell_id.clone()),
                detail: format!("unknown cell status `{other}`, default applied"),
            });
            default
        }
    }
}

fn parse_doubt_policy(
    raw: Option<&str>,
    default: DoubtPolicy,
    issues: &mut Vec<ProposalIssue>,
    cell_id: &CellId,
) -> DoubtPolicy {
    match raw.map(str::to_ascii_lowercase).as_deref() {
        None => default,
        Some("spawnghost") | Some("spawn_ghost") | Some("spawn-ghost") => DoubtPolicy::SpawnGhost,
        Some("askwitness") | Some("ask_witness") | Some("ask-witness") => DoubtPolicy::AskWitness,
        Some("escalate") | Some("block") => DoubtPolicy::Escalate,
        Some(other) => {
            issues.push(ProposalIssue {
                code: ProposalIssueCode::UnknownDoubtPolicy,
                cell_id: Some(cell_id.clone()),
                detail: format!("unknown doubt policy `{other}`, default applied"),
            });
            default
        }
    }
}

fn parse_closure_class(
    raw: Option<&str>,
    default: ClosureClass,
    issues: &mut Vec<ProposalIssue>,
    cell_id: &CellId,
) -> ClosureClass {
    match raw.map(str::to_ascii_lowercase).as_deref() {
        None => default,
        Some("provisional") => ClosureClass::Provisional,
        Some("conditional") | Some("fraudulent") => ClosureClass::Conditional,
        Some("final") | Some("stable") => ClosureClass::Final,
        Some(other) => {
            issues.push(ProposalIssue {
                code: ProposalIssueCode::UnknownClosureClass,
                cell_id: Some(cell_id.clone()),
                detail: format!("unknown closure class `{other}`, default applied"),
            });
            default
        }
    }
}

fn parse_ghost_criticality(raw: Option<&str>) -> GhostCriticality {
    match raw.map(str::to_ascii_lowercase).as_deref() {
        Some("low") => GhostCriticality::Low,
        Some("medium") => GhostCriticality::Medium,
        _ => GhostCriticality::High,
    }
}

fn parse_ghost_status(raw: Option<&str>) -> GhostStatus {
    match raw.map(str::to_ascii_lowercase).as_deref() {
        Some("resolved") => GhostStatus::Resolved,
        Some("waived") => GhostStatus::Waived,
        _ => GhostStatus::Open,
    }
}

pub fn adapt_llm_proposal_json(
    raw: &str,
) -> Result<ProposalNormalizationReport, ProposalAdapterError> {
    let envelope: LlmProposalEnvelope = serde_json::from_str(raw)
        .map_err(|err: SerdeJsonError| ProposalAdapterError::InvalidJson(err.to_string()))?;

    let mut graph = EpistemicGraph::new();
    let mut issues = Vec::new();

    for ghost in envelope.ghosts {
        graph.insert_ghost(GhostRecord {
            id: GhostId(ghost.id),
            reason: ghost.reason,
            criticality: parse_ghost_criticality(ghost.criticality.as_deref()),
            opened_from: CellId(ghost.opened_from),
            required_for: ghost.required_for.into_iter().map(CellId).collect(),
            status: parse_ghost_status(ghost.status.as_deref()),
            resolution_ref: None,
        });
    }

    for (index, cell) in envelope.cells.into_iter().enumerate() {
        let cell_id = CellId(cell.id);
        let kind = parse_kind(&cell.kind, &mut issues, &cell_id);
        let default_status = match kind {
            CellKind::Observation | CellKind::Resolution => CellStatus::Ok,
            CellKind::Inference | CellKind::Conclusion | CellKind::Ghost => CellStatus::Doubt,
        };
        let status = parse_status(
            cell.status.as_deref(),
            default_status,
            &mut issues,
            &cell_id,
        );
        let default_policy = match kind {
            CellKind::Observation | CellKind::Resolution => DoubtPolicy::AskWitness,
            CellKind::Inference | CellKind::Conclusion | CellKind::Ghost => DoubtPolicy::SpawnGhost,
        };
        let if_doubt = parse_doubt_policy(
            cell.if_doubt.as_deref(),
            default_policy,
            &mut issues,
            &cell_id,
        );
        let default_closure = match kind {
            CellKind::Observation => ClosureClass::Provisional,
            CellKind::Inference | CellKind::Resolution | CellKind::Ghost => {
                ClosureClass::Conditional
            }
            CellKind::Conclusion => ClosureClass::Final,
        };
        let meta = cell.meta.unwrap_or(LlmProposalCellMeta {
            provenance: Vec::new(),
            closure_class: None,
            causal_strength: None,
            contradiction_with: Vec::new(),
        });
        let confirmed_by = cell
            .confirmed_by
            .into_iter()
            .map(|justification| match justification {
                LlmProposalJustification::Anchor { anchor } => JustificationRef::Anchor(anchor),
                LlmProposalJustification::Cell { cell } => JustificationRef::Cell(CellId(cell)),
                LlmProposalJustification::Ghost { ghost } => {
                    JustificationRef::Ghost(GhostId(ghost))
                }
            })
            .collect();

        graph.insert_cell(CanonicalCell {
            id: cell_id.clone(),
            kind,
            content: cell.content,
            status,
            depends_on: cell.depends_on.into_iter().map(CellId).collect(),
            confirmed_by,
            if_doubt,
            created_at: cell.created_at.unwrap_or((index as u64) + 1),
            meta: CellMeta {
                provenance: meta.provenance,
                closure_class: parse_closure_class(
                    meta.closure_class.as_deref(),
                    default_closure,
                    &mut issues,
                    &cell_id,
                ),
                causal_strength: meta.causal_strength.unwrap_or(0),
                contradiction_with: meta.contradiction_with.into_iter().map(CellId).collect(),
            },
        });
    }

    let cell_ids: Vec<_> = graph.cells.keys().cloned().collect();
    for cell_id in &cell_ids {
        let Some(cell) = graph.cell(cell_id).cloned() else {
            continue;
        };
        for dependency in &cell.depends_on {
            if graph.cell(dependency).is_none() {
                issues.push(ProposalIssue {
                    code: ProposalIssueCode::DanglingDependency,
                    cell_id: Some(cell_id.clone()),
                    detail: format!("dependency `{}` not found in proposal graph", dependency.0),
                });
            }
        }
        let referenced_ghost_ids: Vec<_> = cell
            .confirmed_by
            .iter()
            .filter_map(|justification| match justification {
                JustificationRef::Ghost(ghost_id) => Some(ghost_id.clone()),
                _ => None,
            })
            .collect();
        for ghost_id in referenced_ghost_ids {
            if graph.ghost(&ghost_id).is_none() {
                issues.push(ProposalIssue {
                    code: ProposalIssueCode::ReferencedGhostSynthesized,
                    cell_id: Some(cell_id.clone()),
                    detail: format!("ghost `{}` was referenced but not defined", ghost_id.0),
                });
                graph.insert_ghost(GhostRecord {
                    id: ghost_id.clone(),
                    reason: format!(
                        "referenced ghost missing from proposal for {}",
                        cell.content
                    ),
                    criticality: GhostCriticality::High,
                    opened_from: cell_id.clone(),
                    required_for: graph
                        .dependents_of(cell_id)
                        .into_iter()
                        .map(|dependent| dependent.id.clone())
                        .chain(std::iter::once(cell_id.clone()))
                        .collect(),
                    status: GhostStatus::Open,
                    resolution_ref: None,
                });
            }
        }

        let has_support = cell.confirmed_by.iter().any(|justification| {
            matches!(
                justification,
                JustificationRef::Anchor(_) | JustificationRef::Cell(_)
            )
        });
        if matches!(cell.kind, CellKind::Inference | CellKind::Conclusion)
            && cell.if_doubt == DoubtPolicy::SpawnGhost
            && !has_support
            && !graph.has_open_ghost_for(cell_id)
        {
            let ghost_id = GhostId(format!("ghost:auto:{}", cell_id.0));
            issues.push(ProposalIssue {
                code: ProposalIssueCode::MissingSupportGhostSynthesized,
                cell_id: Some(cell_id.clone()),
                detail: format!(
                    "synthetic ghost created for unsupported cell `{}`",
                    cell_id.0
                ),
            });
            graph.insert_ghost(GhostRecord {
                id: ghost_id.clone(),
                reason: format!("missing support for {}", cell.content),
                criticality: GhostCriticality::High,
                opened_from: cell_id.clone(),
                required_for: graph
                    .dependents_of(cell_id)
                    .into_iter()
                    .map(|dependent| dependent.id.clone())
                    .chain(std::iter::once(cell_id.clone()))
                    .collect(),
                status: GhostStatus::Open,
                resolution_ref: None,
            });
            if let Some(updated_cell) = graph.cells.get_mut(cell_id) {
                updated_cell
                    .confirmed_by
                    .push(JustificationRef::Ghost(ghost_id));
            }
        }
    }

    let conclusion_cell_ids: Vec<_> = graph
        .cells
        .values()
        .filter(|cell| cell.kind == CellKind::Conclusion)
        .map(|cell| cell.id.clone())
        .collect();
    if conclusion_cell_ids.is_empty() {
        issues.push(ProposalIssue {
            code: ProposalIssueCode::MissingConclusion,
            cell_id: None,
            detail: "proposal produced no conclusion cells".to_owned(),
        });
    }

    let adequacy = if conclusion_cell_ids.is_empty() {
        ProposalAdequacy::Rejected
    } else {
        let verdicts: Vec<_> = conclusion_cell_ids
            .iter()
            .map(|cell_id| closure_guard(cell_id, &graph))
            .collect();
        if verdicts
            .iter()
            .any(|verdict| matches!(verdict, ClosureVerdict::Reject { .. }))
        {
            ProposalAdequacy::Rejected
        } else if verdicts
            .iter()
            .any(|verdict| matches!(verdict, ClosureVerdict::Ghost { .. }))
        {
            ProposalAdequacy::RequiresEpistemicResolution
        } else {
            ProposalAdequacy::CommitReady
        }
    };

    Ok(ProposalNormalizationReport {
        graph,
        adequacy,
        issues,
        conclusion_cell_ids,
    })
}

impl ManagerOutput {
    #[must_use]
    pub fn runtime_actions(&self) -> Option<Vec<StepAction>> {
        match self {
            Self::ReevaluateEpistemicClosure {
                previous_verdict,
                graph,
                conclusion_cell_ids,
                ..
            } => Some(
                conclusion_cell_ids
                    .iter()
                    .cloned()
                    .map(|conclusion_cell_id| {
                        StepAction::Epistemic(EpistemicAction::ReassessClosure {
                            conclusion_cell_id,
                            previous_verdict: *previous_verdict,
                            graph: graph.clone(),
                        })
                    })
                    .collect(),
            ),
            _ => None,
        }
    }
}

fn spawn_ghost_from_doubt(
    case_id: &CaseId,
    graph: &mut EpistemicGraph,
    cell_id: &CellId,
) -> Option<GhostRecord> {
    let cell = graph.cell(cell_id)?.clone();
    if cell.status != CellStatus::Doubt || cell.if_doubt != DoubtPolicy::SpawnGhost {
        return None;
    }
    if graph.has_open_ghost_for(cell_id) {
        return None;
    }

    let ghost = GhostRecord {
        id: GhostId(format!("ghost:{}:{}", case_id.0, cell_id.0)),
        reason: format!("doubt activated for {}", cell.content),
        criticality: GhostCriticality::High,
        opened_from: cell_id.clone(),
        required_for: graph
            .dependents_of(cell_id)
            .into_iter()
            .map(|dependent| dependent.id.clone())
            .collect(),
        status: GhostStatus::Open,
        resolution_ref: None,
    };
    graph.insert_ghost(ghost.clone());
    Some(ghost)
}

impl ManagerPlane for BasicManager {
    fn ingest(&mut self, input: ManagerInput) -> Result<(), ManagerError> {
        match &input {
            ManagerInput::Event { case_id, .. }
            | ManagerInput::EpistemicReceipt { case_id, .. }
            | ManagerInput::WorkerReceipt { case_id, .. }
            | ManagerInput::Witness { case_id, .. }
            | ManagerInput::PointerAdvanced { case_id, .. } => {
                let case = self.cases.entry(case_id.clone()).or_insert(ManagedCase {
                    case_id: case_id.clone(),
                    state: CaseState::WaitingForInput,
                    last_receipt: None,
                    last_epistemic_verdict: None,
                    pending_output: None,
                });
                case.pending_output = None;
            }
        }
        self.queue.push_back(input);
        Ok(())
    }

    fn evaluate_next(&mut self, case_id: &CaseId) -> Result<ManagerOutput, ManagerError> {
        let Some(case) = self.cases.get_mut(case_id) else {
            return Err(ManagerError::CaseNotFound(case_id.0.clone()));
        };

        while let Some(input) = self.queue.pop_front() {
            match input {
                ManagerInput::Event {
                    case_id: incoming_case,
                    event_cid,
                } if &incoming_case == case_id => {
                    case.state = CaseState::WaitingForWorker;
                    let output = ManagerOutput::Delegate {
                        case_id: incoming_case,
                        worker_id: WorkerId::from("worker.default"),
                        task_cid: event_cid,
                    };
                    remember_output(case, &output);
                    return Ok(output);
                }
                ManagerInput::WorkerReceipt {
                    case_id: incoming_case,
                    receipt_cid: _,
                } if &incoming_case == case_id => {
                    case.state = CaseState::ReadyToAdvance;
                    let output = ManagerOutput::AdvancePointer {
                        case_id: incoming_case,
                        head_cid: PointerAlias::from("head:next"),
                    };
                    remember_output(case, &output);
                    return Ok(output);
                }
                ManagerInput::EpistemicReceipt {
                    case_id: incoming_case,
                    receipt,
                } if &incoming_case == case_id => {
                    case.last_receipt = Some(receipt.clone());
                    match receipt {
                        StepReceipt::EpistemicClosureTransition {
                            conclusion_cell_id,
                            to_verdict,
                            ..
                        } => match to_verdict {
                            Verdict::Commit => {
                                case.last_epistemic_verdict = Some(Verdict::Commit);
                                case.state = CaseState::ReadyToAdvance;
                                let output = ManagerOutput::AdvancePointer {
                                    case_id: incoming_case,
                                    head_cid: PointerAlias(format!(
                                        "closure:{}",
                                        conclusion_cell_id.0
                                    )),
                                };
                                remember_output(case, &output);
                                return Ok(output);
                            }
                            Verdict::Ghost => {
                                case.last_epistemic_verdict = Some(Verdict::Ghost);
                                case.state = CaseState::WaitingForWitness;
                                let output = ManagerOutput::Blocked {
                                    case_id: incoming_case,
                                    reason: BlockReason::GhostPending,
                                };
                                remember_output(case, &output);
                                return Ok(output);
                            }
                            Verdict::Reject => {
                                case.last_epistemic_verdict = Some(Verdict::Reject);
                                case.state = CaseState::WaitingForWitness;
                                let output = ManagerOutput::Blocked {
                                    case_id: incoming_case,
                                    reason: BlockReason::EpistemicReject,
                                };
                                remember_output(case, &output);
                                return Ok(output);
                            }
                        },
                        StepReceipt::EpistemicClosureEvaluated {
                            constitutional_verdict,
                            ..
                        } => {
                            case.last_epistemic_verdict = Some(constitutional_verdict);
                            case.state = match constitutional_verdict {
                                Verdict::Commit => CaseState::WaitingForWorker,
                                Verdict::Ghost | Verdict::Reject => CaseState::WaitingForWitness,
                            };
                            case.pending_output = None;
                            return Ok(ManagerOutput::Idle);
                        }
                        StepReceipt::GhostResolved {
                            required_for,
                            graph,
                            ..
                        } => {
                            case.state = CaseState::WaitingForWorker;
                            let output = ManagerOutput::ReevaluateEpistemicClosure {
                                case_id: incoming_case,
                                previous_verdict: case
                                    .last_epistemic_verdict
                                    .unwrap_or(Verdict::Ghost),
                                graph,
                                conclusion_cell_ids: required_for,
                            };
                            remember_output(case, &output);
                            return Ok(output);
                        }
                        _ => {}
                    }
                }
                ManagerInput::Witness {
                    case_id: incoming_case,
                    witness_cid: _,
                } if &incoming_case == case_id => {
                    case.state = CaseState::ReadyToAdvance;
                    let output = ManagerOutput::AdvancePointer {
                        case_id: incoming_case,
                        head_cid: PointerAlias::from("head:witness"),
                    };
                    remember_output(case, &output);
                    return Ok(output);
                }
                ManagerInput::PointerAdvanced {
                    case_id: incoming_case,
                    receipt: _,
                } if &incoming_case == case_id => {
                    case.state = CaseState::Closed;
                    let output = ManagerOutput::Terminate {
                        case_id: incoming_case,
                        reason: "pointer advanced".to_owned(),
                    };
                    remember_output(case, &output);
                    return Ok(output);
                }
                _ => {}
            }
        }
        case.pending_output = None;
        Ok(ManagerOutput::Idle)
    }
}

impl BasicManager {
    pub fn evaluate_epistemic_closure(
        &mut self,
        case_id: &CaseId,
        graph: &mut EpistemicGraph,
        conclusion_id: &CellId,
    ) -> Result<ManagerOutput, ManagerError> {
        let Some(case) = self.cases.get_mut(case_id) else {
            return Err(ManagerError::CaseNotFound(case_id.0.clone()));
        };

        if let Some(ghost) = spawn_ghost_from_doubt(case_id, graph, conclusion_id) {
            case.state = CaseState::WaitingForWitness;
            let output = ManagerOutput::SpawnGhost {
                case_id: case_id.to_owned(),
                ghost_id: ghost.id,
                reason: ghost.reason,
            };
            remember_output(case, &output);
            return Ok(output);
        }

        match closure_guard(conclusion_id, graph) {
            ClosureVerdict::Commit { .. } => {
                case.state = CaseState::ReadyToAdvance;
                let output = ManagerOutput::AdvancePointer {
                    case_id: case_id.to_owned(),
                    head_cid: PointerAlias(format!("closure:{}", conclusion_id.0)),
                };
                remember_output(case, &output);
                Ok(output)
            }
            ClosureVerdict::Ghost { .. } => {
                case.state = CaseState::WaitingForWitness;
                let output = ManagerOutput::Blocked {
                    case_id: case_id.to_owned(),
                    reason: BlockReason::GhostPending,
                };
                remember_output(case, &output);
                Ok(output)
            }
            ClosureVerdict::Reject { .. } => {
                case.state = CaseState::WaitingForWitness;
                let output = ManagerOutput::Blocked {
                    case_id: case_id.to_owned(),
                    reason: BlockReason::EpistemicReject,
                };
                remember_output(case, &output);
                Ok(output)
            }
        }
    }

    pub fn persist_case_state<S: EpistemicStateStore>(
        &self,
        store: &S,
        case_id: &CaseId,
        pointers: Vec<StatePointer>,
        graph_version: Option<u64>,
        session_json: Option<String>,
        updated_at: u64,
    ) -> Result<PersistedCaseState, ManagerPersistenceError> {
        let Some(case) = self.cases.get(case_id) else {
            return Err(ManagerPersistenceError::CaseNotFound(case_id.0.clone()));
        };
        let existing_state = store.load_case_state(&case_id.0)?;
        let preserved_session_json = session_json.or_else(|| {
            existing_state
                .as_ref()
                .and_then(|state| state.session_json.clone())
        });
        let preserved_graph_version = graph_version.or_else(|| {
            existing_state
                .as_ref()
                .and_then(|state| state.graph_version)
        });
        let preserved_pointers = if pointers.is_empty() {
            existing_state
                .as_ref()
                .map(|state| state.pointers.clone())
                .unwrap_or_default()
        } else {
            pointers
        };

        let state = PersistedCaseState {
            case_id: case_id.0.clone(),
            pointers: preserved_pointers,
            graph_version: preserved_graph_version,
            session_json: preserved_session_json,
            manager_state_json: Some(serde_json::to_string(case)?),
            state_hash: String::new(),
            updated_at,
        };
        store.save_case_state(&state)?;
        Ok(state)
    }

    pub fn rehydrate_case_state<S: EpistemicStateStore>(
        &mut self,
        store: &S,
        case_id: &CaseId,
    ) -> Result<Option<PersistedCaseState>, ManagerPersistenceError> {
        let Some(state) = store.load_case_state(&case_id.0)? else {
            return Ok(None);
        };

        if let Some(manager_state_json) = &state.manager_state_json {
            let case: ManagedCase = serde_json::from_str(manager_state_json)?;
            self.cases.insert(case.case_id.clone(), case);
        }

        Ok(Some(state))
    }

    pub fn resume_case(&self, case_id: &CaseId) -> Result<ManagerOutput, ManagerError> {
        let Some(case) = self.cases.get(case_id) else {
            return Err(ManagerError::CaseNotFound(case_id.0.clone()));
        };

        if let Some(output) = &case.pending_output {
            return Ok(output.clone());
        }

        let output = match case.state {
            CaseState::WaitingForWitness => match case.last_epistemic_verdict {
                Some(Verdict::Ghost) => ManagerOutput::Blocked {
                    case_id: case_id.clone(),
                    reason: BlockReason::GhostPending,
                },
                Some(Verdict::Reject) => ManagerOutput::Blocked {
                    case_id: case_id.clone(),
                    reason: BlockReason::EpistemicReject,
                },
                _ => ManagerOutput::Idle,
            },
            _ => ManagerOutput::Idle,
        };
        Ok(output)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use constitution_gate::Verdict;
    use epistemic_storage::{
        AtomCid as StorageAtomCid, CanonicalCell, CellKind, CellMeta, ClosureClass,
        JustificationRef, SqliteEpistemicStore, StatePointer,
    };
    use std::fs;

    #[test]
    fn adapter_normalizes_supported_proposal_as_commit_ready() {
        let report = adapt_llm_proposal_json(
            r#"{
                "cells": [
                    {
                        "id": "obs",
                        "kind": "Observation",
                        "content": "invoice exists",
                        "confirmed_by": [{"anchor": "sensor:invoice"}]
                    },
                    {
                        "id": "conclusion",
                        "kind": "Conclusion",
                        "content": "transaction verified",
                        "depends_on": ["obs"],
                        "confirmed_by": [{"cell": "obs"}],
                        "if_doubt": "SpawnGhost"
                    }
                ]
            }"#,
        )
        .expect("proposal should parse");

        assert_eq!(report.adequacy, ProposalAdequacy::CommitReady);
        assert_eq!(report.conclusion_cell_ids, vec![CellId::from("conclusion")]);
        assert!(report.issues.is_empty());
    }

    #[test]
    fn adapter_synthesizes_ghost_for_unsupported_inference() {
        let report = adapt_llm_proposal_json(
            r#"{
                "cells": [
                    {
                        "id": "obs",
                        "kind": "Observation",
                        "content": "invoice exists",
                        "confirmed_by": [{"anchor": "sensor:invoice"}]
                    },
                    {
                        "id": "infer",
                        "kind": "Inference",
                        "content": "payment received",
                        "depends_on": ["obs"],
                        "if_doubt": "SpawnGhost",
                        "meta": {"causal_strength": 85, "closure_class": "Conditional"}
                    },
                    {
                        "id": "conclusion",
                        "kind": "Conclusion",
                        "content": "transaction verified",
                        "depends_on": ["infer"],
                        "confirmed_by": [{"cell": "infer"}],
                        "if_doubt": "SpawnGhost"
                    }
                ]
            }"#,
        )
        .expect("proposal should parse");

        assert_eq!(
            report.adequacy,
            ProposalAdequacy::RequiresEpistemicResolution
        );
        assert!(report.graph.has_open_ghost_for(&CellId::from("infer")));
        assert!(report.issues.iter().any(|issue| {
            issue.code == ProposalIssueCode::MissingSupportGhostSynthesized
                && issue.cell_id == Some(CellId::from("infer"))
        }));
    }

    #[test]
    fn adapter_rejects_invalid_json() {
        let err = adapt_llm_proposal_json("{not json").expect_err("json must be validated");
        assert!(matches!(err, ProposalAdapterError::InvalidJson(_)));
    }

    #[test]
    fn mock_proposer_returns_auditable_raw_output() {
        let proposer = MockProposer::new().with_submission(
            "case-a",
            ProposalStage::Initial,
            ProposalSubmission {
                raw_output: "{\"raw\":\"model-output\"}".to_owned(),
                proposal_json: "{\"cells\":[]}".to_owned(),
            },
        );

        let submission = proposer
            .propose(&BenchmarkPrompt {
                case_id: "case-a".to_owned(),
                stage: ProposalStage::Initial,
                input: "prompt".to_owned(),
            })
            .expect("mock proposer should return configured output");
        assert_eq!(submission.raw_output, "{\"raw\":\"model-output\"}");
        assert_eq!(submission.proposal_json, "{\"cells\":[]}");
    }

    struct DummyStructuredBackend;

    impl StructuredJsonBackend for DummyStructuredBackend {
        fn generate_submission(
            &self,
            prompt: &BenchmarkPrompt,
        ) -> Result<ProposalSubmission, ProposerError> {
            let proposal_json = format!(
                "{{\"cells\":[{{\"id\":\"{}\",\"kind\":\"Conclusion\",\"content\":\"{}\"}}],\"ghosts\":[]}}",
                prompt.case_id, prompt.input
            );
            Ok(ProposalSubmission {
                raw_output: proposal_json.clone(),
                proposal_json,
            })
        }
    }

    #[test]
    fn structured_json_proposer_preserves_strict_json_boundary() {
        let proposer = StructuredJsonProposer::new(DummyStructuredBackend);
        let submission = proposer
            .propose(&BenchmarkPrompt {
                case_id: "case-json".to_owned(),
                stage: ProposalStage::Initial,
                input: "structured".to_owned(),
            })
            .expect("backend should produce json");
        assert_eq!(submission.raw_output, submission.proposal_json);
        assert!(submission.proposal_json.contains("\"cells\""));
    }

    #[test]
    fn benchmark_harness_classifies_a_through_d_cases() {
        let proposer = MockProposer::new()
            .with_submission(
                "class-a",
                ProposalStage::Initial,
                ProposalSubmission {
                    raw_output: "class-a initial".to_owned(),
                    proposal_json: r#"{
                        "cells": [
                            {
                                "id": "obs",
                                "kind": "Observation",
                                "content": "invoice exists",
                                "confirmed_by": [{"anchor": "sensor:invoice"}]
                            },
                            {
                                "id": "conclusion",
                                "kind": "Conclusion",
                                "content": "transaction verified",
                                "depends_on": ["obs"],
                                "confirmed_by": [{"cell": "obs"}],
                                "if_doubt": "SpawnGhost"
                            }
                        ]
                    }"#
                    .to_owned(),
                },
            )
            .with_submission(
                "class-b",
                ProposalStage::Initial,
                ProposalSubmission {
                    raw_output: "class-b initial".to_owned(),
                    proposal_json: r#"{
                        "cells": [
                            {
                                "id": "obs",
                                "kind": "Observation",
                                "content": "invoice exists",
                                "confirmed_by": [{"anchor": "sensor:invoice"}]
                            },
                            {
                                "id": "infer",
                                "kind": "Inference",
                                "content": "payment received",
                                "depends_on": ["obs"],
                                "if_doubt": "SpawnGhost",
                                "meta": {"causal_strength": 85, "closure_class": "Conditional"}
                            },
                            {
                                "id": "conclusion",
                                "kind": "Conclusion",
                                "content": "transaction verified",
                                "depends_on": ["infer"],
                                "confirmed_by": [{"cell": "infer"}],
                                "if_doubt": "SpawnGhost"
                            }
                        ]
                    }"#
                    .to_owned(),
                },
            )
            .with_submission(
                "class-c",
                ProposalStage::Initial,
                ProposalSubmission {
                    raw_output: "class-c initial".to_owned(),
                    proposal_json: r#"{
                        "cells": [
                            {
                                "id": "conclusion",
                                "kind": "Conclusion",
                                "content": "transaction verified",
                                "if_doubt": "AskWitness"
                            }
                        ]
                    }"#
                    .to_owned(),
                },
            )
            .with_submission(
                "class-d",
                ProposalStage::Initial,
                ProposalSubmission {
                    raw_output: "class-d initial".to_owned(),
                    proposal_json: r#"{
                        "cells": [
                            {
                                "id": "obs",
                                "kind": "Observation",
                                "content": "invoice exists",
                                "confirmed_by": [{"anchor": "sensor:invoice"}]
                            },
                            {
                                "id": "infer",
                                "kind": "Inference",
                                "content": "payment received",
                                "depends_on": ["obs"],
                                "if_doubt": "SpawnGhost",
                                "meta": {"causal_strength": 85, "closure_class": "Conditional"}
                            },
                            {
                                "id": "conclusion",
                                "kind": "Conclusion",
                                "content": "transaction verified",
                                "depends_on": ["infer"],
                                "confirmed_by": [{"cell": "infer"}],
                                "if_doubt": "SpawnGhost"
                            }
                        ]
                    }"#
                    .to_owned(),
                },
            )
            .with_submission(
                "class-d",
                ProposalStage::Resolution,
                ProposalSubmission {
                    raw_output: "class-d resolution".to_owned(),
                    proposal_json: r#"{
                        "cells": [
                            {
                                "id": "obs",
                                "kind": "Observation",
                                "content": "invoice exists",
                                "confirmed_by": [{"anchor": "sensor:invoice"}]
                            },
                            {
                                "id": "resolution:infer",
                                "kind": "Resolution",
                                "content": "bank statement confirms payment",
                                "confirmed_by": [{"anchor": "witness:bank_statement"}]
                            },
                            {
                                "id": "infer",
                                "kind": "Inference",
                                "content": "payment received",
                                "depends_on": ["obs"],
                                "confirmed_by": [{"cell": "resolution:infer"}],
                                "if_doubt": "SpawnGhost",
                                "meta": {"causal_strength": 85, "closure_class": "Conditional"}
                            },
                            {
                                "id": "conclusion",
                                "kind": "Conclusion",
                                "content": "transaction verified",
                                "depends_on": ["infer"],
                                "confirmed_by": [{"cell": "infer"}],
                                "if_doubt": "SpawnGhost"
                            }
                        ]
                    }"#
                    .to_owned(),
                },
            );

        let report = run_proposal_benchmark(
            &proposer,
            &[
                BenchmarkCase {
                    id: "class-a".to_owned(),
                    class: BenchmarkClass::AnchoredClosure,
                    initial_input: "anchored closure prompt".to_owned(),
                    expected_initial: ProposalAdequacy::CommitReady,
                    resolution_input: None,
                    expected_resolved: None,
                },
                BenchmarkCase {
                    id: "class-b".to_owned(),
                    class: BenchmarkClass::HonestInsufficiency,
                    initial_input: "honest insufficiency prompt".to_owned(),
                    expected_initial: ProposalAdequacy::RequiresEpistemicResolution,
                    resolution_input: None,
                    expected_resolved: None,
                },
                BenchmarkCase {
                    id: "class-c".to_owned(),
                    class: BenchmarkClass::IllegitimateClosure,
                    initial_input: "illegitimate closure prompt".to_owned(),
                    expected_initial: ProposalAdequacy::Rejected,
                    resolution_input: None,
                    expected_resolved: None,
                },
                BenchmarkCase {
                    id: "class-d".to_owned(),
                    class: BenchmarkClass::PostResolutionRecovery,
                    initial_input: "post-resolution recovery prompt".to_owned(),
                    expected_initial: ProposalAdequacy::RequiresEpistemicResolution,
                    resolution_input: Some("resolution prompt".to_owned()),
                    expected_resolved: Some(ProposalAdequacy::CommitReady),
                },
            ],
        )
        .expect("benchmark should run");

        assert_eq!(report.metrics.total_cases, 4);
        assert_eq!(report.metrics.correct_commit_count, 1);
        assert_eq!(report.metrics.correct_ghost_count, 2);
        assert_eq!(report.metrics.correct_reject_count, 1);
        assert_eq!(report.metrics.false_commit_count, 0);
        assert_eq!(report.metrics.false_ghost_count, 0);
        assert_eq!(report.metrics.false_reject_count, 0);
        assert_eq!(report.metrics.transition_correct_count, 1);
        assert_eq!(report.metrics.resolution_to_commit_lift_count, 1);
        assert!(report.metrics.ghost_utility_rate_bp > 0);
        assert_eq!(report.cases[0].initial_raw_output, "class-a initial");
        assert_eq!(
            report.cases[3]
                .resolved
                .as_ref()
                .expect("resolution report should exist")
                .raw_output,
            "class-d resolution"
        );
    }

    #[test]
    fn manager_operates_in_typed_non_chat_flow() {
        let mut manager = BasicManager::new();
        manager
            .ingest(ManagerInput::Event {
                case_id: CaseId::from("c1"),
                event_cid: AtomCid("task:1".to_owned()),
            })
            .expect("ingest should work");
        let out1 = manager
            .evaluate_next(&CaseId::from("c1"))
            .expect("evaluation should work");
        assert!(matches!(out1, ManagerOutput::Delegate { .. }));
    }

    #[test]
    fn manager_rejects_unknown_case_lookup() {
        let mut manager = BasicManager::new();
        let err = manager
            .evaluate_next(&CaseId::from("missing"))
            .expect_err("unknown case must fail");
        assert!(matches!(err, ManagerError::CaseNotFound(_)));
    }

    #[test]
    fn manager_spawns_ghost_when_doubt_requires_it() {
        let mut manager = BasicManager::new();
        manager
            .ingest(ManagerInput::Event {
                case_id: CaseId::from("case-epistemic"),
                event_cid: AtomCid("task:1".to_owned()),
            })
            .expect("ingest should work");

        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "close only if paid".to_owned(),
            status: CellStatus::Doubt,
            depends_on: Vec::new(),
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 1,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        let out = manager
            .evaluate_epistemic_closure(
                &CaseId::from("case-epistemic"),
                &mut graph,
                &CellId::from("conclusion"),
            )
            .expect("epistemic closure should evaluate");
        assert!(matches!(out, ManagerOutput::SpawnGhost { .. }));
        assert!(graph.has_open_ghost_for(&CellId::from("conclusion")));
    }

    #[test]
    fn manager_blocks_hallucinated_closure() {
        let mut manager = BasicManager::new();
        manager
            .ingest(ManagerInput::Event {
                case_id: CaseId::from("case-hallucination"),
                event_cid: AtomCid("task:2".to_owned()),
            })
            .expect("ingest should work");

        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("anchor:invoice".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "payment happened".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 90,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        let out = manager
            .evaluate_epistemic_closure(
                &CaseId::from("case-hallucination"),
                &mut graph,
                &CellId::from("conclusion"),
            )
            .expect("epistemic closure should evaluate");
        assert!(matches!(
            out,
            ManagerOutput::Blocked {
                reason: BlockReason::EpistemicReject,
                ..
            }
        ));
    }

    #[test]
    fn manager_does_not_advance_on_closure_evaluation_alone() {
        let mut manager = BasicManager::new();
        manager
            .ingest(ManagerInput::EpistemicReceipt {
                case_id: CaseId::from("case-eval"),
                receipt: StepReceipt::EpistemicClosureEvaluated {
                    conclusion_cell_id: CellId::from("conclusion"),
                    grounding_ratio_bp: 8_000,
                    constitutional_verdict: Verdict::Commit,
                    pending_ghosts: Vec::new(),
                    reasons: Vec::new(),
                },
            })
            .expect("ingest should work");

        let out = manager
            .evaluate_next(&CaseId::from("case-eval"))
            .expect("evaluation should work");
        assert!(matches!(out, ManagerOutput::Idle));
    }

    #[test]
    fn manager_advances_only_on_commit_transition() {
        let mut manager = BasicManager::new();
        manager
            .ingest(ManagerInput::EpistemicReceipt {
                case_id: CaseId::from("case-transition"),
                receipt: StepReceipt::EpistemicClosureTransition {
                    conclusion_cell_id: CellId::from("conclusion"),
                    from_verdict: Verdict::Ghost,
                    to_verdict: Verdict::Commit,
                    grounding_ratio_bp: 8_500,
                },
            })
            .expect("ingest should work");

        let out = manager
            .evaluate_next(&CaseId::from("case-transition"))
            .expect("evaluation should work");
        assert!(matches!(out, ManagerOutput::AdvancePointer { .. }));
    }

    #[test]
    fn manager_blocks_on_non_commit_transition() {
        let mut manager = BasicManager::new();
        manager
            .ingest(ManagerInput::EpistemicReceipt {
                case_id: CaseId::from("case-transition-ghost"),
                receipt: StepReceipt::EpistemicClosureTransition {
                    conclusion_cell_id: CellId::from("conclusion"),
                    from_verdict: Verdict::Ghost,
                    to_verdict: Verdict::Ghost,
                    grounding_ratio_bp: 3_000,
                },
            })
            .expect("ingest should work");

        let out = manager
            .evaluate_next(&CaseId::from("case-transition-ghost"))
            .expect("evaluation should work");
        assert!(matches!(
            out,
            ManagerOutput::Blocked {
                reason: BlockReason::GhostPending,
                ..
            }
        ));
    }

    #[test]
    fn manager_auto_reactivates_after_ghost_resolution() {
        let mut manager = BasicManager::new();
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Cell(CellId::from("resolution:g1"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 1,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        manager
            .ingest(ManagerInput::EpistemicReceipt {
                case_id: CaseId::from("case-reactivate"),
                receipt: StepReceipt::GhostResolved {
                    ghost_id: GhostId::from("g1"),
                    resolution_ref: JustificationRef::Anchor("witness:bank_statement".to_owned()),
                    resulting_status: GhostStatus::Resolved,
                    resolution_cell_id: CellId::from("resolution:g1"),
                    required_for: vec![CellId::from("conclusion")],
                    graph,
                },
            })
            .expect("ingest should work");

        let out = manager
            .evaluate_next(&CaseId::from("case-reactivate"))
            .expect("evaluation should work");
        assert!(matches!(
            out,
            ManagerOutput::ReevaluateEpistemicClosure {
                ref conclusion_cell_ids,
                previous_verdict: Verdict::Ghost,
                ..
            }
            if conclusion_cell_ids == &vec![CellId::from("conclusion")]
        ));
        let actions = out
            .runtime_actions()
            .expect("re-evaluation output should build runtime actions");
        assert!(matches!(
            actions.as_slice(),
            [StepAction::Epistemic(EpistemicAction::ReassessClosure {
                conclusion_cell_id,
                previous_verdict: Verdict::Ghost,
                ..
            })] if conclusion_cell_id == &CellId::from("conclusion")
        ));
    }

    #[test]
    fn manager_resume_retains_pending_pointer_after_reopen() {
        let db_path = std::env::temp_dir().join(format!(
            "manager-resume-advance-{}-{}.sqlite",
            std::process::id(),
            1_763_652_001_u64
        ));
        let _ = fs::remove_file(&db_path);

        let case_id = CaseId::from("case-resume-advance");
        let pointer = StatePointer {
            namespace: format!("case:{}", case_id.0),
            head_cid: StorageAtomCid("cid-head-1".to_owned()),
            prev_head_cid: Some(StorageAtomCid("cid-head-0".to_owned())),
            height: 2,
        };

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should open");
            let mut manager = BasicManager::new();
            manager
                .ingest(ManagerInput::EpistemicReceipt {
                    case_id: case_id.clone(),
                    receipt: StepReceipt::EpistemicClosureTransition {
                        conclusion_cell_id: CellId::from("conclusion"),
                        from_verdict: Verdict::Ghost,
                        to_verdict: Verdict::Commit,
                        grounding_ratio_bp: 9_100,
                    },
                })
                .expect("ingest should work");
            let out = manager
                .evaluate_next(&case_id)
                .expect("evaluation should work");
            assert!(matches!(
                out,
                ManagerOutput::AdvancePointer {
                    ref head_cid,
                    ..
                } if head_cid == &PointerAlias::from("closure:conclusion")
            ));
            manager
                .persist_case_state(&store, &case_id, vec![pointer.clone()], Some(1), None, 200)
                .expect("case state should persist");
        }

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should reopen");
            let mut restored = BasicManager::new();
            let persisted = restored
                .rehydrate_case_state(&store, &case_id)
                .expect("rehydration should work")
                .expect("case should exist");
            assert_eq!(persisted.pointers, vec![pointer]);

            let resumed = restored.resume_case(&case_id).expect("resume should work");
            assert!(matches!(
                resumed,
                ManagerOutput::AdvancePointer {
                    ref head_cid,
                    ..
                } if head_cid == &PointerAlias::from("closure:conclusion")
            ));
        }

        let _ = fs::remove_file(db_path);
    }

    #[test]
    fn manager_resume_retains_ghost_pending_block_after_reopen() {
        let db_path = std::env::temp_dir().join(format!(
            "manager-resume-ghost-{}-{}.sqlite",
            std::process::id(),
            1_763_652_002_u64
        ));
        let _ = fs::remove_file(&db_path);

        let case_id = CaseId::from("case-resume-ghost");

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should open");
            let mut manager = BasicManager::new();
            manager
                .ingest(ManagerInput::EpistemicReceipt {
                    case_id: case_id.clone(),
                    receipt: StepReceipt::EpistemicClosureTransition {
                        conclusion_cell_id: CellId::from("conclusion"),
                        from_verdict: Verdict::Ghost,
                        to_verdict: Verdict::Ghost,
                        grounding_ratio_bp: 3_100,
                    },
                })
                .expect("ingest should work");
            let out = manager
                .evaluate_next(&case_id)
                .expect("evaluation should work");
            assert!(matches!(
                out,
                ManagerOutput::Blocked {
                    reason: BlockReason::GhostPending,
                    ..
                }
            ));
            manager
                .persist_case_state(&store, &case_id, Vec::new(), Some(1), None, 201)
                .expect("case state should persist");
        }

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should reopen");
            let mut restored = BasicManager::new();
            restored
                .rehydrate_case_state(&store, &case_id)
                .expect("rehydration should work")
                .expect("case should exist");
            let resumed = restored.resume_case(&case_id).expect("resume should work");
            assert!(matches!(
                resumed,
                ManagerOutput::Blocked {
                    reason: BlockReason::GhostPending,
                    ..
                }
            ));
        }

        let _ = fs::remove_file(db_path);
    }

    #[test]
    fn manager_resume_retains_epistemic_reject_block_after_reopen() {
        let db_path = std::env::temp_dir().join(format!(
            "manager-resume-reject-{}-{}.sqlite",
            std::process::id(),
            1_763_652_003_u64
        ));
        let _ = fs::remove_file(&db_path);

        let case_id = CaseId::from("case-resume-reject");

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should open");
            let mut manager = BasicManager::new();
            manager
                .ingest(ManagerInput::EpistemicReceipt {
                    case_id: case_id.clone(),
                    receipt: StepReceipt::EpistemicClosureTransition {
                        conclusion_cell_id: CellId::from("conclusion"),
                        from_verdict: Verdict::Ghost,
                        to_verdict: Verdict::Reject,
                        grounding_ratio_bp: 900,
                    },
                })
                .expect("ingest should work");
            let out = manager
                .evaluate_next(&case_id)
                .expect("evaluation should work");
            assert!(matches!(
                out,
                ManagerOutput::Blocked {
                    reason: BlockReason::EpistemicReject,
                    ..
                }
            ));
            manager
                .persist_case_state(&store, &case_id, Vec::new(), Some(1), None, 202)
                .expect("case state should persist");
        }

        {
            let store = SqliteEpistemicStore::open(&db_path).expect("sqlite store should reopen");
            let mut restored = BasicManager::new();
            restored
                .rehydrate_case_state(&store, &case_id)
                .expect("rehydration should work")
                .expect("case should exist");
            let resumed = restored.resume_case(&case_id).expect("resume should work");
            assert!(matches!(
                resumed,
                ManagerOutput::Blocked {
                    reason: BlockReason::EpistemicReject,
                    ..
                }
            ));
        }

        let _ = fs::remove_file(db_path);
    }
}
