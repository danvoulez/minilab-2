use crate::{
    BenchmarkPrompt, ProposalAdapterError, ProposalAdequacy, ProposalIssueCode,
    ProposalNormalizationReport, ProposalStage, Proposer, ProposerError, adapt_llm_proposal_json,
};
use blake3::Hasher;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use thiserror::Error;
use time::{OffsetDateTime, format_description::well_known::Rfc3339};

pub const BENCHMARK_REPORT_SCHEMA_VERSION: &str = "v1";

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum BenchmarkClass {
    AnchoredClosure,
    HonestInsufficiency,
    IllegitimateClosure,
    PostResolutionRecovery,
    ResolutionSourceSensitivity,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkCase {
    pub id: String,
    pub class: BenchmarkClass,
    pub initial_input: String,
    pub expected_initial: ProposalAdequacy,
    pub resolution_input: Option<String>,
    pub expected_resolved: Option<ProposalAdequacy>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkCaseReport {
    pub id: String,
    pub class: BenchmarkClass,
    pub initial_adequacy: ProposalAdequacy,
    pub expected_initial: ProposalAdequacy,
    pub initial_issue_count: usize,
    pub initial_raw_output: String,
    pub open_ghost_count: usize,
    pub ghost_issue_count: usize,
    pub matched_initial: bool,
    pub resolved: Option<BenchmarkResolvedReport>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkResolvedReport {
    pub adequacy: ProposalAdequacy,
    pub expected: ProposalAdequacy,
    pub matched: bool,
    pub transition_correct: bool,
    pub issue_count: usize,
    pub raw_output: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkMetrics {
    pub total_cases: usize,
    pub correct_commit_count: usize,
    pub correct_ghost_count: usize,
    pub correct_reject_count: usize,
    pub false_commit_count: usize,
    pub false_ghost_count: usize,
    pub false_reject_count: usize,
    pub ghost_utility_rate_bp: u16,
    pub redundant_ghost_rate_bp: u16,
    pub transition_correct_count: usize,
    pub resolution_to_commit_lift_count: usize,
    pub resolution_without_commit_count: usize,
    pub commit_without_transition_count: usize,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkReport {
    pub cases: Vec<BenchmarkCaseReport>,
    pub metrics: BenchmarkMetrics,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct BenchmarkVersionLabels {
    pub methodology: Option<String>,
    pub engine: Option<String>,
    pub adapter: Option<String>,
    pub benchmark_spec: Option<String>,
    pub provider_selection: Option<String>,
    pub input_protocol: Option<String>,
    pub case_corpus: Option<String>,
    pub report_schema: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct BenchmarkTrackedPaths {
    #[serde(default)]
    pub methodology: Vec<String>,
    #[serde(default)]
    pub engine: Vec<String>,
    #[serde(default)]
    pub adapter: Vec<String>,
    #[serde(default)]
    pub benchmark_spec: Vec<String>,
    #[serde(default)]
    pub provider_selection: Vec<String>,
    #[serde(default)]
    pub input_protocol: Vec<String>,
    #[serde(default)]
    pub case_corpus: Vec<String>,
    #[serde(default)]
    pub report_schema: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct BenchmarkRunManifest {
    #[serde(default)]
    pub labels: BenchmarkVersionLabels,
    #[serde(default)]
    pub tracked_paths: BenchmarkTrackedPaths,
    #[serde(default)]
    pub notes: Option<String>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub registry_path: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkProviderDescriptor {
    pub backend: String,
    pub model: Option<String>,
    pub reasoning_effort: Option<String>,
    pub background: bool,
    pub base_url: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkDimensionIdentity {
    pub label: Option<String>,
    pub auto_revision: String,
    pub fingerprint: String,
    pub tracked_paths: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkRunIdentity {
    pub methodology: BenchmarkDimensionIdentity,
    pub engine: BenchmarkDimensionIdentity,
    pub adapter: BenchmarkDimensionIdentity,
    pub benchmark_spec: BenchmarkDimensionIdentity,
    pub provider_selection: BenchmarkDimensionIdentity,
    pub input_protocol: BenchmarkDimensionIdentity,
    pub case_corpus: BenchmarkDimensionIdentity,
    pub report_schema: BenchmarkDimensionIdentity,
    pub provider: BenchmarkProviderDescriptor,
    pub manifest_path: Option<String>,
    pub registry_path: String,
    pub cases_path: String,
    pub report_path: String,
    pub git_head: Option<String>,
    pub generated_at_unix_s: u64,
    pub generated_at_iso8601_utc: String,
    pub timing: BenchmarkRunTiming,
    pub prov: BenchmarkProvBundle,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkRunTiming {
    pub started_at_unix_s: u64,
    pub started_at_iso8601_utc: String,
    pub completed_at_unix_s: u64,
    pub completed_at_iso8601_utc: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkProvBundle {
    pub used: Vec<BenchmarkProvEntity>,
    pub was_derived_from: Vec<BenchmarkProvEntity>,
    pub was_generated_by: BenchmarkProvActivity,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkProvEntity {
    pub id: String,
    pub role: String,
    pub path: Option<String>,
    pub fingerprint: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkProvActivity {
    pub id: String,
    pub activity_type: String,
    pub started_at_iso8601_utc: String,
    pub completed_at_iso8601_utc: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct VersionedBenchmarkReport {
    pub run: BenchmarkRunIdentity,
    pub report: BenchmarkReport,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct BenchmarkVersionRegistry {
    #[serde(default)]
    pub dimensions: BTreeMap<String, Vec<BenchmarkVersionRecord>>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BenchmarkVersionRecord {
    pub auto_revision: String,
    pub fingerprint: String,
    pub label: Option<String>,
    pub first_seen_unix_s: u64,
}

#[derive(Debug, Error)]
pub enum BenchmarkIoError {
    #[error("failed to read benchmark cases from {path}: {source}")]
    ReadCases {
        path: String,
        source: std::io::Error,
    },
    #[error("failed to parse benchmark cases from {path}: {source}")]
    ParseCases {
        path: String,
        source: serde_json::Error,
    },
    #[error("failed to serialize benchmark report for {path}: {source}")]
    SerializeReport {
        path: String,
        source: serde_json::Error,
    },
    #[error("failed to write benchmark report to {path}: {source}")]
    WriteReport {
        path: String,
        source: std::io::Error,
    },
    #[error("failed to read benchmark manifest from {path}: {source}")]
    ReadManifest {
        path: String,
        source: std::io::Error,
    },
    #[error("failed to parse benchmark manifest from {path}: {source}")]
    ParseManifest {
        path: String,
        source: serde_json::Error,
    },
    #[error("failed to read benchmark version registry from {path}: {source}")]
    ReadVersionRegistry {
        path: String,
        source: std::io::Error,
    },
    #[error("failed to parse benchmark version registry from {path}: {source}")]
    ParseVersionRegistry {
        path: String,
        source: serde_json::Error,
    },
    #[error("failed to serialize benchmark version registry for {path}: {source}")]
    SerializeVersionRegistry {
        path: String,
        source: serde_json::Error,
    },
    #[error("failed to write benchmark version registry to {path}: {source}")]
    WriteVersionRegistry {
        path: String,
        source: std::io::Error,
    },
    #[error("tracked benchmark path does not exist: {path}")]
    MissingTrackedPath { path: String },
}

#[derive(Debug, Error)]
pub enum BenchmarkError {
    #[error(transparent)]
    Proposer(#[from] ProposerError),
    #[error(transparent)]
    Adapter(#[from] ProposalAdapterError),
}

pub fn load_benchmark_cases(
    path: impl AsRef<Path>,
) -> Result<Vec<BenchmarkCase>, BenchmarkIoError> {
    let path = path.as_ref();
    let raw = fs::read_to_string(path).map_err(|source| BenchmarkIoError::ReadCases {
        path: path.display().to_string(),
        source,
    })?;
    serde_json::from_str(&raw).map_err(|source| BenchmarkIoError::ParseCases {
        path: path.display().to_string(),
        source,
    })
}

pub fn load_benchmark_run_manifest(
    path: impl AsRef<Path>,
) -> Result<BenchmarkRunManifest, BenchmarkIoError> {
    let path = path.as_ref();
    let raw = fs::read_to_string(path).map_err(|source| BenchmarkIoError::ReadManifest {
        path: path.display().to_string(),
        source,
    })?;
    serde_json::from_str(&raw).map_err(|source| BenchmarkIoError::ParseManifest {
        path: path.display().to_string(),
        source,
    })
}

pub fn load_benchmark_version_registry(
    path: impl AsRef<Path>,
) -> Result<BenchmarkVersionRegistry, BenchmarkIoError> {
    let path = path.as_ref();
    if !path.exists() {
        return Ok(BenchmarkVersionRegistry::default());
    }
    let raw = fs::read_to_string(path).map_err(|source| BenchmarkIoError::ReadVersionRegistry {
        path: path.display().to_string(),
        source,
    })?;
    serde_json::from_str(&raw).map_err(|source| BenchmarkIoError::ParseVersionRegistry {
        path: path.display().to_string(),
        source,
    })
}

pub fn write_benchmark_version_registry(
    path: impl AsRef<Path>,
    registry: &BenchmarkVersionRegistry,
) -> Result<(), BenchmarkIoError> {
    let path = path.as_ref();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|source| BenchmarkIoError::WriteVersionRegistry {
            path: path.display().to_string(),
            source,
        })?;
    }
    let raw = serde_json::to_string_pretty(registry).map_err(|source| {
        BenchmarkIoError::SerializeVersionRegistry {
            path: path.display().to_string(),
            source,
        }
    })?;
    fs::write(path, raw).map_err(|source| BenchmarkIoError::WriteVersionRegistry {
        path: path.display().to_string(),
        source,
    })
}

pub fn write_benchmark_report(
    path: impl AsRef<Path>,
    report: &BenchmarkReport,
) -> Result<(), BenchmarkIoError> {
    let path = path.as_ref();
    let raw = serde_json::to_string_pretty(report).map_err(|source| {
        BenchmarkIoError::SerializeReport {
            path: path.display().to_string(),
            source,
        }
    })?;
    fs::write(path, raw).map_err(|source| BenchmarkIoError::WriteReport {
        path: path.display().to_string(),
        source,
    })
}

pub fn write_versioned_benchmark_report(
    path: impl AsRef<Path>,
    report: &VersionedBenchmarkReport,
) -> Result<(), BenchmarkIoError> {
    let path = path.as_ref();
    let raw = serde_json::to_string_pretty(report).map_err(|source| {
        BenchmarkIoError::SerializeReport {
            path: path.display().to_string(),
            source,
        }
    })?;
    fs::write(path, raw).map_err(|source| BenchmarkIoError::WriteReport {
        path: path.display().to_string(),
        source,
    })
}

pub fn default_benchmark_run_manifest() -> BenchmarkRunManifest {
    BenchmarkRunManifest::default()
}

pub fn default_version_registry_path() -> &'static str {
    "benchmarks/version_registry.json"
}

pub fn resolve_run_identity(
    manifest: &BenchmarkRunManifest,
    manifest_path: Option<&Path>,
    workspace_root: &Path,
    cases_path: &Path,
    report_path: &Path,
    provider: &BenchmarkProviderDescriptor,
    timing: BenchmarkRunTiming,
    registry: &mut BenchmarkVersionRegistry,
) -> Result<BenchmarkRunIdentity, BenchmarkIoError> {
    let generated_at_unix_s = timing.completed_at_unix_s;
    let default_engine_paths = vec![
        "crates/epistemic-storage/src/lib.rs".to_owned(),
        "crates/proof-runtime/src/lib.rs".to_owned(),
        "crates/manager-plane/src/lib.rs".to_owned(),
    ];
    let default_adapter_paths = vec![
        "crates/manager-plane/src/lib.rs".to_owned(),
        "crates/manager-plane/src/proposer.rs".to_owned(),
    ];
    let default_benchmark_spec_paths = vec![
        "docs/BENCHMARK_PROTOCOL.md".to_owned(),
        "crates/manager-plane/src/benchmark.rs".to_owned(),
    ];
    let default_input_protocol_paths = vec![
        "crates/manager-plane/src/proposer.rs".to_owned(),
        "crates/manager-plane/examples/run_containment_benchmark.rs".to_owned(),
    ];
    let default_report_schema_paths = vec!["crates/manager-plane/src/benchmark.rs".to_owned()];
    let methodology_paths = resolve_dimension_paths(
        &manifest.tracked_paths.methodology,
        manifest_path,
        workspace_root,
    );
    let engine_paths = resolve_dimension_paths(
        if manifest.tracked_paths.engine.is_empty() {
            &default_engine_paths
        } else {
            &manifest.tracked_paths.engine
        },
        manifest_path,
        workspace_root,
    );
    let adapter_paths = resolve_dimension_paths(
        if manifest.tracked_paths.adapter.is_empty() {
            &default_adapter_paths
        } else {
            &manifest.tracked_paths.adapter
        },
        manifest_path,
        workspace_root,
    );
    let benchmark_spec_paths = resolve_dimension_paths(
        if manifest.tracked_paths.benchmark_spec.is_empty() {
            &default_benchmark_spec_paths
        } else {
            &manifest.tracked_paths.benchmark_spec
        },
        manifest_path,
        workspace_root,
    );
    let provider_selection_paths = resolve_dimension_paths(
        &manifest.tracked_paths.provider_selection,
        manifest_path,
        workspace_root,
    );
    let input_protocol_paths = resolve_dimension_paths(
        if manifest.tracked_paths.input_protocol.is_empty() {
            &default_input_protocol_paths
        } else {
            &manifest.tracked_paths.input_protocol
        },
        manifest_path,
        workspace_root,
    );
    let case_corpus_paths = if manifest.tracked_paths.case_corpus.is_empty() {
        vec![cases_path.to_path_buf()]
    } else {
        resolve_dimension_paths(
            &manifest.tracked_paths.case_corpus,
            manifest_path,
            workspace_root,
        )
    };
    let report_schema_paths = resolve_dimension_paths(
        if manifest.tracked_paths.report_schema.is_empty() {
            &default_report_schema_paths
        } else {
            &manifest.tracked_paths.report_schema
        },
        manifest_path,
        workspace_root,
    );

    let methodology = resolve_dimension_identity(
        registry,
        "methodology",
        manifest.labels.methodology.clone(),
        &methodology_paths,
        &json!({
            "notes": manifest.notes,
            "tags": manifest.tags,
            "manifest_path": manifest_path.map(|path| path.display().to_string()),
        }),
        generated_at_unix_s,
    )?;
    let engine = resolve_dimension_identity(
        registry,
        "engine",
        manifest.labels.engine.clone(),
        &engine_paths,
        &json!({}),
        generated_at_unix_s,
    )?;
    let adapter = resolve_dimension_identity(
        registry,
        "adapter",
        manifest.labels.adapter.clone(),
        &adapter_paths,
        &json!({}),
        generated_at_unix_s,
    )?;
    let benchmark_spec = resolve_dimension_identity(
        registry,
        "benchmark_spec",
        manifest.labels.benchmark_spec.clone(),
        &benchmark_spec_paths,
        &json!({}),
        generated_at_unix_s,
    )?;
    let provider_selection = resolve_dimension_identity(
        registry,
        "provider_selection",
        manifest.labels.provider_selection.clone(),
        &provider_selection_paths,
        &json!(provider),
        generated_at_unix_s,
    )?;
    let input_protocol = resolve_dimension_identity(
        registry,
        "input_protocol",
        manifest.labels.input_protocol.clone(),
        &input_protocol_paths,
        &json!({
            "backend": provider.backend,
            "prompt_envelope": "Case ID + Stage + Benchmark input",
        }),
        generated_at_unix_s,
    )?;
    let case_corpus = resolve_dimension_identity(
        registry,
        "case_corpus",
        manifest.labels.case_corpus.clone(),
        &case_corpus_paths,
        &json!({}),
        generated_at_unix_s,
    )?;
    let report_schema = resolve_dimension_identity(
        registry,
        "report_schema",
        manifest.labels.report_schema.clone(),
        &report_schema_paths,
        &json!({ "schema_version": BENCHMARK_REPORT_SCHEMA_VERSION }),
        generated_at_unix_s,
    )?;

    let registry_path = manifest
        .registry_path
        .clone()
        .unwrap_or_else(|| default_version_registry_path().to_owned());
    let prov = build_prov_bundle(
        manifest_path.map(|path| path.display().to_string()),
        registry_path.clone(),
        cases_path.display().to_string(),
        report_path.display().to_string(),
        &methodology,
        &engine,
        &adapter,
        &benchmark_spec,
        &provider_selection,
        &input_protocol,
        &case_corpus,
        &report_schema,
        &timing,
    );

    Ok(BenchmarkRunIdentity {
        methodology,
        engine,
        adapter,
        benchmark_spec,
        provider_selection,
        input_protocol,
        case_corpus,
        report_schema,
        provider: provider.clone(),
        manifest_path: manifest_path.map(|path| path.display().to_string()),
        registry_path,
        cases_path: cases_path.display().to_string(),
        report_path: report_path.display().to_string(),
        git_head: git_head(workspace_root),
        generated_at_unix_s,
        generated_at_iso8601_utc: timing.completed_at_iso8601_utc.clone(),
        timing,
        prov,
    })
}

fn resolve_dimension_paths(
    configured_paths: &[String],
    manifest_path: Option<&Path>,
    workspace_root: &Path,
) -> Vec<PathBuf> {
    configured_paths
        .iter()
        .map(|path| {
            let path = Path::new(path);
            if path.is_absolute() {
                path.to_path_buf()
            } else {
                let workspace_candidate = workspace_root.join(path);
                if workspace_candidate.exists() {
                    workspace_candidate
                } else if let Some(manifest_path) = manifest_path {
                    manifest_path.parent().unwrap_or(workspace_root).join(path)
                } else {
                    workspace_candidate
                }
            }
        })
        .collect()
}

fn resolve_dimension_identity(
    registry: &mut BenchmarkVersionRegistry,
    dimension: &str,
    label: Option<String>,
    tracked_paths: &[PathBuf],
    extra: &serde_json::Value,
    generated_at_unix_s: u64,
) -> Result<BenchmarkDimensionIdentity, BenchmarkIoError> {
    let fingerprint = fingerprint_paths(tracked_paths, extra)?;
    let auto_revision =
        registry.resolve(dimension, &fingerprint, label.clone(), generated_at_unix_s);
    Ok(BenchmarkDimensionIdentity {
        label,
        auto_revision,
        fingerprint,
        tracked_paths: tracked_paths
            .iter()
            .map(|path| path.display().to_string())
            .collect(),
    })
}

fn fingerprint_paths(
    tracked_paths: &[PathBuf],
    extra: &serde_json::Value,
) -> Result<String, BenchmarkIoError> {
    let mut hasher = Hasher::new();
    let mut sorted_paths = tracked_paths.to_vec();
    sorted_paths.sort();
    for path in sorted_paths {
        if !path.exists() {
            return Err(BenchmarkIoError::MissingTrackedPath {
                path: path.display().to_string(),
            });
        }
        hasher.update(path.display().to_string().as_bytes());
        hasher.update(&[0]);
        hasher.update(
            &fs::read(&path).map_err(|source| BenchmarkIoError::ReadCases {
                path: path.display().to_string(),
                source,
            })?,
        );
        hasher.update(&[0xff]);
    }
    let extra_json = serde_json::to_vec(extra).expect("versioning extra payload should serialize");
    hasher.update(&extra_json);
    Ok(hasher.finalize().to_hex().to_string())
}

fn git_head(workspace_root: &Path) -> Option<String> {
    let git_dir = workspace_root.join(".git");
    let head = fs::read_to_string(git_dir.join("HEAD")).ok()?;
    let head = head.trim();
    if let Some(reference) = head.strip_prefix("ref: ") {
        fs::read_to_string(git_dir.join(reference))
            .ok()
            .map(|value| value.trim().to_owned())
    } else {
        Some(head.to_owned())
    }
}

pub fn capture_run_timing(started_at_unix_s: u64, completed_at_unix_s: u64) -> BenchmarkRunTiming {
    BenchmarkRunTiming {
        started_at_unix_s,
        started_at_iso8601_utc: unix_to_rfc3339(started_at_unix_s),
        completed_at_unix_s,
        completed_at_iso8601_utc: unix_to_rfc3339(completed_at_unix_s),
    }
}

fn unix_to_rfc3339(unix_s: u64) -> String {
    OffsetDateTime::from_unix_timestamp(unix_s as i64)
        .expect("valid unix timestamp")
        .format(&Rfc3339)
        .expect("rfc3339 formatting should work")
}

fn build_prov_bundle(
    manifest_path: Option<String>,
    registry_path: String,
    cases_path: String,
    report_path: String,
    methodology: &BenchmarkDimensionIdentity,
    engine: &BenchmarkDimensionIdentity,
    adapter: &BenchmarkDimensionIdentity,
    benchmark_spec: &BenchmarkDimensionIdentity,
    provider_selection: &BenchmarkDimensionIdentity,
    input_protocol: &BenchmarkDimensionIdentity,
    case_corpus: &BenchmarkDimensionIdentity,
    report_schema: &BenchmarkDimensionIdentity,
    timing: &BenchmarkRunTiming,
) -> BenchmarkProvBundle {
    let mut used = vec![
        BenchmarkProvEntity {
            id: input_protocol.auto_revision.clone(),
            role: "input_protocol".to_owned(),
            path: input_protocol.tracked_paths.first().cloned(),
            fingerprint: Some(input_protocol.fingerprint.clone()),
        },
        BenchmarkProvEntity {
            id: case_corpus.auto_revision.clone(),
            role: "case_corpus".to_owned(),
            path: Some(cases_path.clone()),
            fingerprint: Some(case_corpus.fingerprint.clone()),
        },
        BenchmarkProvEntity {
            id: provider_selection.auto_revision.clone(),
            role: "provider_selection".to_owned(),
            path: None,
            fingerprint: Some(provider_selection.fingerprint.clone()),
        },
        BenchmarkProvEntity {
            id: benchmark_spec.auto_revision.clone(),
            role: "benchmark_spec".to_owned(),
            path: benchmark_spec.tracked_paths.first().cloned(),
            fingerprint: Some(benchmark_spec.fingerprint.clone()),
        },
    ];
    if let Some(manifest_path) = manifest_path.clone() {
        used.push(BenchmarkProvEntity {
            id: methodology.auto_revision.clone(),
            role: "manifest".to_owned(),
            path: Some(manifest_path),
            fingerprint: Some(methodology.fingerprint.clone()),
        });
    }

    let was_derived_from = vec![
        BenchmarkProvEntity {
            id: engine.auto_revision.clone(),
            role: "engine".to_owned(),
            path: engine.tracked_paths.first().cloned(),
            fingerprint: Some(engine.fingerprint.clone()),
        },
        BenchmarkProvEntity {
            id: adapter.auto_revision.clone(),
            role: "adapter".to_owned(),
            path: adapter.tracked_paths.first().cloned(),
            fingerprint: Some(adapter.fingerprint.clone()),
        },
        BenchmarkProvEntity {
            id: report_schema.auto_revision.clone(),
            role: "report_schema".to_owned(),
            path: report_schema.tracked_paths.first().cloned(),
            fingerprint: Some(report_schema.fingerprint.clone()),
        },
        BenchmarkProvEntity {
            id: "version-registry".to_owned(),
            role: "version_registry".to_owned(),
            path: Some(registry_path),
            fingerprint: None,
        },
        BenchmarkProvEntity {
            id: "versioned-report".to_owned(),
            role: "report_output".to_owned(),
            path: Some(report_path),
            fingerprint: None,
        },
    ];

    BenchmarkProvBundle {
        used,
        was_derived_from,
        was_generated_by: BenchmarkProvActivity {
            id: format!("benchmark-run-{}", timing.completed_at_unix_s),
            activity_type: "containment_benchmark_run".to_owned(),
            started_at_iso8601_utc: timing.started_at_iso8601_utc.clone(),
            completed_at_iso8601_utc: timing.completed_at_iso8601_utc.clone(),
        },
    }
}

impl BenchmarkVersionRegistry {
    fn resolve(
        &mut self,
        dimension: &str,
        fingerprint: &str,
        label: Option<String>,
        generated_at_unix_s: u64,
    ) -> String {
        let entries = self.dimensions.entry(dimension.to_owned()).or_default();
        if let Some(entry) = entries
            .iter_mut()
            .find(|entry| entry.fingerprint == fingerprint)
        {
            if entry.label.is_none() && label.is_some() {
                entry.label = label;
            }
            return entry.auto_revision.clone();
        }

        let next_revision = entries.len() + 1;
        let auto_revision = format!("{dimension}-r{next_revision}");
        entries.push(BenchmarkVersionRecord {
            auto_revision: auto_revision.clone(),
            fingerprint: fingerprint.to_owned(),
            label,
            first_seen_unix_s: generated_at_unix_s,
        });
        auto_revision
    }
}

fn ratio_bp(numerator: usize, denominator: usize) -> u16 {
    if denominator == 0 {
        return 0;
    }
    let scaled = ((numerator as f64 / denominator as f64) * 10_000.0).round();
    if scaled <= 0.0 {
        0
    } else if scaled >= f64::from(u16::MAX) {
        u16::MAX
    } else {
        scaled as u16
    }
}

fn count_open_ghosts(report: &ProposalNormalizationReport) -> usize {
    report
        .graph
        .ghosts
        .values()
        .filter(|ghost| ghost.status == epistemic_storage::GhostStatus::Open)
        .count()
}

fn count_ghost_issues(report: &ProposalNormalizationReport) -> usize {
    report
        .issues
        .iter()
        .filter(|issue| {
            matches!(
                issue.code,
                ProposalIssueCode::ReferencedGhostSynthesized
                    | ProposalIssueCode::MissingSupportGhostSynthesized
            )
        })
        .count()
}

pub fn run_proposal_benchmark<P>(
    proposer: &P,
    cases: &[BenchmarkCase],
) -> Result<BenchmarkReport, BenchmarkError>
where
    P: Proposer + ?Sized,
{
    let mut reports = Vec::with_capacity(cases.len());

    let mut correct_commit_count = 0;
    let mut correct_ghost_count = 0;
    let mut correct_reject_count = 0;
    let mut false_commit_count = 0;
    let mut false_ghost_count = 0;
    let mut false_reject_count = 0;
    let mut ghost_useful_cases = 0;
    let mut ghost_total_cases = 0;
    let mut redundant_ghost_cases = 0;
    let mut transition_correct_count = 0;
    let mut resolution_to_commit_lift_count = 0;
    let mut resolution_without_commit_count = 0;
    let mut commit_without_transition_count = 0;

    for case in cases {
        let initial_submission = proposer.propose(&BenchmarkPrompt {
            case_id: case.id.clone(),
            stage: ProposalStage::Initial,
            input: case.initial_input.clone(),
        })?;
        let initial = adapt_llm_proposal_json(&initial_submission.proposal_json)?;
        let matched_initial = initial.adequacy == case.expected_initial;
        match (&initial.adequacy, &case.expected_initial) {
            (ProposalAdequacy::CommitReady, ProposalAdequacy::CommitReady) => {
                correct_commit_count += 1;
            }
            (
                ProposalAdequacy::RequiresEpistemicResolution,
                ProposalAdequacy::RequiresEpistemicResolution,
            ) => {
                correct_ghost_count += 1;
            }
            (ProposalAdequacy::Rejected, ProposalAdequacy::Rejected) => {
                correct_reject_count += 1;
            }
            (ProposalAdequacy::CommitReady, _) => false_commit_count += 1,
            (ProposalAdequacy::RequiresEpistemicResolution, _) => false_ghost_count += 1,
            (ProposalAdequacy::Rejected, _) => false_reject_count += 1,
        }

        let open_ghost_count = count_open_ghosts(&initial);
        let ghost_issue_count = count_ghost_issues(&initial);
        if initial.adequacy == ProposalAdequacy::RequiresEpistemicResolution {
            ghost_total_cases += 1;
            if open_ghost_count > 0 || ghost_issue_count > 0 {
                ghost_useful_cases += 1;
            } else {
                redundant_ghost_cases += 1;
            }
        }

        let resolved = match (&case.resolution_input, &case.expected_resolved) {
            (Some(resolution_input), Some(expected_resolved)) => {
                let resolved_submission = proposer.propose(&BenchmarkPrompt {
                    case_id: case.id.clone(),
                    stage: ProposalStage::Resolution,
                    input: resolution_input.clone(),
                })?;
                let resolved_report = adapt_llm_proposal_json(&resolved_submission.proposal_json)?;
                let matched = resolved_report.adequacy == *expected_resolved;
                let transition_correct = initial.adequacy
                    == ProposalAdequacy::RequiresEpistemicResolution
                    && resolved_report.adequacy == *expected_resolved;
                if transition_correct {
                    transition_correct_count += 1;
                }
                if initial.adequacy != ProposalAdequacy::CommitReady
                    && resolved_report.adequacy == ProposalAdequacy::CommitReady
                {
                    resolution_to_commit_lift_count += 1;
                }
                if initial.adequacy == ProposalAdequacy::RequiresEpistemicResolution
                    && resolved_report.adequacy != ProposalAdequacy::CommitReady
                {
                    resolution_without_commit_count += 1;
                }
                if initial.adequacy == ProposalAdequacy::CommitReady
                    && resolved_report.adequacy == ProposalAdequacy::CommitReady
                {
                    commit_without_transition_count += 1;
                }
                Some(BenchmarkResolvedReport {
                    adequacy: resolved_report.adequacy,
                    expected: expected_resolved.clone(),
                    matched,
                    transition_correct,
                    issue_count: resolved_report.issues.len(),
                    raw_output: resolved_submission.raw_output,
                })
            }
            _ => None,
        };

        reports.push(BenchmarkCaseReport {
            id: case.id.clone(),
            class: case.class.clone(),
            initial_adequacy: initial.adequacy,
            expected_initial: case.expected_initial.clone(),
            initial_issue_count: initial.issues.len(),
            initial_raw_output: initial_submission.raw_output,
            open_ghost_count,
            ghost_issue_count,
            matched_initial,
            resolved,
        });
    }

    let total_cases = reports.len();
    Ok(BenchmarkReport {
        cases: reports,
        metrics: BenchmarkMetrics {
            total_cases,
            correct_commit_count,
            correct_ghost_count,
            correct_reject_count,
            false_commit_count,
            false_ghost_count,
            false_reject_count,
            ghost_utility_rate_bp: ratio_bp(ghost_useful_cases, ghost_total_cases),
            redundant_ghost_rate_bp: ratio_bp(redundant_ghost_cases, ghost_total_cases),
            transition_correct_count,
            resolution_to_commit_lift_count,
            resolution_without_commit_count,
            commit_without_transition_count,
        },
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn unique_temp_path(name: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("time should move forward")
            .as_nanos();
        std::env::temp_dir().join(format!("manager-plane-{name}-{nanos}.json"))
    }

    #[test]
    fn benchmark_report_round_trips_through_json_io() {
        let cases_path = unique_temp_path("cases");
        let report_path = unique_temp_path("report");
        let cases = vec![BenchmarkCase {
            id: "case-1".to_owned(),
            class: BenchmarkClass::AnchoredClosure,
            initial_input: "input".to_owned(),
            expected_initial: ProposalAdequacy::CommitReady,
            resolution_input: None,
            expected_resolved: None,
        }];
        fs::write(
            &cases_path,
            serde_json::to_string(&cases).expect("cases should serialize"),
        )
        .expect("cases file should be written");

        let loaded_cases =
            load_benchmark_cases(&cases_path).expect("benchmark cases should load from disk");
        assert_eq!(loaded_cases, cases);

        let report = BenchmarkReport {
            cases: vec![BenchmarkCaseReport {
                id: "case-1".to_owned(),
                class: BenchmarkClass::AnchoredClosure,
                initial_adequacy: ProposalAdequacy::CommitReady,
                expected_initial: ProposalAdequacy::CommitReady,
                initial_issue_count: 0,
                initial_raw_output: "{\"cells\":[]}".to_owned(),
                open_ghost_count: 0,
                ghost_issue_count: 0,
                matched_initial: true,
                resolved: None,
            }],
            metrics: BenchmarkMetrics {
                total_cases: 1,
                correct_commit_count: 1,
                correct_ghost_count: 0,
                correct_reject_count: 0,
                false_commit_count: 0,
                false_ghost_count: 0,
                false_reject_count: 0,
                ghost_utility_rate_bp: 0,
                redundant_ghost_rate_bp: 0,
                transition_correct_count: 0,
                resolution_to_commit_lift_count: 0,
                resolution_without_commit_count: 0,
                commit_without_transition_count: 0,
            },
        };
        write_benchmark_report(&report_path, &report)
            .expect("benchmark report should write to disk");

        let raw = fs::read_to_string(&report_path).expect("report should be readable");
        let reloaded: BenchmarkReport =
            serde_json::from_str(&raw).expect("report should deserialize");
        assert_eq!(reloaded, report);

        let _ = fs::remove_file(cases_path);
        let _ = fs::remove_file(report_path);
    }

    #[test]
    fn version_registry_reuses_revision_for_same_fingerprint_and_bumps_for_new_one() {
        let root = std::env::temp_dir().join(format!(
            "manager-plane-versioning-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("time should move forward")
                .as_nanos()
        ));
        fs::create_dir_all(&root).expect("temp root should exist");
        let tracked = root.join("tracked.txt");
        fs::write(&tracked, "alpha").expect("tracked file should be written");

        let mut registry = BenchmarkVersionRegistry::default();
        let first = resolve_dimension_identity(
            &mut registry,
            "engine",
            Some("v1".to_owned()),
            std::slice::from_ref(&tracked),
            &json!({}),
            1,
        )
        .expect("first identity should resolve");
        let second = resolve_dimension_identity(
            &mut registry,
            "engine",
            Some("v1".to_owned()),
            std::slice::from_ref(&tracked),
            &json!({}),
            2,
        )
        .expect("second identity should resolve");
        assert_eq!(first.auto_revision, "engine-r1");
        assert_eq!(second.auto_revision, "engine-r1");

        fs::write(&tracked, "beta").expect("tracked file should change");
        let third = resolve_dimension_identity(
            &mut registry,
            "engine",
            Some("v2".to_owned()),
            std::slice::from_ref(&tracked),
            &json!({}),
            3,
        )
        .expect("third identity should resolve");
        assert_eq!(third.auto_revision, "engine-r2");

        let _ = fs::remove_dir_all(root);
    }
}
