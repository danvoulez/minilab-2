# manager-plane

RFC-0005 implementation surface:
- typed manager inputs/outputs
- case-oriented non-chat orchestration
- delegation and pointer-advance flow
- strict-JSON proposer adaptation and containment benchmark harness
- runnable benchmark driver: `cargo run -p manager-plane --example run_containment_benchmark -- --help`
- live OpenAI Responses backend behind the same proposer seam
- versioned benchmark reports with RO-Crate export
