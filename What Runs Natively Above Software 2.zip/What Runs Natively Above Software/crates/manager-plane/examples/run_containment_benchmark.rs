use manager_plane::{
    BenchmarkProviderDescriptor, BenchmarkRunManifest, CommandStructuredJsonBackend,
    FileStructuredJsonBackend, OpenAiResponsesBackend, Proposer, StructuredJsonProposer,
    VersionedBenchmarkReport, capture_run_timing, default_benchmark_run_manifest,
    default_version_registry_path, load_benchmark_cases, load_benchmark_run_manifest,
    load_benchmark_version_registry, resolve_run_identity, run_proposal_benchmark,
    write_benchmark_version_registry, write_versioned_benchmark_report,
};
use std::env;
use std::error::Error;
use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, PartialEq, Eq)]
enum BackendConfig {
    File {
        root: PathBuf,
    },
    Command {
        program: PathBuf,
        args: Vec<String>,
        cwd: Option<PathBuf>,
    },
    OpenAi {
        model: String,
        api_key_env: String,
        base_url: Option<String>,
        reasoning_effort: Option<String>,
        background: bool,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct CliConfig {
    cases_path: PathBuf,
    report_path: PathBuf,
    manifest_path: Option<PathBuf>,
    backend: BackendConfig,
}

fn usage() -> &'static str {
    "usage:
  cargo run -p manager-plane --example run_containment_benchmark -- \
    --cases /path/to/cases.json \
    --report /path/to/report.json \
    --backend file --root /path/to/proposals [--manifest /path/to/manifest.json]

  cargo run -p manager-plane --example run_containment_benchmark -- \
    --cases /path/to/cases.json \
    --report /path/to/report.json \
    --backend command --program /path/to/proposer [--arg VALUE ...] [--cwd /path] [--manifest /path/to/manifest.json]

  cargo run -p manager-plane --example run_containment_benchmark -- \
    --cases /path/to/cases.json \
    --report /path/to/report.json \
    --backend openai [--model gpt-5.4-2026-03-05] [--api-key-env OPENAI_API_KEY] \
    [--reasoning-effort none|low|medium|high|xhigh] [--background] [--base-url URL] [--manifest /path/to/manifest.json]"
}

fn parse_cli() -> Result<Option<CliConfig>, String> {
    let mut args = env::args().skip(1);
    let mut cases_path = None;
    let mut report_path = None;
    let mut manifest_path = None;
    let mut backend = None;
    let mut root = None;
    let mut program = None;
    let mut command_args = Vec::new();
    let mut cwd = None;
    let mut model = Some("gpt-5.4-2026-03-05".to_owned());
    let mut api_key_env = Some("OPENAI_API_KEY".to_owned());
    let mut base_url = None;
    let mut reasoning_effort = Some("none".to_owned());
    let mut background = false;

    while let Some(flag) = args.next() {
        match flag.as_str() {
            "--cases" => {
                let value = args
                    .next()
                    .ok_or_else(|| "--cases requires a path".to_owned())?;
                cases_path = Some(PathBuf::from(value));
            }
            "--report" => {
                let value = args
                    .next()
                    .ok_or_else(|| "--report requires a path".to_owned())?;
                report_path = Some(PathBuf::from(value));
            }
            "--manifest" => {
                let value = args
                    .next()
                    .ok_or_else(|| "--manifest requires a path".to_owned())?;
                manifest_path = Some(PathBuf::from(value));
            }
            "--backend" => {
                backend = Some(args.next().ok_or_else(|| {
                    "--backend requires `file`, `command`, or `openai`".to_owned()
                })?);
            }
            "--root" => {
                let value = args
                    .next()
                    .ok_or_else(|| "--root requires a path".to_owned())?;
                root = Some(PathBuf::from(value));
            }
            "--program" => {
                let value = args
                    .next()
                    .ok_or_else(|| "--program requires a path".to_owned())?;
                program = Some(PathBuf::from(value));
            }
            "--arg" => {
                command_args.push(
                    args.next()
                        .ok_or_else(|| "--arg requires a value".to_owned())?,
                );
            }
            "--cwd" => {
                let value = args
                    .next()
                    .ok_or_else(|| "--cwd requires a path".to_owned())?;
                cwd = Some(PathBuf::from(value));
            }
            "--model" => {
                model = Some(
                    args.next()
                        .ok_or_else(|| "--model requires a value".to_owned())?,
                );
            }
            "--api-key-env" => {
                api_key_env = Some(
                    args.next()
                        .ok_or_else(|| "--api-key-env requires a value".to_owned())?,
                );
            }
            "--base-url" => {
                base_url = Some(
                    args.next()
                        .ok_or_else(|| "--base-url requires a value".to_owned())?,
                );
            }
            "--reasoning-effort" => {
                reasoning_effort = Some(
                    args.next()
                        .ok_or_else(|| "--reasoning-effort requires a value".to_owned())?,
                );
            }
            "--background" => {
                background = true;
            }
            "--help" | "-h" => return Ok(None),
            other => {
                return Err(format!("unknown flag `{other}`\n\n{}", usage()));
            }
        }
    }

    let cases_path = cases_path.ok_or_else(|| format!("missing --cases\n\n{}", usage()))?;
    let report_path = report_path.ok_or_else(|| format!("missing --report\n\n{}", usage()))?;
    let backend = match backend.as_deref() {
        Some("file") => BackendConfig::File {
            root: root.ok_or_else(|| format!("--backend file requires --root\n\n{}", usage()))?,
        },
        Some("command") => BackendConfig::Command {
            program: program
                .ok_or_else(|| format!("--backend command requires --program\n\n{}", usage()))?,
            args: command_args,
            cwd,
        },
        Some("openai") => BackendConfig::OpenAi {
            model: model.unwrap_or_else(|| "gpt-5.4-2026-03-05".to_owned()),
            api_key_env: api_key_env.unwrap_or_else(|| "OPENAI_API_KEY".to_owned()),
            base_url,
            reasoning_effort,
            background,
        },
        Some(other) => {
            return Err(format!(
                "unsupported backend `{other}`; expected `file`, `command`, or `openai`\n\n{}",
                usage()
            ));
        }
        None => return Err(format!("missing --backend\n\n{}", usage())),
    };

    Ok(Some(CliConfig {
        cases_path,
        report_path,
        manifest_path,
        backend,
    }))
}

fn build_proposer(config: &BackendConfig) -> Box<dyn Proposer> {
    match config {
        BackendConfig::File { root } => Box::new(StructuredJsonProposer::new(
            FileStructuredJsonBackend::new(root),
        )),
        BackendConfig::Command { program, args, cwd } => {
            let mut backend = CommandStructuredJsonBackend::new(program).args(args.clone());
            if let Some(cwd) = cwd {
                backend = backend.cwd(cwd);
            }
            Box::new(StructuredJsonProposer::new(backend))
        }
        BackendConfig::OpenAi {
            model,
            api_key_env,
            base_url,
            reasoning_effort,
            background,
        } => {
            let api_key = load_api_key(api_key_env).unwrap_or_else(|| {
                panic!(
                    "environment variable `{api_key_env}` is not set and no `.env` file in the workspace provided it"
                )
            });
            let mut backend = match base_url {
                Some(base_url) => {
                    OpenAiResponsesBackend::with_base_url(api_key, model.clone(), base_url.clone())
                        .expect("openai backend should build")
                }
                None => OpenAiResponsesBackend::new(api_key, model.clone())
                    .expect("openai backend should build"),
            };
            if let Some(reasoning_effort) = reasoning_effort {
                backend = backend.with_reasoning_effort(reasoning_effort.clone());
            }
            if *background {
                backend = backend.with_background(true);
            }
            Box::new(StructuredJsonProposer::new(backend))
        }
    }
}

fn load_api_key(env_key: &str) -> Option<String> {
    if let Ok(value) = env::var(env_key) {
        return Some(value);
    }

    for candidate in dotenv_candidates() {
        if let Ok(raw) = std::fs::read_to_string(&candidate) {
            for line in raw.lines() {
                let trimmed = line.trim();
                if trimmed.is_empty() || trimmed.starts_with('#') {
                    continue;
                }
                let Some((key, value)) = trimmed.split_once('=') else {
                    continue;
                };
                if key.trim() == env_key {
                    return Some(value.trim().trim_matches('"').to_owned());
                }
            }
        }
    }

    None
}

fn dotenv_candidates() -> Vec<PathBuf> {
    let mut candidates = Vec::new();
    if let Ok(current_dir) = env::current_dir() {
        candidates.push(current_dir.join(".env"));
        if let Some(parent) = current_dir.parent() {
            candidates.push(parent.join(".env"));
        }
    }
    candidates
}

fn provider_descriptor(config: &BackendConfig) -> BenchmarkProviderDescriptor {
    match config {
        BackendConfig::File { .. } => BenchmarkProviderDescriptor {
            backend: "file".to_owned(),
            model: None,
            reasoning_effort: None,
            background: false,
            base_url: None,
        },
        BackendConfig::Command { .. } => BenchmarkProviderDescriptor {
            backend: "command".to_owned(),
            model: None,
            reasoning_effort: None,
            background: false,
            base_url: None,
        },
        BackendConfig::OpenAi {
            model,
            base_url,
            reasoning_effort,
            background,
            ..
        } => BenchmarkProviderDescriptor {
            backend: "openai".to_owned(),
            model: Some(model.clone()),
            reasoning_effort: reasoning_effort.clone(),
            background: *background,
            base_url: base_url.clone(),
        },
    }
}

fn load_manifest(path: Option<&PathBuf>) -> Result<BenchmarkRunManifest, Box<dyn Error>> {
    match path {
        Some(path) => Ok(load_benchmark_run_manifest(path)?),
        None => Ok(default_benchmark_run_manifest()),
    }
}

fn export_ro_crate(
    report_path: &PathBuf,
    versioned_report: &VersionedBenchmarkReport,
    cases_path: &PathBuf,
    manifest_path: Option<&PathBuf>,
    registry_path: &PathBuf,
) -> Result<PathBuf, Box<dyn Error>> {
    let bundle_dir = report_path.with_extension("ro-crate");
    fs::create_dir_all(&bundle_dir)?;

    let bundled_report = bundle_dir.join("report.json");
    let bundled_cases = bundle_dir.join("cases.json");
    let bundled_registry = bundle_dir.join("version_registry.json");
    let bundled_manifest = manifest_path.map(|_| bundle_dir.join("manifest.json"));

    write_versioned_benchmark_report(&bundled_report, versioned_report)?;
    fs::copy(cases_path, &bundled_cases)?;
    fs::copy(registry_path, &bundled_registry)?;
    if let (Some(source_manifest), Some(target_manifest)) =
        (manifest_path, bundled_manifest.as_ref())
    {
        fs::copy(source_manifest, target_manifest)?;
    }

    let mut graph = vec![
        serde_json::json!({
            "@id": "ro-crate-metadata.jsonld",
            "@type": "CreativeWork",
            "about": { "@id": "./" },
            "conformsTo": { "@id": "https://w3id.org/ro/crate/1.2" }
        }),
        serde_json::json!({
            "@id": "./",
            "@type": "Dataset",
            "name": format!(
                "Containment benchmark run {}",
                versioned_report.run.case_corpus.auto_revision
            ),
            "description": format!(
                "Versioned containment benchmark bundle for provider={} model={}",
                versioned_report.run.provider.backend,
                versioned_report
                    .run
                    .provider
                    .model
                    .clone()
                    .unwrap_or_else(|| "n/a".to_owned())
            ),
            "license": "MIT OR Apache-2.0",
            "datePublished": versioned_report.run.generated_at_iso8601_utc,
            "hasPart": [
                { "@id": "report.json" },
                { "@id": "cases.json" },
                { "@id": "version_registry.json" }
            ]
        }),
        serde_json::json!({
            "@id": "report.json",
            "@type": "File",
            "name": "Versioned benchmark report",
            "encodingFormat": "application/json"
        }),
        serde_json::json!({
            "@id": "cases.json",
            "@type": "File",
            "name": "Benchmark case corpus",
            "encodingFormat": "application/json"
        }),
        serde_json::json!({
            "@id": "version_registry.json",
            "@type": "File",
            "name": "Automatic version registry snapshot",
            "encodingFormat": "application/json"
        }),
    ];

    if bundled_manifest.is_some() {
        if let Some(root) = graph.get_mut(1).and_then(|value| value.as_object_mut()) {
            if let Some(parts) = root
                .get_mut("hasPart")
                .and_then(|value| value.as_array_mut())
            {
                parts.push(serde_json::json!({ "@id": "manifest.json" }));
            }
        }
        graph.push(serde_json::json!({
            "@id": "manifest.json",
            "@type": "File",
            "name": "Benchmark run manifest",
            "encodingFormat": "application/json"
        }));
    }

    fs::write(
        bundle_dir.join("ro-crate-metadata.jsonld"),
        serde_json::to_string_pretty(&serde_json::json!({
            "@context": "https://w3id.org/ro/crate/1.2/context",
            "@graph": graph,
        }))?,
    )?;

    Ok(bundle_dir)
}

fn main() -> Result<(), Box<dyn Error>> {
    let Some(config) = parse_cli().map_err(|message| {
        eprintln!("{message}");
        std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "invalid benchmark CLI args",
        )
    })?
    else {
        println!("{}", usage());
        return Ok(());
    };

    let cases = load_benchmark_cases(&config.cases_path)?;
    let proposer = build_proposer(&config.backend);
    let started_at_unix_s = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("time should move forward")
        .as_secs();
    let report = run_proposal_benchmark(&*proposer, &cases)?;
    let completed_at_unix_s = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("time should move forward")
        .as_secs();
    let manifest = load_manifest(config.manifest_path.as_ref())?;
    let workspace_root = env::current_dir()?;
    let registry_path = manifest
        .registry_path
        .clone()
        .unwrap_or_else(|| default_version_registry_path().to_owned());
    let registry_path = if PathBuf::from(&registry_path).is_absolute() {
        PathBuf::from(registry_path)
    } else {
        workspace_root.join(registry_path)
    };
    let mut registry = load_benchmark_version_registry(&registry_path)?;
    let run_identity = resolve_run_identity(
        &manifest,
        config.manifest_path.as_deref(),
        &workspace_root,
        &config.cases_path,
        &config.report_path,
        &provider_descriptor(&config.backend),
        capture_run_timing(started_at_unix_s, completed_at_unix_s),
        &mut registry,
    )?;
    write_benchmark_version_registry(&registry_path, &registry)?;
    let versioned_report = VersionedBenchmarkReport {
        run: run_identity,
        report,
    };
    write_versioned_benchmark_report(&config.report_path, &versioned_report)?;
    let ro_crate_dir = export_ro_crate(
        &config.report_path,
        &versioned_report,
        &config.cases_path,
        config.manifest_path.as_ref(),
        &registry_path,
    )?;

    println!(
        "benchmark complete: {} cases, commit={} ghost={} reject={} false_commit={} report={} crate={} methodology={} engine={} cases={}",
        versioned_report.report.metrics.total_cases,
        versioned_report.report.metrics.correct_commit_count,
        versioned_report.report.metrics.correct_ghost_count,
        versioned_report.report.metrics.correct_reject_count,
        versioned_report.report.metrics.false_commit_count,
        config.report_path.display(),
        ro_crate_dir.display(),
        versioned_report.run.methodology.auto_revision,
        versioned_report.run.engine.auto_revision,
        versioned_report.run.case_corpus.auto_revision,
    );

    Ok(())
}
