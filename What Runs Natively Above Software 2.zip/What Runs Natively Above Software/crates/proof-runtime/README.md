# proof-runtime

RFC-0002 implementation surface:
- typed `StepDecision` and `StepAction`
- sessioned runtime loop
- append-only step events
- terminal `ProofPack`
