//! RFC-0002 proof runtime: decision as typed transcript-bearing process.

use blake3::Hasher;
use constitution_gate::Verdict;
use epistemic_storage::{
    AtomStoreView, CanonicalCell, CellId, CellKind, CellMeta, CellStatus, ClosureClass,
    DoubtPolicy, EpistemicGraph, EpistemicStateStore, GhostCriticality, GhostId, GhostStatus,
    JustificationRef, PersistedCaseState, PersistedReceipt, PersistenceError, StatePointer,
};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use thiserror::Error;

const GROUNDING_LAMBDA: f64 = 0.72;
const COMMIT_GROUNDING_THRESHOLD: f64 = 0.55;
const GHOST_GROUNDING_THRESHOLD: f64 = 0.20;
const STRONG_CAUSAL_THRESHOLD: u8 = 80;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CaseId(pub String);

impl From<&str> for CaseId {
    fn from(value: &str) -> Self {
        Self(value.to_owned())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ContractHash(pub String);

impl From<&str> for ContractHash {
    fn from(value: &str) -> Self {
        Self(value.to_owned())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum StepDecision {
    Commit,
    Continue(StepAction),
    Reject(RejectReason),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum StepAction {
    Compute(ComputeAction),
    Materialize(MaterializeAction),
    Witness(WitnessAction),
    Epistemic(EpistemicAction),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ComputeAction {
    Propose {
        proposer_id: String,
        input_set_cid: String,
    },
    RunExpert {
        expert_id: String,
        input_set_cid: String,
    },
    RecomputePath {
        derivation_cid: String,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MaterializeAction {
    RehydrateAtom { cid: String },
    RetrieveEvidence { query_cid: String, top_k: u8 },
    LoadModule { module_id: String },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum WitnessAction {
    AskUserBit {
        question_id: String,
        left: String,
        right: String,
    },
    AskUserField {
        field_id: String,
    },
    GetTime {
        oracle_id: String,
    },
    FetchExternalAtom {
        locator: String,
        expected_cid: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum EpistemicAction {
    AssessClosure {
        conclusion_cell_id: CellId,
        graph: EpistemicGraph,
    },
    ReassessClosure {
        conclusion_cell_id: CellId,
        previous_verdict: Verdict,
        graph: EpistemicGraph,
    },
    ResolveGhostFromLatestWitness {
        ghost_id: GhostId,
        conclusion_cell_id: CellId,
        graph: EpistemicGraph,
    },
    ResolveGhostFromLatestExternalAnchor {
        ghost_id: GhostId,
        conclusion_cell_id: CellId,
        graph: EpistemicGraph,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct ActionCost {
    pub gas: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ProofMode {
    FullSelfContained,
    AnchoredImmutableRefs,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProposalRef {
    pub cid: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Session {
    pub case_id: CaseId,
    pub contract_hash: ContractHash,
    pub proof_mode: ProofMode,
    pub initial_budget: u64,
    pub budget_remaining: u64,
    pub state_root: String,
    pub atoms: AtomStoreView,
    pub transcript_head: Option<String>,
    pub event_count: u64,
    pub current_proposal: Option<ProposalRef>,
    pub last_witness_cid: Option<String>,
    pub last_external_anchor: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SessionView {
    pub case_id: CaseId,
    pub contract_hash: ContractHash,
    pub budget_remaining: u64,
    pub state_root: String,
    pub event_count: u64,
    pub last_witness_cid: Option<String>,
    pub last_external_anchor: Option<String>,
}

impl From<&Session> for SessionView {
    fn from(value: &Session) -> Self {
        Self {
            case_id: value.case_id.clone(),
            contract_hash: value.contract_hash.clone(),
            budget_remaining: value.budget_remaining,
            state_root: value.state_root.clone(),
            event_count: value.event_count,
            last_witness_cid: value.last_witness_cid.clone(),
            last_external_anchor: value.last_external_anchor.clone(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DeterminismProfile {
    pub deterministic: bool,
    pub bounded_divergence: bool,
}

pub trait Contract {
    fn eval_step(&self, session: &SessionView) -> StepDecision;
    fn cost_of(&self, action: &StepAction, session: &SessionView) -> ActionCost;
    fn determinism_profile(&self) -> DeterminismProfile;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum StepReceipt {
    Computed {
        receipt_cid: String,
    },
    AtomRehydrated {
        cid: String,
    },
    ExternalAtomFetched {
        cid: String,
        locator: String,
    },
    WitnessProvided {
        witness_cid: String,
    },
    GhostResolved {
        ghost_id: GhostId,
        resolution_ref: JustificationRef,
        resulting_status: GhostStatus,
        resolution_cell_id: CellId,
        required_for: Vec<CellId>,
        graph: EpistemicGraph,
    },
    EpistemicClosureEvaluated {
        conclusion_cell_id: CellId,
        grounding_ratio_bp: u16,
        constitutional_verdict: Verdict,
        pending_ghosts: Vec<GhostId>,
        reasons: Vec<String>,
    },
    EpistemicClosureTransition {
        conclusion_cell_id: CellId,
        from_verdict: Verdict,
        to_verdict: Verdict,
        grounding_ratio_bp: u16,
    },
}

pub trait RuntimeOps {
    fn execute_action(
        &mut self,
        session: &Session,
        action: &StepAction,
    ) -> Result<(StepReceipt, String), RuntimeError>;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StepEvent {
    pub case_id: CaseId,
    pub index: u64,
    pub action: StepAction,
    pub receipt: StepReceipt,
    pub gas_cost: u64,
    pub budget_before: u64,
    pub budget_after: u64,
    pub prev_event_hash: Option<String>,
    pub event_hash: String,
    pub state_root_after: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum FinalOutcome {
    Commit,
    Reject(RejectReason),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RejectReason {
    OutOfBudget,
    ContractRejected(String),
    RuntimeFailure(String),
    StepLimitExceeded,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProofPack {
    pub case_id: CaseId,
    pub contract_hash: ContractHash,
    pub proof_mode: ProofMode,
    pub events: Vec<StepEvent>,
    pub final_outcome: FinalOutcome,
    pub constitutional_verdict: Verdict,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum RuntimeError {
    #[error("out of budget")]
    OutOfBudget,
    #[error("runtime action failed: {0}")]
    ActionFailed(String),
}

#[derive(Debug, Error)]
pub enum ReplayPersistenceError {
    #[error("storage error: {0}")]
    Storage(#[from] PersistenceError),
    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    #[error("missing replay seed for case `{0}`")]
    MissingReplaySeed(String),
    #[error("missing runtime session payload for case `{0}`")]
    MissingSessionPayload(String),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReplaySeed {
    pub session: Session,
    pub graph: EpistemicGraph,
    pub pointers: Vec<StatePointer>,
    pub graph_version: u64,
    pub saved_at: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReplayAuditBundle {
    pub seed: ReplaySeed,
    pub receipts: Vec<PersistedReceipt>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReplayEquivalenceReport {
    pub case_id: CaseId,
    pub verdict_equivalent: bool,
    pub ghost_state_equivalent: bool,
    pub pointer_eligibility_equivalent: bool,
    pub transition_equivalent: bool,
    pub grounding_equivalent: bool,
    pub replay_divergence_count: u32,
    pub divergence_reasons: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SpawnOmissionReason {
    PremiseWithoutAnchor,
    StrongCausalJumpWithoutEvidence,
    ContradictionWithoutResolution,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SpawnOmission {
    pub cell_id: CellId,
    pub reason: SpawnOmissionReason,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ClosureVerdict {
    Commit {
        grounding_ratio: f64,
    },
    Ghost {
        grounding_ratio: f64,
        pending_ghosts: Vec<GhostId>,
    },
    Reject {
        grounding_ratio: f64,
        reasons: Vec<String>,
    },
}

fn grounding_to_basis_points(grounding_ratio: f64) -> u16 {
    let scaled = (grounding_ratio.clamp(0.0, 1.0) * 10_000.0).round();
    if scaled <= 0.0 {
        0
    } else if scaled >= f64::from(u16::MAX) {
        u16::MAX
    } else {
        scaled as u16
    }
}

fn receipt_kind(receipt: &StepReceipt) -> &'static str {
    match receipt {
        StepReceipt::Computed { .. } => "Computed",
        StepReceipt::AtomRehydrated { .. } => "AtomRehydrated",
        StepReceipt::ExternalAtomFetched { .. } => "ExternalAtomFetched",
        StepReceipt::WitnessProvided { .. } => "WitnessProvided",
        StepReceipt::GhostResolved { .. } => "GhostResolved",
        StepReceipt::EpistemicClosureEvaluated { .. } => "EpistemicClosureEvaluated",
        StepReceipt::EpistemicClosureTransition { .. } => "EpistemicClosureTransition",
    }
}

fn receipt_grounding_bp(receipt: &StepReceipt) -> Option<u16> {
    match receipt {
        StepReceipt::EpistemicClosureEvaluated {
            grounding_ratio_bp, ..
        }
        | StepReceipt::EpistemicClosureTransition {
            grounding_ratio_bp, ..
        } => Some(*grounding_ratio_bp),
        _ => None,
    }
}

fn receipt_is_transitional(receipt: &StepReceipt) -> bool {
    matches!(
        receipt,
        StepReceipt::GhostResolved { .. }
            | StepReceipt::EpistemicClosureEvaluated { .. }
            | StepReceipt::EpistemicClosureTransition { .. }
    )
}

fn latest_grounding_from_pack(pack: &ProofPack) -> Option<u16> {
    pack.events
        .iter()
        .rev()
        .find_map(|event| receipt_grounding_bp(&event.receipt))
}

fn transition_receipts(pack: &ProofPack) -> Vec<StepReceipt> {
    pack.events
        .iter()
        .filter(|event| receipt_is_transitional(&event.receipt))
        .map(|event| event.receipt.clone())
        .collect()
}

fn ghost_state_signature(
    graph: &EpistemicGraph,
) -> Vec<(GhostId, GhostStatus, Option<JustificationRef>)> {
    graph
        .ghosts
        .values()
        .map(|ghost| {
            (
                ghost.id.clone(),
                ghost.status.clone(),
                ghost.resolution_ref.clone(),
            )
        })
        .collect()
}

pub fn persist_replay_seed(
    store: &dyn EpistemicStateStore,
    session: &Session,
    graph: &EpistemicGraph,
    pointers: &[StatePointer],
    saved_at: u64,
) -> Result<ReplaySeed, ReplayPersistenceError> {
    let snapshot = store.save_graph(&session.case_id.0, graph, saved_at)?;
    store.save_case_state(&PersistedCaseState {
        case_id: session.case_id.0.clone(),
        pointers: pointers.to_vec(),
        graph_version: Some(snapshot.version),
        session_json: Some(serde_json::to_string(session)?),
        manager_state_json: None,
        state_hash: String::new(),
        updated_at: saved_at,
    })?;

    Ok(ReplaySeed {
        session: session.clone(),
        graph: snapshot.graph,
        pointers: pointers.to_vec(),
        graph_version: snapshot.version,
        saved_at,
    })
}

pub fn load_replay_seed(
    store: &dyn EpistemicStateStore,
    case_id: &CaseId,
) -> Result<ReplaySeed, ReplayPersistenceError> {
    let snapshot = store
        .load_graph(&case_id.0)?
        .ok_or_else(|| ReplayPersistenceError::MissingReplaySeed(case_id.0.clone()))?;
    let case_state = store
        .load_case_state(&case_id.0)?
        .ok_or_else(|| ReplayPersistenceError::MissingReplaySeed(case_id.0.clone()))?;
    let session_json = case_state
        .session_json
        .ok_or_else(|| ReplayPersistenceError::MissingSessionPayload(case_id.0.clone()))?;
    let session = serde_json::from_str(&session_json)?;

    Ok(ReplaySeed {
        session,
        graph: snapshot.graph,
        pointers: case_state.pointers,
        graph_version: snapshot.version,
        saved_at: snapshot.saved_at,
    })
}

pub fn persist_proof_pack_receipts(
    store: &dyn EpistemicStateStore,
    pack: &ProofPack,
) -> Result<(), ReplayPersistenceError> {
    for event in &pack.events {
        store.append_receipt(&PersistedReceipt {
            case_id: pack.case_id.0.clone(),
            sequence: event.index,
            receipt_kind: receipt_kind(&event.receipt).to_owned(),
            payload_json: serde_json::to_string(event)?,
            payload_hash: String::new(),
            prev_record_hash: None,
            record_hash: String::new(),
            recorded_at: event.index,
        })?;
    }
    Ok(())
}

pub fn load_replay_audit_bundle(
    store: &dyn EpistemicStateStore,
    case_id: &CaseId,
) -> Result<ReplayAuditBundle, ReplayPersistenceError> {
    Ok(ReplayAuditBundle {
        seed: load_replay_seed(store, case_id)?,
        receipts: store.load_receipts(&case_id.0)?,
    })
}

#[must_use]
pub fn compare_replay_equivalence(
    live_pack: &ProofPack,
    replay_pack: &ProofPack,
    live_graph: &EpistemicGraph,
    replay_graph: &EpistemicGraph,
    live_pointers: &[StatePointer],
    replay_pointers: &[StatePointer],
) -> ReplayEquivalenceReport {
    let verdict_equivalent = live_pack.final_outcome == replay_pack.final_outcome
        && live_pack.constitutional_verdict == replay_pack.constitutional_verdict;
    let ghost_state_equivalent =
        ghost_state_signature(live_graph) == ghost_state_signature(replay_graph);
    let pointer_eligibility_equivalent = live_pointers == replay_pointers;
    let transition_equivalent = transition_receipts(live_pack) == transition_receipts(replay_pack);
    let grounding_equivalent =
        latest_grounding_from_pack(live_pack) == latest_grounding_from_pack(replay_pack);

    let mut divergence_reasons = Vec::new();
    if !verdict_equivalent {
        divergence_reasons.push("verdict_mismatch".to_owned());
    }
    if !ghost_state_equivalent {
        divergence_reasons.push("ghost_state_mismatch".to_owned());
    }
    if !pointer_eligibility_equivalent {
        divergence_reasons.push("pointer_eligibility_mismatch".to_owned());
    }
    if !transition_equivalent {
        divergence_reasons.push("transition_mismatch".to_owned());
    }
    if !grounding_equivalent {
        divergence_reasons.push("grounding_mismatch".to_owned());
    }

    ReplayEquivalenceReport {
        case_id: live_pack.case_id.clone(),
        verdict_equivalent,
        ghost_state_equivalent,
        pointer_eligibility_equivalent,
        transition_equivalent,
        grounding_equivalent,
        replay_divergence_count: divergence_reasons.len() as u32,
        divergence_reasons,
    }
}

fn closure_to_constitutional_verdict(verdict: &ClosureVerdict) -> Verdict {
    match verdict {
        ClosureVerdict::Commit { .. } => Verdict::Commit,
        ClosureVerdict::Ghost { .. } => Verdict::Ghost,
        ClosureVerdict::Reject { .. } => Verdict::Reject,
    }
}

fn materialize_resolution_cell(
    graph: &mut EpistemicGraph,
    ghost_id: &GhostId,
    resolution_ref: &JustificationRef,
    created_at: u64,
) -> Option<CellId> {
    let ghost = graph.ghost(ghost_id)?.clone();
    let resolution_cell_id = CellId(format!("resolution:{}", ghost_id.0));
    if !graph.cells.contains_key(&resolution_cell_id) {
        graph.insert_cell(CanonicalCell {
            id: resolution_cell_id.clone(),
            kind: CellKind::Resolution,
            content: format!("resolution for {}", ghost.reason),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![resolution_ref.clone()],
            if_doubt: DoubtPolicy::AskWitness,
            created_at,
            meta: CellMeta {
                provenance: vec![
                    "runtime.epistemic_resolution".to_owned(),
                    format!("opened_from:{}", ghost.opened_from.0),
                ],
                closure_class: ClosureClass::Conditional,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
    }

    let mut targets = ghost.required_for.clone();
    targets.push(ghost.opened_from);
    for target in targets {
        if let Some(cell) = graph.cells.get_mut(&target) {
            if !cell
                .confirmed_by
                .contains(&JustificationRef::Cell(resolution_cell_id.clone()))
            {
                cell.confirmed_by
                    .push(JustificationRef::Cell(resolution_cell_id.clone()));
            }
            if cell.status == CellStatus::Doubt {
                cell.status = CellStatus::Ok;
            }
        }
    }

    Some(resolution_cell_id)
}

#[must_use]
pub fn receipt_for_closure(conclusion_cell_id: &CellId, graph: &EpistemicGraph) -> StepReceipt {
    match closure_guard(conclusion_cell_id, graph) {
        ClosureVerdict::Commit { grounding_ratio } => StepReceipt::EpistemicClosureEvaluated {
            conclusion_cell_id: conclusion_cell_id.clone(),
            grounding_ratio_bp: grounding_to_basis_points(grounding_ratio),
            constitutional_verdict: Verdict::Commit,
            pending_ghosts: Vec::new(),
            reasons: Vec::new(),
        },
        ClosureVerdict::Ghost {
            grounding_ratio,
            pending_ghosts,
        } => StepReceipt::EpistemicClosureEvaluated {
            conclusion_cell_id: conclusion_cell_id.clone(),
            grounding_ratio_bp: grounding_to_basis_points(grounding_ratio),
            constitutional_verdict: Verdict::Ghost,
            pending_ghosts,
            reasons: Vec::new(),
        },
        ClosureVerdict::Reject {
            grounding_ratio,
            reasons,
        } => StepReceipt::EpistemicClosureEvaluated {
            conclusion_cell_id: conclusion_cell_id.clone(),
            grounding_ratio_bp: grounding_to_basis_points(grounding_ratio),
            constitutional_verdict: Verdict::Reject,
            pending_ghosts: Vec::new(),
            reasons,
        },
    }
}

fn execute_epistemic_action(
    session: &Session,
    action: &EpistemicAction,
) -> (Vec<StepReceipt>, String) {
    match action {
        EpistemicAction::AssessClosure {
            conclusion_cell_id,
            graph,
        } => (
            vec![receipt_for_closure(conclusion_cell_id, graph)],
            session.state_root.clone(),
        ),
        EpistemicAction::ReassessClosure {
            conclusion_cell_id,
            previous_verdict,
            graph,
        } => {
            let next = closure_guard(conclusion_cell_id, graph);
            let next_verdict = closure_to_constitutional_verdict(&next);
            let grounding_ratio_bp =
                grounding_to_basis_points(compute_grounding_ratio(conclusion_cell_id, graph));
            let receipt = if &next_verdict == previous_verdict {
                receipt_for_closure(conclusion_cell_id, graph)
            } else {
                StepReceipt::EpistemicClosureTransition {
                    conclusion_cell_id: conclusion_cell_id.clone(),
                    from_verdict: *previous_verdict,
                    to_verdict: next_verdict,
                    grounding_ratio_bp,
                }
            };
            (vec![receipt], session.state_root.clone())
        }
        EpistemicAction::ResolveGhostFromLatestWitness {
            ghost_id,
            conclusion_cell_id: _,
            graph,
        } => {
            let mut updated = graph.clone();
            let witness_cid = session
                .last_witness_cid
                .clone()
                .unwrap_or_else(|| "missing:witness".to_owned());
            let resolution_ref = JustificationRef::Anchor(format!("witness:{witness_cid}"));
            let required_for = updated
                .ghost(ghost_id)
                .map(|ghost| ghost.required_for.clone())
                .unwrap_or_default();
            let resolution_cell_id = materialize_resolution_cell(
                &mut updated,
                ghost_id,
                &resolution_ref,
                session.event_count + 1,
            )
            .unwrap_or_else(|| CellId(format!("resolution-missing:{}", ghost_id.0)));
            let resulting_status = if updated
                .resolve_ghost(ghost_id, resolution_ref.clone())
                .is_ok()
            {
                GhostStatus::Resolved
            } else {
                GhostStatus::Open
            };
            (
                vec![StepReceipt::GhostResolved {
                    ghost_id: ghost_id.clone(),
                    resolution_ref,
                    resulting_status,
                    resolution_cell_id,
                    required_for,
                    graph: updated,
                }],
                session.state_root.clone(),
            )
        }
        EpistemicAction::ResolveGhostFromLatestExternalAnchor {
            ghost_id,
            conclusion_cell_id: _,
            graph,
        } => {
            let mut updated = graph.clone();
            let anchor = session
                .last_external_anchor
                .clone()
                .unwrap_or_else(|| "missing:external_anchor".to_owned());
            let resolution_ref = JustificationRef::Anchor(anchor);
            let required_for = updated
                .ghost(ghost_id)
                .map(|ghost| ghost.required_for.clone())
                .unwrap_or_default();
            let resolution_cell_id = materialize_resolution_cell(
                &mut updated,
                ghost_id,
                &resolution_ref,
                session.event_count + 1,
            )
            .unwrap_or_else(|| CellId(format!("resolution-missing:{}", ghost_id.0)));
            let resulting_status = if updated
                .resolve_ghost(ghost_id, resolution_ref.clone())
                .is_ok()
            {
                GhostStatus::Resolved
            } else {
                GhostStatus::Open
            };
            (
                vec![StepReceipt::GhostResolved {
                    ghost_id: ghost_id.clone(),
                    resolution_ref,
                    resulting_status,
                    resolution_cell_id,
                    required_for,
                    graph: updated,
                }],
                session.state_root.clone(),
            )
        }
    }
}

#[must_use]
pub fn compute_grounding_ratio(cell_id: &CellId, graph: &EpistemicGraph) -> f64 {
    fn visit(cell_id: &CellId, graph: &EpistemicGraph, active: &mut BTreeSet<CellId>) -> f64 {
        if !active.insert(cell_id.clone()) {
            return 0.0;
        }

        let Some(cell) = graph.cell(cell_id) else {
            active.remove(cell_id);
            return 0.0;
        };

        let mut support_paths = BTreeMap::<String, f64>::new();
        for justification in &cell.confirmed_by {
            match justification {
                JustificationRef::Anchor(anchor_id) => {
                    support_paths.insert(format!("anchor:{anchor_id}"), 1.0);
                }
                JustificationRef::Cell(parent_id) => {
                    let parent = visit(parent_id, graph, active);
                    if parent > 0.0 {
                        support_paths
                            .insert(format!("cell:{}", parent_id.0), GROUNDING_LAMBDA * parent);
                    }
                }
                JustificationRef::Ghost(_) => {}
            }
        }

        for dependency in &cell.depends_on {
            let dependency_score = visit(dependency, graph, active);
            if dependency_score > 0.0 {
                support_paths.insert(
                    format!("cell:{}", dependency.0),
                    GROUNDING_LAMBDA * dependency_score,
                );
            }
        }

        active.remove(cell_id);
        support_paths
            .into_values()
            .fold(0.0, |acc, value| (acc + value).min(1.0))
    }

    visit(cell_id, graph, &mut BTreeSet::new())
}

fn lineage_of(cell_id: &CellId, graph: &EpistemicGraph, out: &mut BTreeSet<CellId>) {
    if !out.insert(cell_id.clone()) {
        return;
    }

    if let Some(cell) = graph.cell(cell_id) {
        for dependency in &cell.depends_on {
            lineage_of(dependency, graph, out);
        }
        for justification in &cell.confirmed_by {
            if let JustificationRef::Cell(parent_id) = justification {
                lineage_of(parent_id, graph, out);
            }
        }
    }
}

fn has_non_ghost_justification(cell_id: &CellId, graph: &EpistemicGraph) -> bool {
    graph
        .cell(cell_id)
        .map(|cell| {
            cell.confirmed_by
                .iter()
                .any(|justification| match justification {
                    JustificationRef::Anchor(_) => true,
                    JustificationRef::Cell(parent_id) => {
                        compute_grounding_ratio(parent_id, graph) > 0.0
                    }
                    JustificationRef::Ghost(_) => false,
                })
        })
        .unwrap_or(false)
}

fn has_resolution_for(cell_id: &CellId, graph: &EpistemicGraph) -> bool {
    graph.cells.values().any(|cell| {
        cell.kind == CellKind::Resolution
            && (cell
                .depends_on
                .iter()
                .any(|dependency| dependency == cell_id)
                || cell
                    .meta
                    .contradiction_with
                    .iter()
                    .any(|dependency| dependency == cell_id))
    })
}

#[must_use]
pub fn detect_spawn_omission(graph: &EpistemicGraph) -> Vec<SpawnOmission> {
    let mut omissions = Vec::new();

    for cell in graph.cells.values() {
        let used_as_premise = !graph.dependents_of(&cell.id).is_empty();
        let grounding = compute_grounding_ratio(&cell.id, graph);
        let open_ghost = graph.has_open_ghost_for(&cell.id);

        if used_as_premise && grounding == 0.0 && !open_ghost {
            omissions.push(SpawnOmission {
                cell_id: cell.id.clone(),
                reason: SpawnOmissionReason::PremiseWithoutAnchor,
            });
        }

        if cell.kind == CellKind::Inference
            && cell.meta.causal_strength >= STRONG_CAUSAL_THRESHOLD
            && !has_non_ghost_justification(&cell.id, graph)
            && !open_ghost
        {
            omissions.push(SpawnOmission {
                cell_id: cell.id.clone(),
                reason: SpawnOmissionReason::StrongCausalJumpWithoutEvidence,
            });
        }

        if !cell.meta.contradiction_with.is_empty()
            && cell.kind != CellKind::Resolution
            && !has_resolution_for(&cell.id, graph)
            && !open_ghost
        {
            omissions.push(SpawnOmission {
                cell_id: cell.id.clone(),
                reason: SpawnOmissionReason::ContradictionWithoutResolution,
            });
        }
    }

    omissions
}

#[must_use]
pub fn closure_guard(cell_id: &CellId, graph: &EpistemicGraph) -> ClosureVerdict {
    let grounding_ratio = compute_grounding_ratio(cell_id, graph);
    let omissions = detect_spawn_omission(graph);
    let mut lineage = BTreeSet::new();
    lineage_of(cell_id, graph, &mut lineage);

    let relevant_omissions: Vec<_> = omissions
        .into_iter()
        .filter(|omission| lineage.contains(&omission.cell_id))
        .collect();
    if !relevant_omissions.is_empty() {
        return ClosureVerdict::Reject {
            grounding_ratio,
            reasons: relevant_omissions
                .into_iter()
                .map(|omission| format!("{:?}:{}", omission.reason, omission.cell_id.0))
                .collect(),
        };
    }

    let pending_critical_ghosts: Vec<_> = graph
        .ghosts
        .values()
        .filter(|ghost| {
            ghost.status == GhostStatus::Open
                && matches!(ghost.criticality, GhostCriticality::High)
                && (lineage.contains(&ghost.opened_from)
                    || ghost
                        .required_for
                        .iter()
                        .any(|required| lineage.contains(required)))
        })
        .map(|ghost| ghost.id.clone())
        .collect();

    if grounding_ratio >= COMMIT_GROUNDING_THRESHOLD && pending_critical_ghosts.is_empty() {
        return ClosureVerdict::Commit { grounding_ratio };
    }

    if grounding_ratio >= GHOST_GROUNDING_THRESHOLD || !pending_critical_ghosts.is_empty() {
        return ClosureVerdict::Ghost {
            grounding_ratio,
            pending_ghosts: pending_critical_ghosts,
        };
    }

    ClosureVerdict::Reject {
        grounding_ratio,
        reasons: vec!["grounding_collapsed".to_owned()],
    }
}

#[doc = "UNSTABLE_V0"]
pub struct Runtime {
    pub max_steps: u64,
}

impl Runtime {
    #[must_use]
    pub fn new(max_steps: u64) -> Self {
        Self { max_steps }
    }

    pub fn run(
        &self,
        mut session: Session,
        contract: &dyn Contract,
        ops: &mut dyn RuntimeOps,
    ) -> ProofPack {
        let mut events = Vec::new();

        for _ in 0..self.max_steps {
            let view = SessionView::from(&session);
            match contract.eval_step(&view) {
                StepDecision::Commit => {
                    return ProofPack {
                        case_id: session.case_id.clone(),
                        contract_hash: session.contract_hash.clone(),
                        proof_mode: session.proof_mode,
                        events,
                        final_outcome: FinalOutcome::Commit,
                        constitutional_verdict: Verdict::Commit,
                    };
                }
                StepDecision::Reject(reason) => {
                    return ProofPack {
                        case_id: session.case_id.clone(),
                        contract_hash: session.contract_hash.clone(),
                        proof_mode: session.proof_mode,
                        events,
                        final_outcome: FinalOutcome::Reject(reason),
                        constitutional_verdict: Verdict::Reject,
                    };
                }
                StepDecision::Continue(action) => {
                    let cost = contract.cost_of(&action, &view);
                    if cost.gas > session.budget_remaining {
                        return ProofPack {
                            case_id: session.case_id.clone(),
                            contract_hash: session.contract_hash.clone(),
                            proof_mode: session.proof_mode,
                            events,
                            final_outcome: FinalOutcome::Reject(RejectReason::OutOfBudget),
                            constitutional_verdict: Verdict::Reject,
                        };
                    }
                    let budget_before = session.budget_remaining;
                    session.budget_remaining -= cost.gas;
                    let (receipts, new_state_root) = match &action {
                        StepAction::Epistemic(epistemic_action) => {
                            execute_epistemic_action(&session, epistemic_action)
                        }
                        _ => match ops.execute_action(&session, &action) {
                            Ok(ok) => (vec![ok.0], ok.1),
                            Err(err) => {
                                return ProofPack {
                                    case_id: session.case_id.clone(),
                                    contract_hash: session.contract_hash.clone(),
                                    proof_mode: session.proof_mode,
                                    events,
                                    final_outcome: FinalOutcome::Reject(
                                        RejectReason::RuntimeFailure(err.to_string()),
                                    ),
                                    constitutional_verdict: Verdict::Reject,
                                };
                            }
                        },
                    };
                    let budget_after = session.budget_remaining;
                    session.state_root = new_state_root.clone();
                    for receipt in receipts {
                        session.event_count += 1;
                        match &receipt {
                            StepReceipt::WitnessProvided { witness_cid } => {
                                session.last_witness_cid = Some(witness_cid.clone());
                            }
                            StepReceipt::ExternalAtomFetched { cid, locator } => {
                                session.last_external_anchor =
                                    Some(format!("external:{locator}:{cid}"));
                            }
                            _ => {}
                        }
                        let prev_event_hash =
                            events.last().map(|ev: &StepEvent| ev.event_hash.clone());
                        let event_hash = hash_event(&EventHashInput {
                            case_id: &session.case_id,
                            index: session.event_count,
                            action: &action,
                            receipt: &receipt,
                            gas_cost: cost.gas,
                            budget_before,
                            budget_after,
                            prev_hash: prev_event_hash.as_deref(),
                            state_root_after: &new_state_root,
                        });
                        session.transcript_head = Some(event_hash.clone());
                        events.push(StepEvent {
                            case_id: session.case_id.clone(),
                            index: session.event_count,
                            action: action.clone(),
                            receipt,
                            gas_cost: cost.gas,
                            budget_before,
                            budget_after,
                            prev_event_hash,
                            event_hash,
                            state_root_after: new_state_root.clone(),
                        });
                    }
                }
            }
        }

        ProofPack {
            case_id: session.case_id,
            contract_hash: session.contract_hash,
            proof_mode: session.proof_mode,
            events,
            final_outcome: FinalOutcome::Reject(RejectReason::StepLimitExceeded),
            constitutional_verdict: Verdict::Ghost,
        }
    }
}

struct EventHashInput<'a> {
    case_id: &'a CaseId,
    index: u64,
    action: &'a StepAction,
    receipt: &'a StepReceipt,
    gas_cost: u64,
    budget_before: u64,
    budget_after: u64,
    prev_hash: Option<&'a str>,
    state_root_after: &'a str,
}

fn hash_event(input: &EventHashInput<'_>) -> String {
    let mut hasher = Hasher::new();
    let payload = serde_json::json!({
        "case_id": input.case_id,
        "index": input.index,
        "action": input.action,
        "receipt": input.receipt,
        "gas_cost": input.gas_cost,
        "budget_before": input.budget_before,
        "budget_after": input.budget_after,
        "prev_hash": input.prev_hash,
        "state_root_after": input.state_root_after,
    });
    let canonical = serde_json::to_vec(&payload).expect("payload is serializable");
    hasher.update(&canonical);
    hex::encode(hasher.finalize().as_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;
    use epistemic_storage::{
        CanonicalCell, CellMeta, CellStatus, ClosureClass, DoubtPolicy, EpistemicGraph,
        GhostRecord, SqliteEpistemicStore,
    };

    struct TestContract;

    impl Contract for TestContract {
        fn eval_step(&self, session: &SessionView) -> StepDecision {
            if session.event_count >= 1 {
                StepDecision::Commit
            } else {
                StepDecision::Continue(StepAction::Compute(ComputeAction::Propose {
                    proposer_id: "p".to_owned(),
                    input_set_cid: "i".to_owned(),
                }))
            }
        }

        fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
            ActionCost { gas: 5 }
        }

        fn determinism_profile(&self) -> DeterminismProfile {
            DeterminismProfile {
                deterministic: true,
                bounded_divergence: false,
            }
        }
    }

    struct TestOps;

    impl RuntimeOps for TestOps {
        fn execute_action(
            &mut self,
            _session: &Session,
            _action: &StepAction,
        ) -> Result<(StepReceipt, String), RuntimeError> {
            Ok((
                StepReceipt::Computed {
                    receipt_cid: "r1".to_owned(),
                },
                "state_after_1".to_owned(),
            ))
        }
    }

    struct TwoStepContract;

    impl Contract for TwoStepContract {
        fn eval_step(&self, session: &SessionView) -> StepDecision {
            if session.event_count < 2 {
                StepDecision::Continue(StepAction::Compute(ComputeAction::RunExpert {
                    expert_id: "expert".to_owned(),
                    input_set_cid: format!("set-{}", session.event_count),
                }))
            } else {
                StepDecision::Commit
            }
        }

        fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
            ActionCost { gas: 1 }
        }

        fn determinism_profile(&self) -> DeterminismProfile {
            DeterminismProfile {
                deterministic: true,
                bounded_divergence: false,
            }
        }
    }

    struct CountingOps(u64);

    impl RuntimeOps for CountingOps {
        fn execute_action(
            &mut self,
            _session: &Session,
            _action: &StepAction,
        ) -> Result<(StepReceipt, String), RuntimeError> {
            self.0 += 1;
            Ok((
                StepReceipt::Computed {
                    receipt_cid: format!("r{}", self.0),
                },
                format!("state_after_{}", self.0),
            ))
        }
    }

    struct WitnessThenResolveContract {
        graph: EpistemicGraph,
        ghost_id: GhostId,
        conclusion_id: CellId,
    }

    impl Contract for WitnessThenResolveContract {
        fn eval_step(&self, session: &SessionView) -> StepDecision {
            match session.event_count {
                0 => StepDecision::Continue(StepAction::Witness(WitnessAction::AskUserField {
                    field_id: "bank_statement".to_owned(),
                })),
                1 => StepDecision::Continue(StepAction::Epistemic(
                    EpistemicAction::ResolveGhostFromLatestWitness {
                        ghost_id: self.ghost_id.clone(),
                        conclusion_cell_id: self.conclusion_id.clone(),
                        graph: self.graph.clone(),
                    },
                )),
                _ => StepDecision::Commit,
            }
        }

        fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
            ActionCost { gas: 1 }
        }

        fn determinism_profile(&self) -> DeterminismProfile {
            DeterminismProfile {
                deterministic: true,
                bounded_divergence: false,
            }
        }
    }

    struct ExternalThenResolveContract {
        graph: EpistemicGraph,
        ghost_id: GhostId,
        conclusion_id: CellId,
    }

    impl Contract for ExternalThenResolveContract {
        fn eval_step(&self, session: &SessionView) -> StepDecision {
            match session.event_count {
                0 => {
                    StepDecision::Continue(StepAction::Witness(WitnessAction::FetchExternalAtom {
                        locator: "https://bank.example/statement".to_owned(),
                        expected_cid: Some("cid:bank:statement".to_owned()),
                    }))
                }
                1 => StepDecision::Continue(StepAction::Epistemic(
                    EpistemicAction::ResolveGhostFromLatestExternalAnchor {
                        ghost_id: self.ghost_id.clone(),
                        conclusion_cell_id: self.conclusion_id.clone(),
                        graph: self.graph.clone(),
                    },
                )),
                _ => StepDecision::Commit,
            }
        }

        fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
            ActionCost { gas: 1 }
        }

        fn determinism_profile(&self) -> DeterminismProfile {
            DeterminismProfile {
                deterministic: true,
                bounded_divergence: false,
            }
        }
    }

    struct WitnessOps;

    impl RuntimeOps for WitnessOps {
        fn execute_action(
            &mut self,
            _session: &Session,
            action: &StepAction,
        ) -> Result<(StepReceipt, String), RuntimeError> {
            match action {
                StepAction::Witness(WitnessAction::AskUserField { field_id }) => Ok((
                    StepReceipt::WitnessProvided {
                        witness_cid: format!("witness:{field_id}:cid"),
                    },
                    "state_after_witness".to_owned(),
                )),
                StepAction::Witness(WitnessAction::FetchExternalAtom {
                    locator,
                    expected_cid,
                }) => Ok((
                    StepReceipt::ExternalAtomFetched {
                        cid: expected_cid
                            .clone()
                            .unwrap_or_else(|| "cid:fetched".to_owned()),
                        locator: locator.clone(),
                    },
                    "state_after_external_fetch".to_owned(),
                )),
                _ => Err(RuntimeError::ActionFailed(
                    "unexpected action for witness ops".to_owned(),
                )),
            }
        }
    }

    struct EpistemicContract {
        graph: EpistemicGraph,
        conclusion_id: CellId,
    }

    impl Contract for EpistemicContract {
        fn eval_step(&self, session: &SessionView) -> StepDecision {
            if session.event_count >= 1 {
                StepDecision::Commit
            } else {
                StepDecision::Continue(StepAction::Epistemic(EpistemicAction::AssessClosure {
                    conclusion_cell_id: self.conclusion_id.clone(),
                    graph: self.graph.clone(),
                }))
            }
        }

        fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
            ActionCost { gas: 2 }
        }

        fn determinism_profile(&self) -> DeterminismProfile {
            DeterminismProfile {
                deterministic: true,
                bounded_divergence: false,
            }
        }
    }

    struct ReassessContract {
        graph: EpistemicGraph,
        conclusion_id: CellId,
        previous_verdict: Verdict,
    }

    impl Contract for ReassessContract {
        fn eval_step(&self, session: &SessionView) -> StepDecision {
            if session.event_count >= 1 {
                StepDecision::Commit
            } else {
                StepDecision::Continue(StepAction::Epistemic(EpistemicAction::ReassessClosure {
                    conclusion_cell_id: self.conclusion_id.clone(),
                    previous_verdict: self.previous_verdict,
                    graph: self.graph.clone(),
                }))
            }
        }

        fn cost_of(&self, _action: &StepAction, _session: &SessionView) -> ActionCost {
            ActionCost { gas: 1 }
        }

        fn determinism_profile(&self) -> DeterminismProfile {
            DeterminismProfile {
                deterministic: true,
                bounded_divergence: false,
            }
        }
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    enum ExpectedEpistemicVerdict {
        Commit,
        Ghost,
        Reject,
    }

    #[derive(Debug, Clone)]
    struct Stage1Scenario {
        name: &'static str,
        graph: EpistemicGraph,
        conclusion_id: CellId,
        expected_verdict: ExpectedEpistemicVerdict,
    }

    fn session(budget: u64) -> Session {
        Session {
            case_id: CaseId::from("case-1"),
            contract_hash: ContractHash::from("contract-v1"),
            proof_mode: ProofMode::FullSelfContained,
            initial_budget: budget,
            budget_remaining: budget,
            state_root: "state_0".to_owned(),
            atoms: AtomStoreView {
                present_cids: Vec::new(),
            },
            transcript_head: None,
            event_count: 0,
            current_proposal: None,
            last_witness_cid: None,
            last_external_anchor: None,
        }
    }

    fn pointer(namespace: &str, head: &str, prev: Option<&str>, height: u64) -> StatePointer {
        StatePointer {
            namespace: namespace.to_owned(),
            head_cid: epistemic_storage::AtomCid(head.to_owned()),
            prev_head_cid: prev.map(|value| epistemic_storage::AtomCid(value.to_owned())),
            height,
        }
    }

    fn stage1_complete_scenario() -> Stage1Scenario {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("c1"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("anchor:invoice_pdf".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("c2"),
            kind: CellKind::Observation,
            content: "payment received".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("anchor:bank_statement".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 2,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("c3"),
            kind: CellKind::Inference,
            content: "invoice matches payment".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("c1"), CellId::from("c2")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("c2"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["engine".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 65,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("c4"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("c3")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("c3"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 4,
            meta: CellMeta {
                provenance: vec!["engine".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        Stage1Scenario {
            name: "complete",
            graph,
            conclusion_id: CellId::from("c4"),
            expected_verdict: ExpectedEpistemicVerdict::Commit,
        }
    }

    fn stage1_honest_doubt_scenario() -> Stage1Scenario {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("h1"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("anchor:invoice_pdf".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("h2"),
            kind: CellKind::Observation,
            content: "payment received".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("h1")],
            confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-h2"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("h3"),
            kind: CellKind::Inference,
            content: "invoice matches payment".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("h1"), CellId::from("h2")],
            confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-h3"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["engine".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 85,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("h4"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("h3")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("h3"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 4,
            meta: CellMeta {
                provenance: vec!["engine".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-h2"),
            reason: "missing bank statement".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("h2"),
            required_for: vec![CellId::from("h3"), CellId::from("h4")],
            status: GhostStatus::Open,
            resolution_ref: None,
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-h3"),
            reason: "causal link incomplete".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("h3"),
            required_for: vec![CellId::from("h4")],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        Stage1Scenario {
            name: "honest_doubt",
            graph,
            conclusion_id: CellId::from("h4"),
            expected_verdict: ExpectedEpistemicVerdict::Ghost,
        }
    }

    fn stage1_hallucination_scenario() -> Stage1Scenario {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("a1"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("anchor:invoice_pdf".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("a2"),
            kind: CellKind::Observation,
            content: "payment received".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("a3"),
            kind: CellKind::Inference,
            content: "invoice matches payment".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("a1"), CellId::from("a2")],
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 95,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("a4"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("a3")],
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 4,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        Stage1Scenario {
            name: "hallucination",
            graph,
            conclusion_id: CellId::from("a4"),
            expected_verdict: ExpectedEpistemicVerdict::Reject,
        }
    }

    fn stage1_paranoia_scenario() -> Stage1Scenario {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("p1"),
            kind: CellKind::Observation,
            content: "neighbor glance".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("p2")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("p2"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("p2"),
            kind: CellKind::Inference,
            content: "surveillance network".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("p3")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("p3"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["mind".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 70,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("p3"),
            kind: CellKind::Observation,
            content: "friend warning as cover".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("p1")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("p1"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("p4"),
            kind: CellKind::Conclusion,
            content: "they are after me".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("p1"), CellId::from("p2"), CellId::from("p3")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("p3"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 4,
            meta: CellMeta {
                provenance: vec!["mind".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        Stage1Scenario {
            name: "paranoia",
            graph,
            conclusion_id: CellId::from("p4"),
            expected_verdict: ExpectedEpistemicVerdict::Reject,
        }
    }

    fn stage1_scenarios() -> Vec<Stage1Scenario> {
        vec![
            stage1_complete_scenario(),
            stage1_honest_doubt_scenario(),
            stage1_hallucination_scenario(),
            stage1_paranoia_scenario(),
        ]
    }

    fn receipt_verdict(receipt: &StepReceipt) -> Option<Verdict> {
        match receipt {
            StepReceipt::EpistemicClosureEvaluated {
                constitutional_verdict,
                ..
            } => Some(*constitutional_verdict),
            StepReceipt::EpistemicClosureTransition { to_verdict, .. } => Some(*to_verdict),
            _ => None,
        }
    }

    #[test]
    fn runtime_emits_proof_pack_with_append_only_events() {
        let runtime = Runtime::new(10);
        let mut ops = TestOps;
        let pack = runtime.run(session(100), &TestContract, &mut ops);
        assert_eq!(pack.events.len(), 1);
        assert_eq!(pack.final_outcome, FinalOutcome::Commit);
        assert_eq!(pack.events[0].budget_before, 100);
        assert_eq!(pack.events[0].budget_after, 95);
    }

    #[test]
    fn runtime_rejects_when_budget_is_insufficient() {
        let runtime = Runtime::new(10);
        let mut ops = TestOps;
        let pack = runtime.run(session(1), &TestContract, &mut ops);
        assert_eq!(
            pack.final_outcome,
            FinalOutcome::Reject(RejectReason::OutOfBudget)
        );
        assert!(pack.events.is_empty());
    }

    #[test]
    fn transcript_events_form_hash_chain() {
        let runtime = Runtime::new(10);
        let mut ops = CountingOps(0);
        let pack = runtime.run(session(10), &TwoStepContract, &mut ops);
        assert_eq!(pack.events.len(), 2);
        assert!(pack.events[0].prev_event_hash.is_none());
        assert_eq!(
            pack.events[1].prev_event_hash,
            Some(pack.events[0].event_hash.clone())
        );
    }

    #[test]
    fn hallucinated_closure_is_rejected_when_required_ghost_is_missing() {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "real observation".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:1".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "strong causal leap".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 95,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "close the case".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        let omissions = detect_spawn_omission(&graph);
        assert!(!omissions.is_empty());
        assert!(
            compute_grounding_ratio(&CellId::from("conclusion"), &graph)
                < COMMIT_GROUNDING_THRESHOLD
        );
        assert!(matches!(
            closure_guard(&CellId::from("conclusion"), &graph),
            ClosureVerdict::Reject { .. }
        ));
    }

    #[test]
    fn honest_gap_yields_ghost_not_reject() {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "real observation".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:1".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "missing causal support".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 95,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "close the case".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-infer"),
            reason: "missing causal link".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("infer"),
            required_for: vec![CellId::from("conclusion")],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        assert!(detect_spawn_omission(&graph).is_empty());
        assert!(matches!(
            closure_guard(&CellId::from("conclusion"), &graph),
            ClosureVerdict::Ghost { .. }
        ));
    }

    #[test]
    fn runtime_records_epistemic_closure_receipt_in_transcript() {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "real observation".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:1".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "strong causal leap".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 95,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "close the case".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        let runtime = Runtime::new(4);
        let mut ops = TestOps;
        let pack = runtime.run(
            session(10),
            &EpistemicContract {
                graph,
                conclusion_id: CellId::from("conclusion"),
            },
            &mut ops,
        );

        assert_eq!(pack.events.len(), 1);
        match &pack.events[0].receipt {
            StepReceipt::EpistemicClosureEvaluated {
                conclusion_cell_id,
                grounding_ratio_bp,
                constitutional_verdict,
                reasons,
                ..
            } => {
                assert_eq!(conclusion_cell_id, &CellId::from("conclusion"));
                assert!(*grounding_ratio_bp < 5_500);
                assert_eq!(constitutional_verdict, &Verdict::Reject);
                assert!(!reasons.is_empty());
            }
            other => panic!("expected epistemic receipt, got {other:?}"),
        }
    }

    #[test]
    fn runtime_resolves_ghost_from_latest_witness() {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:invoice".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "payment received".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-witness"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 85,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-witness"),
            reason: "need bank statement".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("infer"),
            required_for: vec![CellId::from("conclusion")],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        let runtime = Runtime::new(4);
        let mut ops = WitnessOps;
        let pack = runtime.run(
            session(10),
            &WitnessThenResolveContract {
                graph,
                ghost_id: GhostId::from("g-witness"),
                conclusion_id: CellId::from("conclusion"),
            },
            &mut ops,
        );

        assert_eq!(pack.events.len(), 2);
        match &pack.events[1].receipt {
            StepReceipt::GhostResolved {
                ghost_id,
                resolution_ref,
                resulting_status,
                resolution_cell_id,
                required_for,
                graph,
            } => {
                assert_eq!(ghost_id, &GhostId::from("g-witness"));
                assert_eq!(*resulting_status, GhostStatus::Resolved);
                assert_eq!(resolution_cell_id, &CellId::from("resolution:g-witness"));
                assert_eq!(required_for, &vec![CellId::from("conclusion")]);
                assert_eq!(
                    graph
                        .ghost(&GhostId::from("g-witness"))
                        .expect("resolved ghost should remain available")
                        .status,
                    GhostStatus::Resolved
                );
                assert_eq!(
                    resolution_ref,
                    &JustificationRef::Anchor("witness:witness:bank_statement:cid".to_owned())
                );
            }
            other => panic!("expected ghost resolution receipt, got {other:?}"),
        }
    }

    #[test]
    fn runtime_resolves_ghost_from_latest_external_anchor() {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:invoice".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "payment received".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: vec![JustificationRef::Ghost(GhostId::from("g-external"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 85,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Doubt,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-external"),
            reason: "need external statement".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("infer"),
            required_for: vec![CellId::from("conclusion")],
            status: GhostStatus::Open,
            resolution_ref: None,
        });

        let runtime = Runtime::new(4);
        let mut ops = WitnessOps;
        let pack = runtime.run(
            session(10),
            &ExternalThenResolveContract {
                graph,
                ghost_id: GhostId::from("g-external"),
                conclusion_id: CellId::from("conclusion"),
            },
            &mut ops,
        );

        assert_eq!(pack.events.len(), 2);
        match &pack.events[1].receipt {
            StepReceipt::GhostResolved {
                ghost_id,
                resolution_ref,
                resulting_status,
                resolution_cell_id,
                required_for,
                graph,
            } => {
                assert_eq!(ghost_id, &GhostId::from("g-external"));
                assert_eq!(*resulting_status, GhostStatus::Resolved);
                assert_eq!(resolution_cell_id, &CellId::from("resolution:g-external"));
                assert_eq!(required_for, &vec![CellId::from("conclusion")]);
                assert_eq!(
                    graph
                        .ghost(&GhostId::from("g-external"))
                        .expect("resolved ghost should remain available")
                        .status,
                    GhostStatus::Resolved
                );
                assert_eq!(
                    resolution_ref,
                    &JustificationRef::Anchor(
                        "external:https://bank.example/statement:cid:bank:statement".to_owned()
                    )
                );
            }
            other => panic!("expected ghost resolution receipt, got {other:?}"),
        }
    }

    #[test]
    fn runtime_reassesses_closure_after_resolution() {
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:invoice".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "payment received".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: vec![
                JustificationRef::Ghost(GhostId::from("g-reassess")),
                JustificationRef::Cell(CellId::from("resolution:g-reassess")),
            ],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 85,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![
                JustificationRef::Cell(CellId::from("infer")),
                JustificationRef::Cell(CellId::from("resolution:g-reassess")),
            ],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("resolution:g-reassess"),
            kind: CellKind::Resolution,
            content: "resolution for need bank statement".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor(
                "witness:witness:bank_statement:cid".to_owned(),
            )],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 4,
            meta: CellMeta {
                provenance: vec!["runtime.epistemic_resolution".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-reassess"),
            reason: "need bank statement".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("infer"),
            required_for: vec![CellId::from("conclusion")],
            status: GhostStatus::Resolved,
            resolution_ref: Some(JustificationRef::Anchor(
                "witness:witness:bank_statement:cid".to_owned(),
            )),
        });

        let runtime = Runtime::new(2);
        let mut ops = WitnessOps;
        let pack = runtime.run(
            session(10),
            &ReassessContract {
                graph,
                conclusion_id: CellId::from("conclusion"),
                previous_verdict: Verdict::Ghost,
            },
            &mut ops,
        );

        assert_eq!(pack.events.len(), 1);
        match &pack.events[0].receipt {
            StepReceipt::EpistemicClosureTransition {
                conclusion_cell_id,
                from_verdict,
                to_verdict,
                ..
            } => {
                assert_eq!(conclusion_cell_id, &CellId::from("conclusion"));
                assert_eq!(from_verdict, &Verdict::Ghost);
                assert_eq!(to_verdict, &Verdict::Commit);
            }
            other => panic!("expected closure transition receipt, got {other:?}"),
        }
    }

    #[test]
    fn replay_seed_round_trips_session_graph_and_pointers() {
        let store = SqliteEpistemicStore::open_in_memory().expect("sqlite store should open");
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "document exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("anchor:doc".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        let session = session(15);
        let pointers = vec![pointer("case:1", "cid:1", None, 1)];

        let seed = persist_replay_seed(&store, &session, &graph, &pointers, 42)
            .expect("seed should persist");
        let restored = load_replay_seed(&store, &session.case_id).expect("seed should restore");

        assert_eq!(restored, seed);
        assert_eq!(restored.session, session);
        assert_eq!(restored.graph, graph);
        assert_eq!(restored.pointers, pointers);
    }

    #[test]
    fn replay_equivalence_survives_store_round_trip_for_ghost_to_commit_case() {
        let store = SqliteEpistemicStore::open_in_memory().expect("sqlite store should open");
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "invoice exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:invoice".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "payment received".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: vec![
                JustificationRef::Ghost(GhostId::from("g-reassess")),
                JustificationRef::Cell(CellId::from("resolution:g-reassess")),
            ],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 85,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "transaction verified".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![
                JustificationRef::Cell(CellId::from("infer")),
                JustificationRef::Cell(CellId::from("resolution:g-reassess")),
            ],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("resolution:g-reassess"),
            kind: CellKind::Resolution,
            content: "resolution for need bank statement".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor(
                "witness:witness:bank_statement:cid".to_owned(),
            )],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 4,
            meta: CellMeta {
                provenance: vec!["runtime.epistemic_resolution".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_ghost(GhostRecord {
            id: GhostId::from("g-reassess"),
            reason: "need bank statement".to_owned(),
            criticality: GhostCriticality::High,
            opened_from: CellId::from("infer"),
            required_for: vec![CellId::from("conclusion")],
            status: GhostStatus::Resolved,
            resolution_ref: Some(JustificationRef::Anchor(
                "witness:witness:bank_statement:cid".to_owned(),
            )),
        });

        let runtime = Runtime::new(2);
        let mut live_ops = WitnessOps;
        let live_session = session(10);
        let pointers = vec![pointer("case:1", "cid:head-1", Some("cid:head-0"), 2)];

        persist_replay_seed(&store, &live_session, &graph, &pointers, 100)
            .expect("seed should persist");

        let live_pack = runtime.run(
            live_session.clone(),
            &ReassessContract {
                graph: graph.clone(),
                conclusion_id: CellId::from("conclusion"),
                previous_verdict: Verdict::Ghost,
            },
            &mut live_ops,
        );
        persist_proof_pack_receipts(&store, &live_pack).expect("live receipts should persist");

        let restored = load_replay_audit_bundle(&store, &live_session.case_id)
            .expect("audit bundle should restore");
        assert_eq!(restored.seed.session, live_session);
        assert_eq!(restored.seed.graph, graph);
        assert_eq!(restored.seed.pointers, pointers);
        assert_eq!(restored.receipts.len(), live_pack.events.len());
        assert!(
            restored.receipts.iter().any(|receipt| {
                receipt.receipt_kind == "EpistemicClosureTransition"
                    && receipt.payload_json.contains("\"grounding_ratio_bp\"")
            }),
            "persisted receipts should retain grounding metadata"
        );

        let mut replay_ops = WitnessOps;
        let replay_pack = runtime.run(
            restored.seed.session.clone(),
            &ReassessContract {
                graph: restored.seed.graph.clone(),
                conclusion_id: CellId::from("conclusion"),
                previous_verdict: Verdict::Ghost,
            },
            &mut replay_ops,
        );

        let report = compare_replay_equivalence(
            &live_pack,
            &replay_pack,
            &graph,
            &restored.seed.graph,
            &pointers,
            &restored.seed.pointers,
        );

        assert!(report.verdict_equivalent);
        assert!(report.ghost_state_equivalent);
        assert!(report.pointer_eligibility_equivalent);
        assert!(report.transition_equivalent);
        assert!(report.grounding_equivalent);
        assert_eq!(report.replay_divergence_count, 0);
    }

    #[test]
    fn replay_equivalence_survives_store_round_trip_for_adversarial_reject_case() {
        let store = SqliteEpistemicStore::open_in_memory().expect("sqlite store should open");
        let mut graph = EpistemicGraph::new();
        graph.insert_cell(CanonicalCell {
            id: CellId::from("obs"),
            kind: CellKind::Observation,
            content: "camera frame exists".to_owned(),
            status: CellStatus::Ok,
            depends_on: Vec::new(),
            confirmed_by: vec![JustificationRef::Anchor("sensor:camera".to_owned())],
            if_doubt: DoubtPolicy::AskWitness,
            created_at: 1,
            meta: CellMeta::default(),
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("infer"),
            kind: CellKind::Inference,
            content: "operator sabotaged the system".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("obs")],
            confirmed_by: Vec::new(),
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 2,
            meta: CellMeta {
                provenance: vec!["llm".to_owned()],
                closure_class: ClosureClass::Conditional,
                causal_strength: 95,
                contradiction_with: Vec::new(),
            },
        });
        graph.insert_cell(CanonicalCell {
            id: CellId::from("conclusion"),
            kind: CellKind::Conclusion,
            content: "revoke operator access immediately".to_owned(),
            status: CellStatus::Ok,
            depends_on: vec![CellId::from("infer")],
            confirmed_by: vec![JustificationRef::Cell(CellId::from("infer"))],
            if_doubt: DoubtPolicy::SpawnGhost,
            created_at: 3,
            meta: CellMeta {
                provenance: vec!["manager".to_owned(), "rights-affecting".to_owned()],
                closure_class: ClosureClass::Final,
                causal_strength: 0,
                contradiction_with: Vec::new(),
            },
        });

        let runtime = Runtime::new(2);
        let mut live_ops = TestOps;
        let live_session = session(10);
        let blocked_pointers = vec![pointer("case:reject-1", "cid:head-0", None, 1)];

        persist_replay_seed(&store, &live_session, &graph, &blocked_pointers, 200)
            .expect("seed should persist");

        let live_pack = runtime.run(
            live_session.clone(),
            &EpistemicContract {
                graph: graph.clone(),
                conclusion_id: CellId::from("conclusion"),
            },
            &mut live_ops,
        );
        persist_proof_pack_receipts(&store, &live_pack).expect("live receipts should persist");

        let restored = load_replay_audit_bundle(&store, &live_session.case_id)
            .expect("audit bundle should restore");
        assert_eq!(restored.seed.graph, graph);
        assert_eq!(restored.seed.pointers, blocked_pointers);

        let mut replay_ops = TestOps;
        let replay_pack = runtime.run(
            restored.seed.session.clone(),
            &EpistemicContract {
                graph: restored.seed.graph.clone(),
                conclusion_id: CellId::from("conclusion"),
            },
            &mut replay_ops,
        );

        let report = compare_replay_equivalence(
            &live_pack,
            &replay_pack,
            &graph,
            &restored.seed.graph,
            &blocked_pointers,
            &restored.seed.pointers,
        );

        match &live_pack.events[0].receipt {
            StepReceipt::EpistemicClosureEvaluated {
                constitutional_verdict,
                grounding_ratio_bp,
                ..
            } => {
                assert_eq!(*constitutional_verdict, Verdict::Reject);
                assert!(*grounding_ratio_bp < 5_500);
            }
            other => panic!("expected epistemic reject receipt, got {other:?}"),
        }
        match &replay_pack.events[0].receipt {
            StepReceipt::EpistemicClosureEvaluated {
                constitutional_verdict,
                grounding_ratio_bp,
                ..
            } => {
                assert_eq!(*constitutional_verdict, Verdict::Reject);
                assert!(*grounding_ratio_bp < 5_500);
            }
            other => panic!("expected replay epistemic reject receipt, got {other:?}"),
        }
        assert!(
            restored.receipts.iter().any(|receipt| {
                receipt.receipt_kind == "EpistemicClosureEvaluated"
                    && receipt
                        .payload_json
                        .contains("\"constitutional_verdict\":\"Reject\"")
                    && receipt.payload_json.contains("\"grounding_ratio_bp\"")
            }),
            "persisted receipts should retain reject verdict and grounding metadata"
        );
        assert!(report.verdict_equivalent);
        assert!(report.ghost_state_equivalent);
        assert!(report.pointer_eligibility_equivalent);
        assert!(report.transition_equivalent);
        assert!(report.grounding_equivalent);
        assert_eq!(report.replay_divergence_count, 0);
    }

    #[test]
    fn stage1_scenarios_match_expected_epistemic_verdicts() {
        let runtime = Runtime::new(2);

        for scenario in stage1_scenarios() {
            let mut ops = TestOps;
            let pack = runtime.run(
                session(10),
                &EpistemicContract {
                    graph: scenario.graph.clone(),
                    conclusion_id: scenario.conclusion_id.clone(),
                },
                &mut ops,
            );

            let verdict = receipt_verdict(&pack.events[0].receipt)
                .expect("first receipt should carry an epistemic verdict");
            let expected = match scenario.expected_verdict {
                ExpectedEpistemicVerdict::Commit => Verdict::Commit,
                ExpectedEpistemicVerdict::Ghost => Verdict::Ghost,
                ExpectedEpistemicVerdict::Reject => Verdict::Reject,
            };
            assert_eq!(
                verdict, expected,
                "scenario `{}` should preserve its expected epistemic class",
                scenario.name
            );
        }
    }

    #[test]
    fn stage1_scenarios_survive_replay_equivalence_round_trip() {
        let runtime = Runtime::new(2);

        for (index, scenario) in stage1_scenarios().into_iter().enumerate() {
            let store = SqliteEpistemicStore::open_in_memory().expect("sqlite store should open");
            let live_session = session(10);
            let pointers = match scenario.expected_verdict {
                ExpectedEpistemicVerdict::Commit => {
                    vec![pointer(
                        &format!("case:{}", scenario.name),
                        "cid:advanced",
                        Some("cid:prev"),
                        2,
                    )]
                }
                ExpectedEpistemicVerdict::Ghost | ExpectedEpistemicVerdict::Reject => {
                    vec![pointer(
                        &format!("case:{}", scenario.name),
                        "cid:blocked",
                        None,
                        1,
                    )]
                }
            };

            persist_replay_seed(
                &store,
                &live_session,
                &scenario.graph,
                &pointers,
                300 + index as u64,
            )
            .expect("seed should persist");

            let mut live_ops = TestOps;
            let live_pack = runtime.run(
                live_session.clone(),
                &EpistemicContract {
                    graph: scenario.graph.clone(),
                    conclusion_id: scenario.conclusion_id.clone(),
                },
                &mut live_ops,
            );
            persist_proof_pack_receipts(&store, &live_pack).expect("live receipts should persist");

            let restored = load_replay_audit_bundle(&store, &live_session.case_id)
                .expect("audit bundle should restore");

            let mut replay_ops = TestOps;
            let replay_pack = runtime.run(
                restored.seed.session.clone(),
                &EpistemicContract {
                    graph: restored.seed.graph.clone(),
                    conclusion_id: scenario.conclusion_id.clone(),
                },
                &mut replay_ops,
            );

            let report = compare_replay_equivalence(
                &live_pack,
                &replay_pack,
                &scenario.graph,
                &restored.seed.graph,
                &pointers,
                &restored.seed.pointers,
            );

            assert!(
                report.verdict_equivalent,
                "scenario `{}` drifted in verdict",
                scenario.name
            );
            assert!(
                report.ghost_state_equivalent,
                "scenario `{}` drifted in ghost state",
                scenario.name
            );
            assert!(
                report.pointer_eligibility_equivalent,
                "scenario `{}` drifted in pointer eligibility",
                scenario.name
            );
            assert!(
                report.grounding_equivalent,
                "scenario `{}` drifted in grounding visibility",
                scenario.name
            );
            assert_eq!(
                report.replay_divergence_count, 0,
                "scenario `{}` should replay without semantic drift",
                scenario.name
            );
        }
    }
}
