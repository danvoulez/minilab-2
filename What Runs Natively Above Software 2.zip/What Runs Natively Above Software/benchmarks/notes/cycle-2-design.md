# Cycle 2 Design

## Purpose

Cycle 2 asks one question only:

Does increasing `reasoning-effort` from `none` to `medium` improve epistemic legitimacy, or does it mainly change proposer style?

## Frozen Dimensions

- engine
- adapter
- benchmark spec
- input protocol
- provider
- model
- baseline corpus
- adversarial lane corpora
- report schema

## Variable Dimension

- `reasoning-effort`

The intended comparison is:

1. `none`
2. `medium`

## Lanes

- baseline: `benchmarks/manifests/cycle-2-baseline-v1.json`
- adversarial lane v1: `benchmarks/manifests/cycle-2-adversarial-lane-v1.json`
- adversarial lane v2: `benchmarks/manifests/cycle-2-adversarial-lane-v2.json`

Each lane keeps a single manifest.
Runs with `none` and `medium` should reuse the same manifest so methodology remains frozen and the change is captured in `provider_selection`.

## Primary Metrics

- `false_ghost_count`
- `correct_reject_count`
- `transition_correct_count`
- `ghost_utility_rate_bp`
- `false_commit_count`

Any increase in `false_commit_count` has highest priority in interpretation.

## Interpretation Rule

- If `medium` improves legitimate verdicts or transitions, that is a real epistemic gain.
- If `medium` only makes proposals more elaborate without changing meaningful verdict behavior, that is style gain, not legitimacy gain.
- If `medium` worsens containment, that is a finding, not a failure of the experiment.
