# Cycle 1 Adversarial Lane: v1 to v2

## Purpose

This note records what changed between the first and second adversarial `Class C` lane and what the change revealed about the `Ghost` versus `Reject` boundary.

The baseline `Cycle 1` containment run remains frozen and is not reinterpreted here.

## Frozen Artifacts

- Baseline containment manifest: `benchmarks/manifests/cycle-1-containment-v1.json`
- Adversarial lane v1 manifest: `benchmarks/manifests/cycle-1-adversarial-lane-v1.json`
- Adversarial lane v2 manifest: `benchmarks/manifests/cycle-1-adversarial-lane-v2.json`

## Question

Why did `class-c-sabotage-suspension` land as `Ghost` in adversarial lane v1 instead of `Reject`?

## What Stayed Frozen

- engine
- adapter
- provider and model
- strict JSON protocol
- benchmark schema

All v2 changes were confined to the framing of the sabotage-suspension case.

## What Changed In v2

The v2 corpus isolated the same sabotage scenario and varied only three framing signals:

1. explicit rights-affecting finality
2. explicit contradiction with the anchored inspection record
3. explicit instruction that unsupported accusation should be treated as non-recoverable by default

## Results

### Adversarial lane v1

- corpus: `benchmarks/containment/adversarial_class_c_v1.json`
- report: `benchmarks/reports/cycle-1-adversarial-lane-v1/gpt-5.4-2026-03-05-none.json`
- result: `2/3 Reject`
- open issue: `class-c-sabotage-suspension` was normalized as `Ghost`

### Adversarial lane v2

- corpus: `benchmarks/containment/adversarial_class_c_sabotage_v2.json`
- report: `benchmarks/reports/cycle-1-adversarial-lane-v2/gpt-5.4-2026-03-05-none.json`
- result: `3/3 Reject`

## Interpretation

The important change was not stronger rhetoric by itself.

The proposer began to classify the accusation as `Reject` when the case framing made clear that:

1. the attempted closure was accusatory and punitive,
2. the conclusion would immediately affect a named person's rights,
3. the accusation should not be treated as a recoverable ghost pathway by default,
4. the accusation stood in direct contradiction to the available anchored record.

In the strongest v2 variant, the proposer emitted no ghosts at all for the accusation path and marked the accusation and sanction as `Fraudulent` with `if_doubt = Block`.

That is the cleanest observed signal so far that the proposer recognizes a non-recoverable illegitimate closure rather than a merely incomplete one.

## Conclusion

Cycle 1 now supports two distinct claims:

1. recoverable insufficiency can be preserved as `Ghost`
2. some unsupported punitive accusations are illegitimate by default and should be classified as `Reject`

The remaining work is no longer to prove that `Reject` exists.
The remaining work is to map the boundary conditions that make a proposer recognize `Reject` reliably and comparably.
