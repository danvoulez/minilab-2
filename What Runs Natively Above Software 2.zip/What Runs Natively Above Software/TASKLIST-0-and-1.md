
Perfeito. Eu fecharia isso como TASKLIST 0 — alinhamento do repo antes da próxima tasklist.

A lógica é: o repo já tem uma constituição muito clara e não deve ser reestruturado no eixo dos 10 offices; o próprio ARCHITECTURE.md deixa isso explícito, junto com a separação de dependências e o fato de que boa parte do que existe hoje é um slice executável fino com outras camadas ainda deferidas.  ￼

**TASKLIST 0**

T0.1 — Normalizar a superfície do repo

Objetivo: remover inconsistências básicas antes de qualquer expansão.

Fazer:
	•	decidir entre:
	•	adicionar um Justfile real com fmt, check, lint, test, ci, ou
	•	remover as referências a just de README.md e CONTRIBUTING.md
	•	alinhar:
	•	Cargo.toml (rust-version = "1.85")
	•	rust-toolchain.toml (channel = "1.94.0")
	•	deixar explícito no README qual é a versão mínima suportada vs. a versão pinada para desenvolvimento/CI, se a diferença for intencional

Por quê: hoje o material do repo fala em just, mas o tree visível não mostra Justfile, e há mismatch entre rust-version e toolchain. Isso gera atrito desnecessário logo na entrada.  ￼

⸻

T0.2 — Fazer o README dizer a verdade atual do projeto

Objetivo: parar de apresentar o repo só como “constitucional e esparso” se ele já tem runtime epistemológico operacional.

Arquivos:
	•	README.md
	•	ARCHITECTURE.md
	•	docs/IMPLEMENTATION_STATUS.md
	•	docs/EPISTEMIC_RUNTIME.md

Fazer:
	•	manter a narrativa de “constitutional stack”
	•	mas acrescentar uma seção curta tipo Current operational slice
	•	registrar explicitamente que já existe um caminho operacional mínimo de avaliação epistemológica / transição / governança de fechamento
	•	separar melhor:
	•	implemented now
	•	deferred by design
	•	next operational frontier

Por quê: o repo se define como constitutional stack e também já declara slices executáveis implementados; a documentação precisa refletir esse ponto intermediário com precisão.  ￼

⸻

T0.3 — Criar um roadmap formal do próximo ciclo

Objetivo: parar de deixar a ordem das próximas frentes só implícita.

Novo arquivo:
	•	docs/ROADMAP.md

Conteúdo mínimo:
	1.	adapter LLM -> proposal/epistemic input
	2.	benchmark de inference-without-anchor containment
	3.	persistência real de AtomSpace / estado epistemológico
	4.	sorrow test / interlocks em horizon-real
	5.	endurecimento de federation
	6.	backend real de sandbox/worker

Por quê: o ARCHITECTURE.md já separa claramente o que foi implementado do que foi deferido; falta só transformar isso em ordem de execução.  ￼

⸻

T0.4 — Especificar o benchmark antes de crescer o runtime

Objetivo: ter critério empírico, não só critério doutrinário.

Novo arquivo:
	•	docs/BENCHMARK_PROTOCOL.md

Definir:
	•	falso fechamento
	•	ghost útil vs. ghost redundante
	•	taxa de over-blocking
	•	lift após witness/anchor
	•	tempo até closure
	•	% de casos que exigem signoff humano
	•	distinção entre:
	•	commit correto
	•	ghost correto
	•	reject correto
	•	transição correta após resolução

Por quê: RFC-0004 exige prova, anti-rewind, fork explícito e separação entre recepção e aceitação; RFC-0008 exige finalidade explícita e nunca implícita em casos de consequência. Sem benchmark, isso fica bonito no papel e difuso na prática.  ￼

⸻

T0.5 — Escrever a spec de Ghost como artefato de primeira classe

Objetivo: consolidar a semântica do que já virou peça estrutural do runtime.

Novo arquivo:
	•	docs/ANATOMY_OF_A_GHOST.md

Definir:
	•	condições de spawn
	•	omission vs contradiction vs insufficiency
	•	critical vs non-critical ghost
	•	o que conta como resolução
	•	quando resolução basta e quando exige reavaliação
	•	como ghost impacta closure, pointer advance e manager blocking

Por quê: isso reduz ambiguidade sem mexer na constituição do repo.

⸻

T0.6 — Adicionar fluxos canônicos de sequência

Objetivo: tornar o sistema legível sem exigir leitura integral dos RFCs sempre.

Novo arquivo:
	•	docs/SEQUENCE_FLOWS.md

Fluxos mínimos:
	•	proposal -> epistemic evaluation -> Ghost
	•	Ghost -> witness/anchor -> resolution -> reevaluation -> Commit
	•	evaluation sem commit -> manager bloqueia
	•	transition to Commit -> manager avança pointer
	•	fork federado -> preserve fork / resolve / require witness
	•	caso jurisdiction-bearing -> sem assinatura, sem finalidade

Por quê: RFC-0004 trata fork como objeto de primeira classe; RFC-0008 proíbe finalidade implícita. Vale muito ter isso em fluxo operacional simples.  ￼

⸻

T0.7 — Criar threat model do repo

Objetivo: explicitar contra o que exatamente a arquitetura está defendendo.

Novo arquivo:
	•	docs/THREAT_MODEL.md

Cobrir pelo menos:
	•	silent overwrite de pointer head
	•	replay/rewind
	•	ProofPack inválido mas bem formado
	•	dependency injection errada
	•	forged signer / forged authority
	•	UI acknowledgment fingindo assinatura
	•	advisory output promovido a ação final
	•	suppressão de dissent / suspension / escalation

Por quê: isso está fortemente implicado pelos RFCs de federation e jurisdiction; só falta cristalizar em documento operacional.  ￼

⸻

T0.8 — Fazer uma passada curta de type hardening

Objetivo: endurecer identidade onde identidade realmente importa.

Fazer:
	•	revisar uso de String cru para entidades sensíveis
	•	promover para newtypes onde fizer sentido, por exemplo:
	•	CaseCid
	•	ProofPackCid
	•	ContractHash
	•	SignerId
	•	AuthorityId
	•	PointerAlias
	•	ReceiptCid

Por quê: o próprio ARCHITECTURE.md manda preferir tipos mais fortes quando identidade/assinatura importam.  ￼

⸻

T0.9 — Gate de saída da TASKLIST 0

Só começa a próxima tasklist quando:
	•	README e IMPLEMENTATION_STATUS estiverem honestos
	•	Justfile/workflow estiverem consistentes
	•	versão Rust estiver coerente ou documentada
	•	ROADMAP.md existir
	•	BENCHMARK_PROTOCOL.md existir
	•	ANATOMY_OF_A_GHOST.md existir
	•	SEQUENCE_FLOWS.md existir
	•	THREAT_MODEL.md existir
	•	type hardening tiver sido feito ou aberto como issues explícitas




**TASLIST 1** 

The key constraint is the repo’s own constitutional shape: one-way office separation, replay-first execution, no hidden state, no reverse authority dependencies, and a v0 that already has thin executable slices for gate/runtime/storage/federation/worker/economics/jurisdiction/horizon, plus a minimal but real epistemic runtime. That means the next steps should tighten the existing loop first, then force contact with real model behavior, then harden persistence and physical boundary conditions.  ￼

Ranked execution roadmap

1. Make ReevaluateEpistemicClosure a real runtime dispatch path

Dependency: none; this is already named as the immediate next implementation pass in your own docs.
Artifact: runtime path that consumes ReevaluateEpistemicClosure natively, rather than leaving re-evaluation as typed output plus test orchestration.
Success criterion: a case can move from evaluation → Ghost → witness/anchor resolution → re-evaluation → explicit EpistemicClosureTransition without manual orchestration glue.
Why it matters: this finishes the loop your epistemic note already says should exist, and it makes the current “closure-carrying governance” story tighter before you open new fronts.

2. Build the LLM proposal adapter

Dependency: step 1 is ideal but not strictly required.
Artifact: a strict adapter that converts model output into CanonicalCell graphs with depends_on, confirmed_by, and doubt policy surfaces, plus normalization passes that separate parse success from epistemic adequacy.
Success criterion: given incomplete evidence, a real model can emit a structured proposal that the runtime can ingest without hand-authored fixtures.
Why it matters: your own docs still list “LLM-facing adapters and user-facing operator surfaces” as deferred. This is the shortest route from internal doctrine to real perturbation testing, and it directly exercises the repo’s principle that model output must not become final authority.

3. Run the flagship Stage 2 benchmark: unanchored inference containment

Dependency: step 2.
Artifact: a small benchmark harness with incomplete-evidence tasks, baseline raw-model outputs, and qualified-closure outputs.
Success criterion: when a real model proposes closure from missing support, the system catches the omission, grounding stays below threshold, closure does not advance as Commit, and the system yields Ghost and/or Resolve-next instead.
Why it matters: this is the first public proof that the epistemic layer governs real model mess rather than only in-memory fixtures. It also turns the manifesto into numbers: fewer false commits, explicit missing support, and directed next actions instead of confidence theater. Your current guarantees already prove the pattern in synthetic form; this is where you demonstrate it against a real proposer.

4. Persist the AtomSpace and the EpistemicGraph

Dependency: none in principle, but do it right after the first containment run so the experiment has a durable substrate.
Artifact: persistent storage for proof artifacts and epistemic state, not just in-memory payloads; enough to spin down, spin up, rehydrate, and replay.
Success criterion: a ProofPack, pointer state, and epistemic graph survive restart; the verifier can replay and confirm the same terminal or intermediate state after rehydration.
Why it matters: the repo explicitly defers persistent storage engines and persistent epistemic graph storage, while the doctrine insists that state advances by immutable graphs and replayable proof rather than mutable memory. Until persistence lands, the system is still proving itself mostly in RAM.

5. Run the Sorrow Test with a dummy actuator

Dependency: steps 1 and 4 help; a full production hardware stack is not required.
Artifact: a local actuator boundary where an irreversible or body/life-affecting command is blocked unless accountable signer authority and lawful closure are both satisfied.
Success criterion: a command that is epistemically strong but lacks valid accountable jurisdiction never crosses the physical boundary.
Why it matters: the repo already claims a physical interlock refusing irreversible command without lawful closure, and the jurisdiction RFC is one of the most distinctive parts of the whole architecture: models advise, managers coordinate, but final consequential commitment belongs where non-transferable consequence remains. This test makes that doctrine visible at the horizon of the real.

6. Add the benchmark protocol as a first-class document and harness

Dependency: steps 2 and 3.
Artifact: a benchmark spec defining inputs, expected verdict classes, false-commit rate, Ghost utility rate, over-blocking rate, resolution lift, and time-to-closure.
Success criterion: every experiment emits comparable metrics, not just anecdotes.
Why it matters: otherwise the project risks having compelling demos but no stable empirical language. Your validation section needs to be able to say not only “it trapped this one,” but “under these scenarios it reduced illegitimate closure by X while incurring Y delay.” The current docs already frame validation as central, not decorative.

7. Build the “Hello World of Epistemic Governance”

Dependency: steps 1–3.
Artifact: a practitioner-facing tutorial showing a minimal case from proposal → Ghost → witness/anchor → closure transition → pointer advance.
Success criterion: an outside developer can run one happy path and one blocked path without needing to absorb the whole RFC corpus first.
Why it matters: the current repo is excellent for architects, but its own README and architecture docs show a sparse constitutional workspace, not yet an integrator bridge. This doc is how the system becomes buildable, not just admirable.

8. Write the “Anatomy of a Ghost” technical spec

Dependency: step 2 will sharpen it.
Artifact: a precise document covering GhostRecord, criticality, spawn conditions, resolution paths, closure effects, and when to choose different doubt policies.
Success criterion: a developer can answer “when should a Ghost spawn, when does it block, and how is it resolved?” without guessing from tests.
Why it matters: Ghost is now central to the runtime’s meaning. Your own epistemic note makes it clear that absence now has form, doubt is a process obligation, and resolution is not identical to closure. That deserves a dedicated operational spec.  ￼

9. Move into federation hardening

Dependency: step 4 strongly recommended.
Artifact: the fork/anti-rewind/quorum path made concrete with persisted fork artifacts and real acceptance receipts.
Success criterion: concurrent incompatible heads become explicit PointerFork history, never silent overwrite; local sovereignty is preserved; resolution remains policy- and proof-based.
Why it matters: federation is already doctrinally strong in the RFCs: no mutable state sync, no blind trust, fork as first-class object, anti-rewind mandatory, and acceptance separated from reception. But the architecture docs still mark production networking/cryptography and expanded conflict resolution as deferred. This should come after the first public epistemic proof, not before it.

10. Replace mock sandbox/runtime boundaries with real WASM worker execution

Dependency: persistence helps; federation not required first.
Artifact: a real worker-abi backend with bounded labor, explicit yield/resume, and no reverse policy dependence.
Success criterion: a worker can request missing data, yield cleanly, resume deterministically, and stay subordinate to transcript and contract.
Why it matters: the architecture explicitly separates worker-abi from manager logic and treats bounded labor as its own office. Real WASM or similar backends matter, but they are a second-wave hardening task, not the first public proof point.

The order I’d actually execute

If I made this brutally practical, I’d do it in this sequence:
	1.	real ReevaluateEpistemicClosure dispatch
	2.	LLM proposal adapter
	3.	unanchored inference containment benchmark
	4.	persistent AtomSpace + persistent EpistemicGraph
	5.	Sorrow Test with dummy actuator
	6.	benchmark protocol + public numbers
	7.	Hello World + Anatomy of a Ghost
	8.	federation fork test
	9.	real WASM worker backend
	10.	threat model / attack trees + visual architecture

Why this order is the best fit for this repo

Because the repo already has three things that should drive priority:
	•	a constitutional stack with strict office separation and no reverse authority dependencies, so you should avoid broad cross-cutting rewrites too early;  ￼
	•	a minimal but real epistemic runtime whose current guarantees already prove Ghost, closure transition, and manager obedience in an end-to-end path;  ￼
	•	explicit deferred items that name persistence, production adapters, real sandbox backends, and richer federation as next-wave work rather than unfinished doctrine.

So the correct near-future move is not “make the doctrine prettier.” It is:

prove that a real proposer can be governed, then prove that the result survives restart, then prove that it stops at the physical boundary without accountable authority.

That’s the sequence that turns this from a remarkable architecture into a public standard candidate.

If you want, I’ll turn this next into a one-page project board with columns for:
Now / Next / Later / Risks / Demo value.


