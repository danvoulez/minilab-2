O-QUE-FAZER-AGORA.md


## Response:
Sim — e agora dá pra refazer isso **bem melhor** à luz do que discutimos:

*   sem burocracia performática
*   compatível com o **Cânon dos LABs**
*   alinhado com **RO-Crate / PROV / CodeMeta**
*   preservando a automação que vocês já têm
*   e, principalmente, com uma distinção clara entre:
    *   **template family estável**
    *   **conteúdo variável por ciclo/run**

A chave agora é esta:

> **o template não é um formulário arbitrário; é um contrato estrutural.**  
> Ele deve durar, mudar raramente, e todo documento experimental deve passar por um **Canonical Completeness Check**.

Ou seja: não é obrigatório escrever literalmente `who / did / this / when`, mas é obrigatório que o documento contenha, no jargão científico apropriado, os equivalentes funcionais de:

*   agente/responsável
*   ação/intervenção
*   objeto/escopo
*   contexto temporal/versionado
*   base evidencial
*   condição de avanço
*   condição de dúvida/inconclusão
*   condição de falha
*   estado atual

Isso deixa tudo muito mais sólido.

* * *

Kit de templates para experimentos digitais
===========================================

Template Family v1 — Canon-aligned, research-ready
--------------------------------------------------

Princípio geral
---------------

A ideia é simples:

*   **antes**: definir o experimento
*   **durante**: registrar a run
*   **depois**: consolidar o aprendizado

Mas agora com uma regra mais madura:

> **Template muda raramente. Conteúdo muda a cada ciclo.**

E com outra regra:

> **Todo documento experimental deve passar por um Canonical Completeness Check.**

Isso significa que o template family v1 é parte da infraestrutura do trabalho, não um rascunho improvisado.

* * *

Estrutura sugerida
==================

```
docs/experiments/
  TEMPLATE_FAMILY_v1/
    TEMPLATE_EXPERIMENT_CHARTER.md
    TEMPLATE_METHODOLOGY_SPEC.md
    TEMPLATE_COMPARATIVE_NOTE.md
    TEMPLATE_DECISION_NOTE.md
    TEMPLATE_PRE_CYCLE_CHECKLIST.md
    TEMPLATE_CANONICAL_COMPLETENESS_CHECK.md

benchmarks/manifests/
  <run>.json

benchmarks/notes/
  <comparative-note>.md

benchmarks/reports/
  <run>.json
  <run>.ro-crate/
```

* * *

Política curta da Template Family v1
====================================

Regra 1 — A forma é estável
---------------------------

A família de templates é versionada e só muda por nota explícita.

Regra 2 — Um ciclo usa uma única família
----------------------------------------

Nenhum ciclo mistura template family diferentes.

Regra 3 — O Cânon é funcional, não literal
------------------------------------------

Os documentos podem usar vocabulário científico natural, desde que contenham as funções canônicas necessárias.

Regra 4 — Padrões internacionais entram por interoperabilidade
--------------------------------------------------------------

*   **RO-Crate** como pacote do run
*   **PROV** como vocabulário parcial de proveniência
*   **CodeMeta** para descrever o software
*   **FAIR** como princípio de qualidade  
    Mas a semântica canônica continua sendo a fonte de verdade.

Regra 5 — Automação continua valendo
------------------------------------

O que já foi automatizado:

*   versionamento por fingerprint
*   manifests de run
*   reports
*   RO-Crate  
    não deve ser refeito manualmente.  
    Os templates entram como **delta de governança**, não como regressão.

* * *

1) TEMPLATE\_EXPERIMENT\_CHARTER.md
===================================

Este documento responde:

*   o que estamos tentando descobrir
*   por que isso importa
*   o que pode mudar
*   o que fica congelado
*   quando o ciclo termina

Ele é o documento de **intenção e borda**.

```
# Experiment Charter

## Identity
- template_family: v1
- experiment_id:
- cycle_id:
- title:
- owner:
- date_opened:
- status: planned | running | frozen | closed

## Question
> Qual é a pergunta única que este ciclo quer responder?

## Hypothesis
> O que esperamos encontrar, antes de rodar?

## Why this matters
> Por que esta pergunta importa para o produto, arquitetura ou pesquisa?

## Scope
### In scope
- 

### Out of scope
- 

## Allowed change
> Qual é a única variável principal que pode mudar neste ciclo?

- allowed_change:

## Frozen dimensions
> O que não pode mudar neste ciclo?

- engine_version:
- methodology_version:
- benchmark_spec_version:
- case_corpus_version:
- input_protocol_version:
- provider_selection_version:
- report_schema_version:
- thresholds:
- other_frozen_dimensions:

## Corpus / lanes
- baseline:
- adversarial_lanes:
- additional_lanes:

## Metrics of interest
### Primary
- 

### Secondary
- 

### Safety-critical
- 

## Success signal
> O que contaria como resultado positivo ou informativo?

## Failure signal
> O que contaria como fracasso real deste ciclo?

## Stop condition
> Quando saberemos que este ciclo respondeu o suficiente?

## Versioning rule
> O que gera:
- nova run:
- nova lane:
- v2:
- novo ciclo:

## Risks
- methodological_risk:
- tooling_risk:
- interpretation_risk:

## Notes
- 
```

* * *

2) TEMPLATE\_METHODOLOGY\_SPEC.md
=================================

Este documento responde:

*   como o experimento será conduzido
*   com qual corpus
*   com qual provider/model
*   com qual protocolo
*   com quais métricas
*   com quais regras de interpretação

Ele é a **receita operacional** do ciclo.

```
# Methodology Spec

## Identity
- template_family: v1
- methodology_id:
- related_experiment_id:
- author:
- date:
- status: active | frozen | superseded

## Objective
> O que esta metodologia operacionaliza?

## Experimental design
- design_type: baseline comparison | adversarial lane | ablation | robustness | other
- unit_of_analysis:
- comparison_axis:

## Inputs

### Case corpus
- corpus_id:
- source:
- lane(s):
- expected_verdict_classes:

### Input protocol
- protocol_id:
- format:
- constraints:
- normalization_rules:

## System configuration

### Engine
- engine_version:
- relevant_modules:
- thresholds_policies:

### Provider / model
- provider:
- model:
- snapshot:
- reasoning_effort:
- other_parameters:

### Adapter
- adapter_version:
- structured_output_requirement:
- parse_rules:
- adequacy_rules:

## Run procedure
1.
2.
3.
4.

## Metrics

### Primary metrics
- false_commit_count
- false_ghost_count
- false_reject_count
- correct_commit_count
- correct_ghost_count
- correct_reject_count
- transition_correct_count

### Secondary metrics
- ghost_utility
- resolution_to_commit_lift
- runtime_latency
- cost
- parse_failure_rate

## Reporting
- report_schema_version:
- output_paths:
- raw_output_retained: yes | no
- research_package_format: RO-Crate
- provenance_style: PROV-aligned partial fields
- software_metadata: CodeMeta

## Interpretation rules
> Como interpretar os resultados sem improvisar depois?

### Examples
- If X happens, interpret as:
- If Y happens, interpret as:
- If Z happens, do not claim:

## Limitations
- 
```

* * *

3) TEMPLATE\_RUN\_MANIFEST.json
===============================

Esse continua em JSON porque combina bem com automação, fingerprints e reports.

A diferença agora é que ele passa a ser entendido como:

*   **manifesto do run**
*   **envelope de identidade**
*   **ponto de interop com RO-Crate e PROV**

```
{
  "template_family": "v1",
  "experiment_id": "",
  "cycle_id": "",
  "run_id": "",
  "timestamp_start_utc": "",
  "timestamp_end_utc": "",
  "owner": "",

  "methodology": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },
  "engine": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },
  "benchmark_spec": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },
  "case_corpus": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },
  "input_protocol": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },
  "provider_selection": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },
  "report_schema": {
    "label": "",
    "auto_revision": "",
    "fingerprint": ""
  },

  "provider": "",
  "model": "",
  "model_snapshot": "",
  "reasoning_effort": "",
  "backend": "",

  "frozen_dimensions": [
    "engine",
    "benchmark_spec",
    "case_corpus",
    "input_protocol"
  ],

  "prov": {
    "used": [],
    "wasGeneratedBy": "",
    "wasDerivedFrom": [],
    "wasAssociatedWith": ""
  },

  "notes": ""
}
```

* * *

4) TEMPLATE\_COMPARATIVE\_NOTE.md
=================================

Este documento responde:

*   o que foi comparado
*   o que ficou constante
*   o que mudou
*   o que os números permitem afirmar
*   o que ainda não provam

Ele é a **ponte entre runs e conhecimento**.

```
# Comparative Note

## Identity
- template_family: v1
- note_id:
- date:
- author:
- compares:
  - run_a:
  - run_b:

## What was held constant
- 
- 
- 

## What changed
- 
- 
- 

## Main result
> Em uma frase: o que mudou de verdade?

## Metrics comparison

| Metric | Run A | Run B | Difference | Interpretation |
|---|---:|---:|---:|---|
| correct_commit_count |  |  |  |  |
| correct_ghost_count |  |  |  |  |
| correct_reject_count |  |  |  |  |
| false_commit_count |  |  |  |  |
| false_ghost_count |  |  |  |  |
| false_reject_count |  |  |  |  |
| transition_correct_count |  |  |  |  |

## Case-by-case differences
- case:
  - Run A:
  - Run B:
  - Why it matters:

## Honest reading

### What improved
- 

### What got worse
- 

### What stayed unchanged
- 

## Methodological conclusion
> O que esta comparação nos permite afirmar com segurança?

## What it does NOT prove
> O que ainda não podemos afirmar?

## Next step
- 
```

* * *

5) TEMPLATE\_DECISION\_NOTE.md
==============================

Este documento responde:

*   por que estamos encerrando ou avançando
*   o que fica congelado
*   o que fica em aberto
*   o que não deve ser reaberto retroativamente

Ele é a **memória decisória** do ciclo.

```
# Decision Note

## Identity
- template_family: v1
- decision_id:
- date:
- author:
- related_cycle:

## Decision
> O que foi decidido?

- freeze_cycle
- open_new_lane
- open_v2
- open_new_cycle
- stop_experimentation_on_this_axis
- other:

## Why now
> Por que este é o momento certo de encerrar ou avançar?

## Evidence used
- reports:
- notes:
- artifacts:

## What is now frozen
- 
- 
- 

## What remains open
- 
- 
- 

## What comes next
- next_cycle:
- next_lane:
- next_hypothesis:

## Anti-chaos note
> O que NÃO deve ser reaberto retroativamente?

- 
```

* * *

6) TEMPLATE\_PRE\_CYCLE\_CHECKLIST.md
=====================================

Esse é o documento leve que impede corrida desgovernada.

```
# Pre-Cycle Checklist

## Question
- [ ] A pergunta do ciclo cabe em 1 frase

## Allowed change
- [ ] Só 1 variável principal pode mudar

## Frozen dimensions
- [ ] Engine congelada
- [ ] Corpus congelado
- [ ] Prompt/protocolo congelado
- [ ] Provider/model congelado
- [ ] Thresholds congelados

## Method
- [ ] Métricas principais definidas
- [ ] Critério de encerramento definido
- [ ] Regra de versionamento definida

## Output
- [ ] Run manifest preparado
- [ ] Report schema definido
- [ ] Raw outputs serão preservados
- [ ] RO-Crate será gerado
- [ ] Proveniência mínima PROV-aligned está presente

## Go / No-Go
- [ ] Este ciclo está pronto para rodar
```

* * *

7) TEMPLATE\_CANONICAL\_COMPLETENESS\_CHECK.md
==============================================

Esse é o delta mais importante em relação à versão anterior.

Não é um documento para “preencher e esquecer”.  
É um **teste estrutural** aplicado aos outros documentos.

A pergunta dele é:

> este documento contém, no jargão apropriado, as funções canônicas mínimas para ser cientificamente governável?

```
# Canonical Completeness Check

## Identity
- template_family:
- document_type:
- document_id:
- checked_by:
- date:
- status: PASS | FAIL | PARTIAL

## Canonical functions present?

| Canonical function | Present? | Scientific field used in this document | Notes |
|---|---|---|---|
| actor / responsible agent | yes/no |  |  |
| action / intervention | yes/no |  |  |
| object / scope | yes/no |  |  |
| temporal or versioned context | yes/no |  |  |
| evidentiary basis / confirmed_by | yes/no |  |  |
| success path / if_ok | yes/no |  |  |
| inconclusive path / if_doubt | yes/no |  |  |
| failure path / if_not | yes/no |  |  |
| current status | yes/no |  |  |

## Missing pieces
- 

## Decision
- PASS
- PASS WITH CAVEATS
- FAIL
```

* * *

Como usar isso sem enlouquecer
==============================

Antes de um ciclo novo
----------------------

Preencher:

*   `Experiment Charter`
*   `Methodology Spec`
*   `Pre-Cycle Checklist`

E aplicar:

*   `Canonical Completeness Check`

A cada run
----------

Gerar automaticamente:

*   `Run Manifest`
*   `Structured Report`
*   `Raw outputs`
*   `RO-Crate`

Ao comparar ou encerrar
-----------------------

Escrever:

*   `Comparative Note`
*   `Decision Note`

E, se necessário:

*   `Canonical Completeness Check` nos docs novos

* * *

O mínimo do mínimo
==================

Se quiserem o núcleo mais simples possível, eu diria:

1.  `Experiment Charter`
2.  `Methodology Spec`
3.  `Run Manifest`
4.  `Comparative Note`
5.  `Decision Note`
6.  `Canonical Completeness Check`

Esse sexto item é o que transforma o kit antigo em algo realmente alinhado com tudo o que vocês discutiram.

* * *

Regra de ouro, agora melhor formulada
=====================================

Se antes de rodar vocês não conseguem responder claramente:

*   o que estamos testando,
*   o que pode mudar,
*   o que está congelado,
*   com base em que vamos interpretar,
*   e quando vamos parar,

então ainda não está pronto para virar run.

E se o documento não responde às funções canônicas mínimas, ele ainda não está cientificamente completo.

* * *

Fórmula final
=============

A frase que eu usaria no repo é:

> **Cânon por dentro, padrões internacionais por fora.**
> 
> Os templates experimentais usam a gramática canônica como teste de completude estrutural, mantêm vocabulário científico natural nos documentos, e publicam runs em formatos interoperáveis como RO-Crate com proveniência alinhada a PROV e software metadata em CodeMeta.

Isso amarra tudo.

Se você quiser, no próximo passo eu posso transformar essa versão em **arquivos prontos para copiar para o repo**, já com nomes finais e texto mais “institucional”.

## Prompt:
E da pra automatizar isso bastante

## Response:
Muito. E **deve** 😄

A regra boa aqui é:

> **automatizar estrutura, preservar julgamento.**

Ou seja:

*   a máquina preenche, valida, fingerprinta, empacota, compara, carimba tempo, checa completude;
*   humanos decidem hipótese, interpretação, encerramento e próxima pergunta.

O que dá para automatizar bastante
----------------------------------

### 1\. `Run Manifest`

Quase tudo:

*   timestamps UTC
*   versões e fingerprints
*   provider/model/backend
*   reasoning effort
*   corpus usado
*   report schema
*   frozen dimensions
*   refs para outputs
*   bloco PROV básico

Isso já está bem encaminhado no que vocês fizeram.

### 2\. `Canonical Completeness Check`

Também dá para automatizar bastante.

Não no sentido de “entender ciência magicamente”, mas de checar presença de campos/funções mínimas:

*   tem identidade?
*   tem escopo?
*   tem variável permitida?
*   tem frozen dimensions?
*   tem evidência/confirmed\_by?
*   tem success/failure/stop condition?
*   tem status?

Dá para fazer como:

*   validator por template
*   warnings
*   PASS / PASS WITH CAVEATS / FAIL

### 3\. `Pre-Cycle Checklist`

Pode ser semi-automático:

*   metade checada por schema/arquivos existentes
*   metade confirmada por humano

Exemplo:

*   existe charter? automático
*   existe methodology? automático
*   corpus fingerprintado? automático
*   pergunta cabe em 1 frase? humano
*   stop condition presente? automático
*   frozen dimensions preenchidas? automático

### 4\. `Comparative Note` rascunho

Dá para gerar um **draft muito bom** automaticamente:

*   o que ficou constante
*   o que mudou
*   diff de métricas
*   diff por caso
*   tempos/custos
*   lista de artifacts comparados

E deixar para humano escrever:

*   leitura honesta
*   conclusão metodológica
*   o que ainda não prova

Isso economiza muito tempo.

### 5\. `Decision Note` rascunho

Também dá:

*   ciclo relacionado
*   evidências usadas
*   runs comparadas
*   freeze targets
*   open questions
*   próximos candidatos

O humano só fecha:

*   por que encerrar agora
*   o que não reabrir
*   qual próxima hipótese

### 6\. RO-Crate / PROV / CodeMeta

Altamente automatizável:

*   gerar pacote
*   copiar artifacts
*   montar metadata JSON-LD
*   preencher `used`, `wasGeneratedBy`, `wasDerivedFrom`
*   linkar software/corpus/report

### 7\. Version registry

Quase 100% automático:

*   fingerprints
*   auto revisions
*   tracked paths
*   lineage entre ciclos/runs/lanes

### 8\. Diff de metodologia

Isso seria muito útil:

*   “o que mudou entre metodologia v1 e v2?”
*   “o que mudou entre input protocol v1 e v2?”
*   “esse ciclo mudou só provider selection ou mudou corpus também?”

Isso evita autoengano.

* * *

O que **não** deve ser automatizado demais
------------------------------------------

Aqui mora o cuidado.

### 1\. Hipótese

A máquina pode armazenar.  
Mas não deveria inventar a hipótese do ciclo como verdade metodológica.

### 2\. Interpretação final

Ela pode sugerir um draft.  
Mas a leitura honesta precisa de humano.

### 3\. Decisão de encerrar

Pode haver sinais automáticos, mas o fechamento do ciclo é ato de governança.

### 4\. Reclassificação oportunista

Nunca deixar o sistema “ajustar” expected verdicts ou redefinir corpus automaticamente para parecer melhor.

Esse é o tipo de automação que destrói a credibilidade.

* * *

O melhor desenho
================

Eu faria em **3 camadas**:

Camada 1 — Estrutural (quase toda automática)
---------------------------------------------

*   manifests
*   fingerprints
*   versions
*   reports
*   RO-Crate
*   completeness checks
*   metric diffs

Camada 2 — Assistida (rascunho automático, revisão humana)
----------------------------------------------------------

*   comparative note draft
*   decision note draft
*   methodology diff summary
*   cycle summary

Camada 3 — Humana (não terceirizar)
-----------------------------------

*   pergunta do ciclo
*   hipótese
*   leitura honesta
*   decisão de encerramento
*   próximo passo

* * *

O produto disso
===============

Se fizerem bem, vocês podem ter algo assim:

Antes da run
------------

Comando:

```
lab exp prepare --cycle cycle-2-baseline-v1
```

Gera/verifica:

*   charter presente
*   methodology presente
*   completeness check
*   manifests base
*   corpus fingerprint
*   frozen dimensions check
*   go/no-go report

Depois da run
-------------

Comando:

```
lab exp finalize --run cycle-2-baseline-v1-none
```

Gera:

*   run manifest completo
*   report consolidado
*   RO-Crate
*   version registry update
*   comparative draft se houver par comparável

Ao fechar ciclo
---------------

Comando:

```
lab exp close --cycle cycle-2-baseline-v1
```

Gera rascunhos:

*   comparative note
*   decision note
*   status patch suggestion

Isso seria lindo.

* * *

Em termos práticos, o que eu automatizaria primeiro
===================================================

Se eu estivesse priorizando, faria nesta ordem:

### 1\. `Canonical Completeness Check` automático

Porque isso governa tudo o resto.

### 2\. `prepare/finalize` do ciclo/run

Porque organiza o fluxo inteiro.

### 3\. Draft automático de `Comparative Note`

Porque poupa tempo e mantém consistência.

### 4\. Draft automático de `Decision Note`

Porque fecha memória institucional.

### 5\. Diffs de metodologia / corpus / provider selection

Porque isso melhora muito a honestidade experimental.

* * *

Resposta curta
==============

**Sim, dá para automatizar bastante.**  
E o ideal é automatizar tudo que é:

*   identidade,
*   estrutura,
*   versionamento,
*   validação,
*   empacotamento,
*   comparação.

E deixar para humanos o que é:

*   hipótese,
*   interpretação,
*   julgamento,
*   encerramento.

A frase boa é:

> **automatizar a disciplina, não terceirizar a honestidade.**

Se você quiser, eu posso te desenhar agora um **mini sistema de comandos/funções** para isso, tipo:

*   `prepare_cycle`
*   `validate_templates`
*   `finalize_run`
*   `draft_comparison`
*   `draft_decision`

## Prompt:
Preciso na verdade responder isso: comeco tudo de novo?

## Response:
Não. **Não começa tudo de novo.**

O que vocês têm hoje **já é trabalho válido**. O que faltou não foi valor — foi **governança ex ante**. Isso se corrige **por cima**, não apagando o que já foi feito.

A forma honesta de pensar é esta:

O que não recomeça
------------------

Não recomeçam:

*   a arquitetura
*   o runtime
*   o benchmark harness
*   os ciclos já rodados
*   os artefatos já congelados
*   os aprendizados já obtidos

Tudo isso continua valendo.

O que precisa “recomeçar” de forma controlada
---------------------------------------------

O que vocês fazem agora é só isto:

### 1\. Congelar o passado como **pré-governança**

Dar nome honesto ao que já aconteceu, por exemplo:

*   `pre-governance phase`
*   ou `template-family pre-v1`

Não para desqualificar, mas para contextualizar metodologicamente.

### 2\. Criar a **Template Family v1**

Agora sim, com:

*   charter
*   methodology
*   manifest
*   comparative note
*   decision note
*   completeness check

E declarar:

> daqui pra frente, todo ciclo novo usa essa família.

### 3\. Continuar a partir daqui

Não repetir tudo.  
Só os experimentos que **realmente precisarem** de rerun sob a nova governança.

E isso provavelmente significa:

*   não rerodar tudo cegamente,
*   só rerodar o que for importante como baseline oficial sob `v1`, se vocês julgarem necessário.

A pergunta certa não é
----------------------

“jogo tudo fora e começo do zero?”

A pergunta certa é:

> **o que do passado permanece como evidência útil, e o que precisa ser reexecutado sob governança mais forte para virar baseline definitivo?**

Essa é a postura madura.

Minha recomendação prática
--------------------------

Eu faria exatamente assim:

### A. Criar uma nota curta

Algo como:

*   `EXPERIMENTAL_GOVERNANCE_TRANSITION.md`

Dizendo:

*   o que existia antes
*   o que faltava
*   o que foi corrigido
*   a partir de quando vale a template family v1

### B. Marcar os ciclos já feitos como

*   válidos
*   úteis
*   mas anteriores à governança formal v1

### C. Escolher um ponto de reinício oficial

Não “do zero”, mas:

*   **a partir daqui começa a linha oficial governada**

### D. Seguir em frente

Sem culpa, sem apagar história, sem teatro de pureza.

Resposta mais direta ainda
--------------------------

Se você recomeçar tudo do zero, perde:

*   momentum
*   aprendizagem real
*   história metodológica
*   e confiança no próprio processo

Se você **assumir a ignorância, formalizar a governança e continuar**, ganha:

*   rigor
*   continuidade
*   honestidade
*   e um projeto mais forte

Então a minha resposta é:

> **não começa tudo de novo.**  
> **Você faz uma transição de regime.**

E isso, sinceramente, é muito melhor.

Se quiser, eu posso te redigir agora uma resposta curta, em tom firme e tranquilo, pra você colar lá exatamente com essa posição.